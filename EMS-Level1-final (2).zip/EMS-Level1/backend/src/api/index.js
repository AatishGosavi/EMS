'use strict';
// API process: REST + WebSocket + the built UI.  Usage: node src/api/index.js
const http = require('http');
const config = require('../config');
const { createPool } = require('../db');
const { createApp } = require('./app');
const { attachWs } = require('./ws');
const { fetchLive } = require('./routes/live');

const pool = createPool(config.databaseUrl, 10);
const server = http.createServer(createApp({ pool, config }));
const ws = attachWs({ server, pool, config, fetchLive: () => fetchLive(pool, config.staleSeconds) });
server.listen(config.port, () => console.log(`[${new Date().toISOString()}] [api] listening on http://localhost:${config.port}`));
require('./schema').missingObjects(pool).then((m) => {
  if (m.length) console.error(`[api] DATABASE SETUP INCOMPLETE - missing: ${m.join(', ')}\n[api] Run database/ems_check.sql, then install the missing parts (database/ems_all_in_one.sql on an empty database).`);
  else console.log('[api] database setup is complete');
}).catch((e) => console.error('[api] cannot reach the database:', e.message));
const stop = async () => { await ws.close(); server.close(); await pool.end(); process.exit(0); };
process.on('SIGINT', stop); process.on('SIGTERM', stop);
