'use strict';
// WebSocket /ws?token=<access token>: pushes {type:'live', meters:[...]} when the collector stored new values
// (PostgreSQL NOTIFY), at most once per second, and at least every 10 s so stale meters turn Down on screen.
const { WebSocketServer } = require('ws');
const jwt = require('jsonwebtoken');

function attachWs({ server, pool, config, fetchLive }) {
  const wss = new WebSocketServer({ noServer: true });
  server.on('upgrade', (req, socket, head) => {
    const url = new URL(req.url, 'http://localhost');
    let ok = url.pathname === '/ws';
    if (ok) { try { jwt.verify(url.searchParams.get('token') || '', config.jwtSecret); } catch { ok = false; } }
    if (!ok) { socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n'); return socket.destroy(); }
    wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws));
  });

  const frame = async () => JSON.stringify({ type: 'live', ts: new Date(), meters: await fetchLive() });
  const broadcast = async () => {
    if (!wss.clients.size) return;
    try { const msg = await frame(); for (const ws of wss.clients) if (ws.readyState === 1) ws.send(msg); }
    catch (e) { console.error('[ws] broadcast failed:', e.message); }
  };
  wss.on('connection', async (ws) => {
    ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; }); ws.on('error', () => {});
    try { ws.send(await frame()); } catch (_) {}
  });

  let timer = null, again = false, client = null, closed = false;
  const onNotify = () => {
    if (timer) { again = true; return; }
    broadcast();
    timer = setTimeout(() => { timer = null; if (again) { again = false; onNotify(); } }, 1000);
  };
  async function listen() {
    if (closed) return;
    try {
      client = await pool.connect();
      client.on('notification', onNotify);
      client.on('error', () => { try { client.release(true); } catch (_) {} client = null; setTimeout(listen, 5000); });
      await client.query('LISTEN ems_live');
    } catch (_) { client = null; setTimeout(listen, 5000); }
  }
  listen();
  const beat = setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); continue; } ws.isAlive = false; ws.ping(); } }, 30000);
  const refresh = setInterval(broadcast, 10000);
  return { wss, close: async () => { closed = true; clearInterval(beat); clearInterval(refresh); clearTimeout(timer); for (const ws of wss.clients) ws.terminate(); wss.close(); if (client) client.release(); } };
}
module.exports = { attachWs };
