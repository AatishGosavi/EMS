'use strict';
const express = require('express');
const ExcelJS = require('exceljs');
const { wrap, camel, intp, datep, HttpError } = require('../util');
const { tx } = require('../../db');

module.exports = function reportRoutes({ pool, auth }) {
  const r = express.Router();

  const checkDef = (d) => { if (!d || typeof d !== 'object' || Array.isArray(d)) throw new HttpError(400, 'definition must be an object'); return d; };
  async function runDef(def) {
    const { rows } = await pool.query('SELECT run_report($1::jsonb) AS r', [JSON.stringify(checkDef(def))]);
    return rows.map((x) => x.r);
  }
  async function columnsFor(def) {
    const gb = Array.isArray(def.groupBy) ? def.groupBy : def.groupBy ? [def.groupBy] : [];
    const dims = (await pool.query('SELECT code, label FROM report_dimensions')).rows, fields = (await pool.query('SELECT code, label, unit, default_agg FROM report_fields')).rows;
    const cols = gb.map((g) => ({ key: g, label: dims.find((d) => d.code === g)?.label || g, kind: 'dimension' }));
    for (const f of def.fields || []) {
      const fd = fields.find((x) => x.code === f.code), agg = (f.agg || fd?.default_agg || '').toLowerCase();
      cols.push({ key: `${f.code}_${agg}`, label: fd ? `${fd.label}${fd.unit ? ' (' + fd.unit + ')' : ''}${['sum'].includes(agg) ? '' : ' - ' + agg}` : f.code, kind: 'value' });
    }
    return cols;
  }

  // Everything the report builder screen needs to show its pickers.
  r.get('/reports/meta', wrap(async (req, res) => {
    const q = async (s) => (await pool.query(s)).rows;
    res.json({
      fields: camel(await q('SELECT code, label, unit, default_agg, allowed_aggs FROM report_fields ORDER BY sort_order')),
      dimensions: camel(await q('SELECT code, label, kind FROM report_dimensions ORDER BY sort_order')),
      scopes: [{ code: 'meters', label: 'Meters (without main meter)' }, { code: 'plant', label: 'Plant total (main meters)' }, { code: 'all', label: 'All meters' }],
      areas: camel(await q('SELECT id, name FROM areas ORDER BY sort_order, name')),
      meters: camel(await q('SELECT id, name, area_id, is_main FROM meters WHERE is_active ORDER BY name')),
    });
  }));

  r.post('/reports/run', wrap(async (req, res) => {
    const def = checkDef(req.body && req.body.definition);
    res.json({ columns: await columnsFor(def), rows: await runDef(def) });
  }));

  r.post('/reports/export', wrap(async (req, res) => {
    const def = checkDef(req.body && req.body.definition), format = (req.body.format || 'xlsx').toLowerCase();
    const cols = await columnsFor(def), rows = await runDef(def), stamp = new Date().toISOString().slice(0, 10);
    if (format === 'csv') {
      const esc = (v) => (v == null ? '' : /[",\n;]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
      const csv = [cols.map((c) => esc(c.label)).join(','), ...rows.map((x) => cols.map((c) => esc(x[c.key])).join(','))].join('\r\n');
      res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="report-${stamp}.csv"` });
      return res.send('\ufeff' + csv);
    }
    if (format !== 'xlsx') throw new HttpError(400, 'format must be xlsx or csv');
    const wb = new ExcelJS.Workbook(), ws = wb.addWorksheet('Report');
    ws.columns = cols.map((c) => ({ header: c.label, key: c.key, width: Math.max(14, c.label.length + 2) }));
    ws.getRow(1).font = { bold: true };
    ws.views = [{ state: 'frozen', ySplit: 1 }];
    for (const x of rows) ws.addRow(Object.fromEntries(cols.map((c) => [c.key, x[c.key]])));
    cols.forEach((c, i) => { if (c.kind === 'value') ws.getColumn(i + 1).numFmt = '#,##0.0##'; });
    res.set({ 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': `attachment; filename="report-${stamp}.xlsx"` });
    res.send(Buffer.from(await wb.xlsx.writeBuffer()));
  }));

  // ---- saved report templates: own templates, plus shared ones ----
  const mayShare = (u) => u.role !== 'viewer';
  r.get('/reports/templates', wrap(async (req, res) => {
    const { rows } = await pool.query(`SELECT t.id, t.name, t.definition, t.is_shared, t.owner_id, u.username AS owner, t.updated_at
      FROM report_templates t LEFT JOIN users u ON u.id = t.owner_id WHERE t.owner_id = $1 OR t.is_shared ORDER BY t.name`, [req.user.id]);
    res.json(camel(rows));
  }));
  r.post('/reports/templates', wrap(async (req, res) => {
    const { name, definition, isShared = false } = req.body || {};
    if (!name || !String(name).trim()) throw new HttpError(400, 'name is required');
    if (isShared && !mayShare(req.user)) throw new HttpError(403, 'Only engineers and admins can share templates');
    await runDef(definition);                                  // validates the definition against the field registry
    const row = await tx(pool, req.user.id, async (c) => (await c.query(
      'INSERT INTO report_templates (name, owner_id, is_shared, definition) VALUES ($1, $2, $3, $4) RETURNING *', [String(name).trim(), req.user.id, !!isShared, definition])).rows[0]);
    res.status(201).json(camel(row));
  }));
  const owned = async (req) => {
    const { rows } = await pool.query('SELECT * FROM report_templates WHERE id = $1', [intp(req.params.id, 'id')]);
    if (!rows[0]) throw new HttpError(404, 'Template not found');
    if (rows[0].owner_id !== req.user.id && req.user.role !== 'admin') throw new HttpError(403, 'This template belongs to someone else');
    return rows[0];
  };
  r.put('/reports/templates/:id', wrap(async (req, res) => {
    const t = await owned(req), { name = t.name, definition = t.definition, isShared = t.is_shared } = req.body || {};
    if (isShared && !mayShare(req.user)) throw new HttpError(403, 'Only engineers and admins can share templates');
    await runDef(definition);
    const row = await tx(pool, req.user.id, async (c) => (await c.query(
      'UPDATE report_templates SET name = $2, is_shared = $3, definition = $4 WHERE id = $1 RETURNING *', [t.id, name, !!isShared, definition])).rows[0]);
    res.json(camel(row));
  }));
  r.delete('/reports/templates/:id', wrap(async (req, res) => {
    const t = await owned(req);
    await tx(pool, req.user.id, (c) => c.query('DELETE FROM report_templates WHERE id = $1', [t.id]));
    res.json({ ok: true });
  }));

  // ---- cost per day and meter from the tariffs ----
  r.get('/reports/cost', wrap(async (req, res) => {
    const from = datep(req.query.from, 'from'), to = datep(req.query.to, 'to');
    const meters = req.query.meters ? String(req.query.meters).split(',').map((x) => intp(x, 'meters')) : null;
    const { rows } = await pool.query('SELECT * FROM energy_cost($1::date, $2::date, $3::int[])', [from, to, meters]);
    res.json(camel(rows));
  }));
  return r;
};
