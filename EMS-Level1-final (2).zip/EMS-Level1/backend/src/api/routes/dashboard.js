'use strict';
const express = require('express');
const { wrap } = require('../util');

module.exports = function dashboardRoutes({ pool, config }) {
  const r = express.Router();
  r.get('/dashboard', wrap(async (req, res) => {
    const q = async (sql, p = []) => (await pool.query(sql, p)).rows;
    const tz = (await q("SELECT value FROM app_settings WHERE key = 'plant_timezone'"))[0]?.value || 'UTC';
    const hasMain = (await q('SELECT EXISTS (SELECT 1 FROM meters WHERE is_main AND is_active) AS x'))[0].x;
    const plant = hasMain ? 'm.is_main' : 'true';          // plant total = main meters if any are flagged, otherwise all meters
    const parts = hasMain ? 'NOT m.is_main' : 'true';      // area/meter breakdowns never include the main meter
    const t0 = "(date_trunc('day', now() AT TIME ZONE $1) AT TIME ZONE $1)";

    const [now] = await q(`
      WITH x AS (SELECT m.is_main, l.kw, (l.ts >= now() - make_interval(secs => $1) AND l.state <> 0) AS up
                 FROM meters m LEFT JOIN meter_latest l ON l.meter_id = m.id WHERE m.is_active)
      SELECT coalesce(sum(kw) FILTER (WHERE ${hasMain ? 'is_main' : 'true'} AND up), 0) AS kw_now,
             count(*) FILTER (WHERE ${hasMain ? 'NOT is_main' : 'true'}) AS total,
             count(*) FILTER (WHERE ${hasMain ? 'NOT is_main' : 'true'} AND up) AS online FROM x`, [config.staleSeconds]);
    const [energy] = await q(`SELECT coalesce(sum(d.kwh_import), 0) AS kwh FROM readings_daily d JOIN meters m ON m.id = d.meter_id
                              WHERE d.day = ${t0} AND ${plant}`, [tz]);
    const [peak] = await q(`SELECT r.ts, sum(r.kw) AS kw FROM readings r JOIN meters m ON m.id = r.meter_id
                            WHERE r.ts >= ${t0} AND ${plant} GROUP BY r.ts ORDER BY kw DESC NULLS LAST LIMIT 1`, [tz]);
    const [batches] = await q('SELECT count(*) AS n FROM batches WHERE end_ts IS NULL');
    const trend = await q(`
      WITH t AS (SELECT r.ts, sum(r.kw) AS kw FROM readings r JOIN meters m ON m.id = r.meter_id
                 WHERE r.ts >= now() - interval '48 hours' AND ${plant} GROUP BY r.ts)
      SELECT time_bucket('30 minutes', ts) AS b, avg(kw) AS kw FROM t GROUP BY 1 ORDER BY 1`, []);
    const areas = await q(`SELECT a.name AS area, sum(d.kwh_import) AS kwh FROM readings_daily d
                           JOIN meters m ON m.id = d.meter_id JOIN areas a ON a.id = m.area_id
                           WHERE d.day = ${t0} AND ${parts} GROUP BY a.name ORDER BY kwh DESC`, [tz]);
    const cut = Date.now() - 24 * 3600e3, round = (v) => Math.round(v * 10) / 10;
    res.json({
      timezone: tz, usesMainMeter: hasMain,
      plantKwNow: round(now.kw_now), energyTodayKwh: round(energy.kwh),
      peakDemandKw: peak ? round(peak.kw) : null, peakAt: peak ? peak.ts : null,
      metersOnline: now.online, metersTotal: now.total, batchesRunning: batches.n,
      trend: { bucketMinutes: 30,
        today: trend.filter((p) => p.b.getTime() >= cut).map((p) => ({ t: p.b, kw: round(p.kw) })),
        yesterday: trend.filter((p) => p.b.getTime() < cut).map((p) => ({ t: new Date(p.b.getTime() + 24 * 3600e3), kw: round(p.kw) })) },
      areaEnergyToday: areas.map((a) => ({ area: a.area, kwh: round(a.kwh) })),
    });
  }));

  // Trend of one meter. Resolution is chosen from the range: raw minutes (<= 2 days), 15 minutes (<= 31 days), daily.
  r.get('/meters/:id/trend', wrap(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const to = req.query.to ? new Date(req.query.to) : new Date();
    const from = req.query.from ? new Date(req.query.from) : new Date(to.getTime() - 24 * 3600e3);
    if (isNaN(from) || isNaN(to) || to <= from) return res.status(400).json({ error: 'from/to must be valid date-times, to after from' });
    const days = (to - from) / 86400e3;
    let sql, resolution;
    if (days <= 2) { resolution = 'minute'; sql = 'SELECT ts AS t, state, kw, kvar, kva, pf, freq, v_l1, v_l2, v_l3, i_l1, i_l2, i_l3, kwh_import_delta AS kwh FROM readings WHERE meter_id = $1 AND ts >= $2 AND ts < $3 ORDER BY ts'; }
    else if (days <= 31) { resolution = '15min'; sql = 'SELECT bucket AS t, kw_avg AS kw, kw_max, kvar_avg AS kvar, pf_avg AS pf, v_l1_avg AS v_l1, i_max, kwh_import AS kwh FROM readings_15min WHERE meter_id = $1 AND bucket >= $2 AND bucket < $3 ORDER BY bucket'; }
    else { resolution = 'day'; sql = 'SELECT day AS t, kw_avg AS kw, kw_max, pf_avg AS pf, i_max, kwh_import AS kwh, running_samples, idle_samples, down_samples FROM readings_daily WHERE meter_id = $1 AND day >= $2 AND day < $3 ORDER BY day'; }
    const { rows } = await pool.query(sql, [id, from, to]);
    res.json({ meterId: id, resolution, rows });
  }));
  return r;
};
