'use strict';
const express = require('express');
const { wrap, camel } = require('../util');

const LABEL = ['Down', 'Idle', 'Running'];
const VALUES = ['v_l1', 'v_l2', 'v_l3', 'i_l1', 'i_l2', 'i_l3', 'kw', 'kvar', 'kva', 'pf', 'freq', 'kwh_import', 'kwh_export'];
const SQL = `
  SELECT m.id, m.code, m.name, m.area_id, a.name AS area, m.has_batch, m.is_main,
         l.ts, (l.ts IS NULL OR l.ts < now() - make_interval(secs => $1)) AS stale, l.state,
         ${VALUES.map((c) => 'l.' + c).join(', ')},
         vb.id AS batch_id, vb.batch_no, vb.recipe_id, vb.recipe_name, vb.start_ts AS batch_started,
         extract(epoch FROM vb.duration) AS batch_seconds, vb.kwh_import AS batch_kwh
  FROM meters m
  JOIN areas a ON a.id = m.area_id
  LEFT JOIN meter_latest l ON l.meter_id = m.id
  LEFT JOIN v_batches vb ON vb.meter_id = m.id AND vb.end_ts IS NULL
  WHERE m.is_active
  ORDER BY a.sort_order, a.name, m.sort_order, m.name`;

// Live view of all meters. A meter whose data is older than STALE_SECONDS is reported Down (collector or PLC problem).
// Energy today per meter changes slowly and is the most expensive number, so it is cached for 30 seconds.
const cache = new WeakMap();
async function energyToday(pool) {
  const c = cache.get(pool) || {};
  if (c.map && Date.now() - c.at < 30000) return c.map;
  if (!c.busy) {
    c.busy = pool.query(`SELECT d.meter_id, d.kwh_import FROM readings_daily d WHERE d.day =
      (date_trunc('day', now() AT TIME ZONE (SELECT value FROM app_settings WHERE key = 'plant_timezone'))
         AT TIME ZONE (SELECT value FROM app_settings WHERE key = 'plant_timezone'))`)
      .then((r) => { c.map = new Map(r.rows.map((x) => [x.meter_id, x.kwh_import])); c.at = Date.now(); })
      .finally(() => { c.busy = null; });
    cache.set(pool, c);
  }
  await c.busy;
  return c.map || new Map();
}

async function fetchLive(pool, staleSeconds) {
  const [{ rows }, today] = await Promise.all([pool.query(SQL, [staleSeconds]), energyToday(pool)]);
  return rows.map((r) => {
    const state = r.stale ? 0 : (r.state ?? 0), up = state !== 0;
    const o = { id: r.id, code: r.code, name: r.name, areaId: r.area_id, area: r.area, hasBatch: r.has_batch, isMain: r.is_main,
      state, status: LABEL[state], lastUpdate: r.ts, stale: r.stale, energyToday: today.get(r.id) ?? 0 };
    for (const c of VALUES) o[Object.keys(camel({ [c]: 1 }))[0]] = up ? r[c] : null;
    o.batch = r.batch_id ? { id: r.batch_id, no: r.batch_no, recipeId: r.recipe_id, recipe: r.recipe_name,
      startedAt: r.batch_started, seconds: Math.round(r.batch_seconds), kwhSoFar: r.batch_kwh } : null;
    return o;
  });
}

module.exports = function liveRoutes({ pool, config }) {
  const r = express.Router();
  r.get('/live/meters', wrap(async (req, res) => res.json(await fetchLive(pool, config.staleSeconds))));
  return r;
};
module.exports.fetchLive = fetchLive;
