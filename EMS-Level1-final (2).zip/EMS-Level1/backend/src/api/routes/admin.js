'use strict';
const express = require('express');
const { wrap, camel, intp, limitp, patchSet, HttpError } = require('../util');
const { tx } = require('../../db');

const METER = { code: 'code', name: 'name', areaId: 'area_id', plcIndex: 'plc_index', hasBatch: 'has_batch', multiplier: 'multiplier',
  runSource: 'run_source', idleThresholdKw: 'idle_threshold_kw', isMain: 'is_main', isActive: 'is_active', sortOrder: 'sort_order' };
const USER = { displayName: 'display_name', email: 'email', role: 'role', isActive: 'is_active', mustChangePassword: 'must_change_password' };

function insertParts(body, map, required = []) {
  for (const k of required) if (body[k] === undefined || body[k] === '') throw new HttpError(400, `${k} is required`);
  const cols = [], vals = [];
  for (const [k, col] of Object.entries(map)) if (body[k] !== undefined) { cols.push(col); vals.push(body[k]); }
  return { cols: cols.join(', '), ph: vals.map((_, i) => '$' + (i + 1)).join(', '), vals };
}

module.exports = function adminRoutes({ pool, config, auth }) {
  const r = express.Router(), { role } = auth;
  const notify = () => pool.query("SELECT pg_notify('ems_config', '')");
  const strip = ({ password_hash, ...u }) => camel(u);

  r.get('/settings', wrap(async (req, res) => {
    const tz = (await pool.query("SELECT value FROM app_settings WHERE key = 'plant_timezone'")).rows[0]?.value;
    res.json({ plantTimezone: tz, staleSeconds: config.staleSeconds, pollSeconds: config.pollMs / 1000, logSeconds: config.logMs / 1000 });
  }));

  // ---- areas ----
  r.get('/areas', wrap(async (req, res) => res.json(camel((await pool.query(
    `SELECT a.id, a.parent_id, a.name, a.sort_order, count(m.id)::int AS meter_count FROM areas a LEFT JOIN meters m ON m.area_id = a.id
     GROUP BY a.id ORDER BY a.sort_order, a.name`)).rows))));
  r.post('/areas', role('admin'), wrap(async (req, res) => {
    const b = req.body || {}; if (!b.name) throw new HttpError(400, 'name is required');
    const row = await tx(pool, req.user.id, async (c) => (await c.query('INSERT INTO areas (name, parent_id, sort_order) VALUES ($1, $2, $3) RETURNING *', [b.name, b.parentId || null, b.sortOrder || 0])).rows[0]);
    await notify(); res.status(201).json(camel(row));
  }));
  r.patch('/areas/:id', role('admin'), wrap(async (req, res) => {
    const { sets, vals } = patchSet(req.body || {}, { name: 'name', parentId: 'parent_id', sortOrder: 'sort_order' });
    const row = await tx(pool, req.user.id, async (c) => (await c.query(`UPDATE areas SET ${sets} WHERE id = $${vals.length + 1} RETURNING *`, [...vals, intp(req.params.id, 'id')])).rows[0]);
    if (!row) throw new HttpError(404, 'Area not found');
    await notify(); res.json(camel(row));
  }));
  r.delete('/areas/:id', role('admin'), wrap(async (req, res) => {
    const n = await tx(pool, req.user.id, async (c) => (await c.query('DELETE FROM areas WHERE id = $1', [intp(req.params.id, 'id')])).rowCount);
    if (!n) throw new HttpError(404, 'Area not found');
    await notify(); res.json({ ok: true });
  }));

  // ---- meters (changes are picked up by the collector without a restart) ----
  r.get('/meters', wrap(async (req, res) => res.json(camel((await pool.query(
    `SELECT m.*, a.name AS area FROM meters m JOIN areas a ON a.id = m.area_id ORDER BY m.plc_index`)).rows))));
  r.post('/meters', role('admin'), wrap(async (req, res) => {
    const { cols, ph, vals } = insertParts(req.body || {}, METER, ['code', 'name', 'areaId', 'plcIndex']);
    const row = await tx(pool, req.user.id, async (c) => (await c.query(`INSERT INTO meters (${cols}) VALUES (${ph}) RETURNING *`, vals)).rows[0]);
    await notify(); res.status(201).json(camel(row));
  }));
  r.patch('/meters/:id', role('admin'), wrap(async (req, res) => {
    const { sets, vals } = patchSet(req.body || {}, METER);
    const row = await tx(pool, req.user.id, async (c) => (await c.query(`UPDATE meters SET ${sets} WHERE id = $${vals.length + 1} RETURNING *`, [...vals, intp(req.params.id, 'id')])).rows[0]);
    if (!row) throw new HttpError(404, 'Meter not found');
    await notify(); res.json(camel(row));
  }));

  // ---- recipes (names for the numbers the PLC sends) ----
  r.get('/recipes', wrap(async (req, res) => res.json((await pool.query('SELECT id, name FROM recipes ORDER BY id')).rows)));
  r.put('/recipes/:id', role('engineer'), wrap(async (req, res) => {
    const name = String((req.body || {}).name || '').trim(); if (!name) throw new HttpError(400, 'name is required');
    const row = await tx(pool, req.user.id, async (c) => (await c.query('INSERT INTO recipes (id, name) VALUES ($1, $2) ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name RETURNING *', [intp(req.params.id, 'id'), name])).rows[0]);
    res.json(row);
  }));

  // ---- users (admin only) ----
  r.get('/users', role('admin'), wrap(async (req, res) => res.json((await pool.query(
    'SELECT id, username, display_name, email, role, is_active, must_change_password, last_login_at, created_at FROM users ORDER BY username')).rows.map(camel))));
  r.post('/users', role('admin'), wrap(async (req, res) => {
    const b = req.body || {};
    if (!b.username || !b.password) throw new HttpError(400, 'username and password are required');
    if (String(b.password).length < 8) throw new HttpError(400, 'Password must have at least 8 characters');
    const row = await tx(pool, req.user.id, async (c) => (await c.query(
      `INSERT INTO users (username, display_name, email, password_hash, role, must_change_password) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [b.username, b.displayName || b.username, b.email || null, await auth.hash(String(b.password)), b.role || 'viewer', b.mustChangePassword !== false])).rows[0]);
    res.status(201).json(strip(row));
  }));
  r.patch('/users/:id', role('admin'), wrap(async (req, res) => {
    const id = intp(req.params.id, 'id'), b = req.body || {};
    if (id === req.user.id && (b.isActive === false || (b.role && b.role !== 'admin'))) throw new HttpError(400, 'You cannot deactivate or demote your own account');
    const body = { ...b }, extra = [];
    if (b.password !== undefined) {
      if (String(b.password).length < 8) throw new HttpError(400, 'Password must have at least 8 characters');
      body.passwordHash = await auth.hash(String(b.password)); extra.push('passwordHash');
    }
    const { sets, vals } = patchSet(body, { ...USER, passwordHash: 'password_hash' });
    const row = await tx(pool, req.user.id, async (c) => {
      const u = (await c.query(`UPDATE users SET ${sets} WHERE id = $${vals.length + 1} RETURNING *`, [...vals, id])).rows[0];
      if (u && (b.password !== undefined || b.isActive === false)) await c.query('UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [id]);
      return u;
    });
    if (!row) throw new HttpError(404, 'User not found');
    res.json(strip(row));
  }));

  r.get('/audit', role('admin'), wrap(async (req, res) => {
    const p = [limitp(req.query.limit, 100, 1000)]; let w = '';
    if (req.query.entity) { p.push(String(req.query.entity)); w = 'WHERE a.entity = $2'; }
    res.json((await pool.query(`SELECT a.id, a.ts, a.user_id, u.username, a.action, a.entity, a.entity_id, a.details FROM audit_log a
      LEFT JOIN users u ON u.id = a.user_id ${w} ORDER BY a.ts DESC, a.id DESC LIMIT $1`, p)).rows.map(camel));
  }));

  // ---- tariffs (admin) ----
  const TARIFFS = `SELECT t.*, coalesce(json_agg(json_build_object('id', p.id, 'name', p.name, 'startTime', to_char(p.start_time, 'HH24:MI'),
      'endTime', to_char(p.end_time, 'HH24:MI'), 'days', p.days, 'ratePerKwh', p.rate_per_kwh) ORDER BY p.start_time) FILTER (WHERE p.id IS NOT NULL), '[]') AS periods
    FROM tariffs t LEFT JOIN tariff_periods p ON p.tariff_id = t.id`;
  r.get('/tariffs', wrap(async (req, res) => res.json(camel((await pool.query(`${TARIFFS} GROUP BY t.id ORDER BY t.valid_from DESC`)).rows))));
  const savePeriods = async (c, id, periods = []) => {
    await c.query('DELETE FROM tariff_periods WHERE tariff_id = $1', [id]);
    for (const p of periods) await c.query('INSERT INTO tariff_periods (tariff_id, name, start_time, end_time, days, rate_per_kwh) VALUES ($1,$2,$3,$4,$5,$6)',
      [id, p.name, p.startTime, p.endTime, p.days || [1, 2, 3, 4, 5, 6, 7], p.ratePerKwh]);
  };
  const TMAP = { name: 'name', validFrom: 'valid_from', validTo: 'valid_to', currency: 'currency', defaultRatePerKwh: 'default_rate_per_kwh', demandRatePerKw: 'demand_rate_per_kw', fixedMonthlyCharge: 'fixed_monthly_charge' };
  r.post('/tariffs', role('admin'), wrap(async (req, res) => {
    const b = req.body || {}, { cols, ph, vals } = insertParts(b, TMAP, ['name', 'validFrom', 'defaultRatePerKwh']);
    const id = await tx(pool, req.user.id, async (c) => { const t = (await c.query(`INSERT INTO tariffs (${cols}) VALUES (${ph}) RETURNING id`, vals)).rows[0]; await savePeriods(c, t.id, b.periods); return t.id; });
    res.status(201).json(camel((await pool.query(`${TARIFFS} WHERE t.id = $1 GROUP BY t.id`, [id])).rows[0]));
  }));
  r.put('/tariffs/:id', role('admin'), wrap(async (req, res) => {
    const id = intp(req.params.id, 'id'), b = req.body || {};
    await tx(pool, req.user.id, async (c) => {
      const keys = Object.keys(TMAP).filter((k) => b[k] !== undefined);
      if (keys.length) { const { sets, vals } = patchSet(b, TMAP); if (!(await c.query(`UPDATE tariffs SET ${sets} WHERE id = $${vals.length + 1}`, [...vals, id])).rowCount) throw new HttpError(404, 'Tariff not found'); }
      if (b.periods) await savePeriods(c, id, b.periods);
    });
    res.json(camel((await pool.query(`${TARIFFS} WHERE t.id = $1 GROUP BY t.id`, [id])).rows[0]));
  }));
  r.delete('/tariffs/:id', role('admin'), wrap(async (req, res) => {
    await tx(pool, req.user.id, (c) => c.query('DELETE FROM tariffs WHERE id = $1', [intp(req.params.id, 'id')]));
    res.json({ ok: true });
  }));
  return r;
};
