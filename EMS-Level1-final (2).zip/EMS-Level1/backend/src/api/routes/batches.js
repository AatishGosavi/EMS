'use strict';
const express = require('express');
const { wrap, camel, intp, datep, limitp, HttpError } = require('../util');

module.exports = function batchRoutes({ pool }) {
  const r = express.Router();
  r.get('/batches', wrap(async (req, res) => {
    const w = [], p = [];
    const add = (sql, v) => { p.push(v); w.push(sql.replace('?', '$' + p.length)); };
    if (req.query.meterId) add('meter_id = ?', intp(req.query.meterId, 'meterId'));
    if (req.query.recipeId) add('recipe_id = ?', intp(req.query.recipeId, 'recipeId'));
    if (req.query.status) { if (!['running', 'completed'].includes(req.query.status)) throw new HttpError(400, 'status must be running or completed'); add('status = ?', req.query.status); }
    const tz = (await pool.query("SELECT value FROM app_settings WHERE key = 'plant_timezone'")).rows[0]?.value || 'UTC';
    if (req.query.from) { p.push(datep(req.query.from, 'from'), tz); w.push(`start_ts >= ($${p.length - 1}::date)::timestamp AT TIME ZONE $${p.length}`); }
    if (req.query.to) { p.push(datep(req.query.to, 'to'), tz); w.push(`start_ts < (($${p.length - 1}::date + 1)::timestamp) AT TIME ZONE $${p.length}`); }
    p.push(limitp(req.query.limit), Math.max(parseInt(req.query.offset, 10) || 0, 0));
    const { rows } = await pool.query(`SELECT *, extract(epoch FROM duration) AS duration_seconds FROM v_batches
      ${w.length ? 'WHERE ' + w.join(' AND ') : ''} ORDER BY start_ts DESC LIMIT $${p.length - 1} OFFSET $${p.length}`, p);
    res.json(rows.map(({ duration, ...b }) => camel(b)));
  }));

  r.get('/batches/:id', wrap(async (req, res) => {
    const id = intp(req.params.id, 'id');
    const one = async (bid) => (await pool.query('SELECT *, extract(epoch FROM duration) AS duration_seconds FROM v_batches WHERE id = $1', [bid])).rows[0];
    const b = await one(id);
    if (!b) throw new HttpError(404, 'Batch not found');
    const curve = async (bid) => (await pool.query('SELECT minute, kw FROM batch_curve($1)', [bid])).rows;
    const prevId = (await pool.query('SELECT batch_previous($1) AS id', [id])).rows[0].id;
    const prev = prevId ? await one(prevId) : null;
    const cmp = (await pool.query('SELECT * FROM batch_vs_previous($1)', [id])).rows[0] || null;
    const strip = ({ duration, ...x }) => camel(x);
    res.json({ batch: strip(b), curve: await curve(id), previous: prev ? strip(prev) : null, previousCurve: prev ? await curve(prevId) : [],
      comparison: cmp ? camel(cmp) : null });
  }));
  return r;
};
