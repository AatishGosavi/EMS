'use strict';
const express = require('express');
const { wrap, camel, intp, limitp, patchSet, HttpError } = require('../util');
const { tx } = require('../../db');

const RULE = { name: 'name', scope: 'scope', meterId: 'meter_id', areaId: 'area_id', metric: 'metric', operator: 'operator',
  threshold: 'threshold', forSeconds: 'for_seconds', severity: 'severity', isActive: 'is_active' };

module.exports = function alarmRoutes({ pool, auth }) {
  const r = express.Router(), { role } = auth;
  const notify = () => pool.query("SELECT pg_notify('ems_config', '')");

  r.get('/alarms', wrap(async (req, res) => {
    const w = req.query.active === 'true' ? 'WHERE active' : req.query.active === 'false' ? 'WHERE NOT active' : '';
    res.json((await pool.query(`SELECT * FROM v_alarms ${w} ORDER BY started_at DESC LIMIT $1`, [limitp(req.query.limit, 100, 1000)])).rows.map(camel));
  }));
  r.post('/alarms/:id/ack', role('engineer'), wrap(async (req, res) => {
    const ok = (await pool.query('SELECT alarm_ack($1, $2) AS ok', [intp(req.params.id, 'id'), req.user.id])).rows[0].ok;
    if (!ok) throw new HttpError(409, 'Alarm not found or already acknowledged');
    res.json({ ok: true });
  }));

  r.get('/alarm-rules', wrap(async (req, res) => res.json((await pool.query('SELECT * FROM alarm_rules ORDER BY id')).rows.map(camel))));
  r.post('/alarm-rules', role('engineer'), wrap(async (req, res) => {
    const b = req.body || {}, cols = [], vals = [];
    for (const [k, col] of Object.entries(RULE)) if (b[k] !== undefined) { cols.push(col); vals.push(b[k]); }
    if (!b.name || !b.metric || !b.operator || b.threshold === undefined) throw new HttpError(400, 'name, metric, operator and threshold are required');
    const row = await tx(pool, req.user.id, async (c) => (await c.query(`INSERT INTO alarm_rules (${cols.join(', ')}) VALUES (${vals.map((_, i) => '$' + (i + 1)).join(', ')}) RETURNING *`, vals)).rows[0]);
    await notify(); res.status(201).json(camel(row));
  }));
  r.put('/alarm-rules/:id', role('engineer'), wrap(async (req, res) => {
    const { sets, vals } = patchSet(req.body || {}, RULE);
    const row = await tx(pool, req.user.id, async (c) => (await c.query(`UPDATE alarm_rules SET ${sets} WHERE id = $${vals.length + 1} RETURNING *`, [...vals, intp(req.params.id, 'id')])).rows[0]);
    if (!row) throw new HttpError(404, 'Rule not found');
    await notify(); res.json(camel(row));
  }));
  r.delete('/alarm-rules/:id', role('engineer'), wrap(async (req, res) => {
    await tx(pool, req.user.id, (c) => c.query('DELETE FROM alarm_rules WHERE id = $1', [intp(req.params.id, 'id')]));
    await notify(); res.json({ ok: true });
  }));
  return r;
};
