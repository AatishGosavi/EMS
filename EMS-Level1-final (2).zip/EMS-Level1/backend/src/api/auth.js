'use strict';
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { HttpError, wrap } = require('./util');

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
const RANK = { viewer: 1, engineer: 2, admin: 3 };
const MAX_FAILS = 5, LOCK_MIN = 15;

module.exports = function makeAuth({ pool, config }) {
  const publicUser = (u) => ({ id: u.id, username: u.username, displayName: u.display_name || u.username, email: u.email, role: u.role, mustChangePassword: u.must_change_password });
  const sign = (u) => jwt.sign({ sub: u.id, role: u.role, name: u.display_name || u.username }, config.jwtSecret, { expiresIn: config.accessTtlMin * 60 });

  const required = (req, res, next) => {
    const h = req.headers.authorization || '';
    if (!h.startsWith('Bearer ')) return res.status(401).json({ error: 'Not signed in' });
    try { const p = jwt.verify(h.slice(7), config.jwtSecret); req.user = { id: +p.sub, role: p.role, name: p.name }; next(); }
    catch { res.status(401).json({ error: 'Session expired' }); }
  };
  const role = (min) => (req, res, next) => (RANK[req.user.role] >= RANK[min] ? next() : res.status(403).json({ error: 'Your role is not allowed to do this' }));

  async function newSession(user, req) {
    const token = crypto.randomBytes(32).toString('hex');
    await pool.query(`INSERT INTO user_sessions (user_id, refresh_token_hash, expires_at, ip, user_agent)
                      VALUES ($1, $2, now() + make_interval(days => $3), $4, $5)`,
      [user.id, sha(token), config.refreshTtlDays, req.ip || null, (req.headers['user-agent'] || '').slice(0, 200)]);
    return { accessToken: sign(user), refreshToken: token, expiresInSeconds: config.accessTtlMin * 60, user: publicUser(user) };
  }

  const router = express.Router();

  router.post('/login', wrap(async (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) throw new HttpError(400, 'Username and password are required');
    const { rows } = await pool.query('SELECT * FROM users WHERE lower(username) = lower($1)', [String(username)]);
    const u = rows[0];
    if (u && u.locked_until && u.locked_until > new Date()) throw new HttpError(423, 'Account is locked for a while after too many wrong passwords');
    const ok = u && u.is_active && await bcrypt.compare(String(password), u.password_hash);
    if (!ok) {
      if (u) await pool.query(`UPDATE users SET failed_logins = failed_logins + 1,
        locked_until = CASE WHEN failed_logins + 1 >= $2 THEN now() + make_interval(mins => $3) ELSE locked_until END WHERE id = $1`, [u.id, MAX_FAILS, LOCK_MIN]);
      throw new HttpError(401, 'Wrong username or password');
    }
    await pool.query('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = now() WHERE id = $1', [u.id]);
    res.json(await newSession(u, req));
  }));

  router.post('/refresh', wrap(async (req, res) => {
    const token = (req.body || {}).refreshToken;
    if (!token) throw new HttpError(400, 'refreshToken is required');
    const { rows } = await pool.query(`UPDATE user_sessions s SET revoked_at = now() FROM users u
      WHERE s.refresh_token_hash = $1 AND s.revoked_at IS NULL AND s.expires_at > now() AND u.id = s.user_id AND u.is_active
      RETURNING u.*`, [sha(String(token))]);
    if (!rows[0]) throw new HttpError(401, 'Session expired, please sign in again');
    res.json(await newSession(rows[0], req));                 // refresh tokens are single-use (rotated)
  }));

  router.post('/logout', wrap(async (req, res) => {
    const token = (req.body || {}).refreshToken;
    if (token) await pool.query('UPDATE user_sessions SET revoked_at = now() WHERE refresh_token_hash = $1 AND revoked_at IS NULL', [sha(String(token))]);
    res.json({ ok: true });
  }));

  router.get('/me', required, wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM users WHERE id = $1 AND is_active', [req.user.id]);
    if (!rows[0]) throw new HttpError(401, 'Account is not active');
    res.json(publicUser(rows[0]));
  }));

  router.post('/change-password', required, wrap(async (req, res) => {
    const { currentPassword, newPassword } = req.body || {};
    if (!newPassword || String(newPassword).length < 8) throw new HttpError(400, 'New password must have at least 8 characters');
    const { rows } = await pool.query('SELECT * FROM users WHERE id = $1', [req.user.id]);
    if (!rows[0] || !(await bcrypt.compare(String(currentPassword || ''), rows[0].password_hash))) throw new HttpError(400, 'Current password is wrong');
    await pool.query('UPDATE users SET password_hash = $2, must_change_password = false WHERE id = $1', [req.user.id, await bcrypt.hash(String(newPassword), 12)]);
    await pool.query('UPDATE user_sessions SET revoked_at = now() WHERE user_id = $1 AND revoked_at IS NULL', [req.user.id]);
    res.json({ ok: true });
  }));

  return { router, required, role, hash: (p) => bcrypt.hash(p, 12) };
};
