'use strict';
const express = require('express');
const fs = require('fs');
const path = require('path');
const makeAuth = require('./auth');
const { wrap, errorHandler } = require('./util');
const { missingObjects } = require('./schema');

function createApp({ pool, config }) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 'loopback');
  app.use((req, res, next) => { res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'same-origin' }); next(); });
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', wrap(async (req, res) => {
    try {
      const r = await pool.query('SELECT extract(epoch FROM now() - max(ts)) AS age FROM meter_latest');
      const age = r.rows[0].age, missing = await missingObjects(pool);
      res.json({ ok: missing.length === 0, database: true, schemaOk: missing.length === 0, missing, secondsSinceLastData: age === null ? null : Math.round(age), collectorAlive: age !== null && age < config.staleSeconds });
    } catch (e) {
      const missing = e.code === '42P01' ? await missingObjects(pool).catch(() => []) : [];       // meter_latest itself is missing
      res.status(503).json({ ok: false, database: e.code === '42P01', schemaOk: false, missing, error: e.message });
    }
  }));

  const auth = makeAuth({ pool, config });
  app.use('/api/auth', auth.router);
  app.use('/api', auth.required);
  const ctx = { pool, config, auth };
  app.use('/api', require('./routes/live')(ctx));
  app.use('/api', require('./routes/dashboard')(ctx));
  app.use('/api', require('./routes/batches')(ctx));
  app.use('/api', require('./routes/reports')(ctx));
  app.use('/api', require('./routes/alarms')(ctx));
  app.use('/api', require('./routes/admin')(ctx));
  app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

  // The built React UI (copied to backend/public) is served by the same server.
  if (fs.existsSync(path.join(config.staticDir, 'index.html'))) {
    app.use(express.static(config.staticDir, { index: false, maxAge: '1h' }));
    app.get('*', (req, res) => res.sendFile(path.join(config.staticDir, 'index.html')));
  }
  app.use(errorHandler);
  return app;
}
module.exports = { createApp };
