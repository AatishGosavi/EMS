'use strict';
// The database objects the application needs (the same list as database/ems_check.sql).
const EXPECTED = [
  ['table', 'areas'], ['table', 'meters'], ['table', 'meter_latest'], ['table', 'readings'], ['table', 'app_settings'],
  ['continuous aggregate', 'readings_15min'], ['continuous aggregate', 'readings_daily'], ['view', 'plant_15min'], ['view', 'plant_daily'],
  ['table', 'recipes'], ['table', 'batches'], ['view', 'v_batches'], ['function', 'batch_start'], ['function', 'batch_end'],
  ['table', 'report_fields'], ['table', 'report_dimensions'], ['table', 'report_templates'], ['function', 'run_report'],
  ['table', 'users'], ['table', 'user_sessions'], ['table', 'audit_log'], ['function', 'audit_row_change'],
  ['table', 'alarm_rules'], ['table', 'alarm_events'], ['view', 'v_alarms'], ['function', 'alarm_raise'],
  ['table', 'tariffs'], ['table', 'tariff_periods'], ['function', 'energy_cost'],
];
async function missingObjects(pool) {
  const { rows } = await pool.query(`SELECT e.name FROM unnest($1::text[], $2::text[]) AS e(kind, name)
    WHERE NOT (CASE WHEN e.kind = 'function' THEN EXISTS (SELECT 1 FROM pg_proc WHERE proname = e.name) ELSE to_regclass('public.' || e.name) IS NOT NULL END)`,
  [EXPECTED.map((e) => e[0]), EXPECTED.map((e) => e[1])]);
  return rows.map((r) => r.name);
}
module.exports = { EXPECTED, missingObjects };
