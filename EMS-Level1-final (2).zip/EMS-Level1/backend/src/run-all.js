'use strict';
// Development helper: starts the collector and the API together. In production run them as two separate services.
const { spawn } = require('child_process');
const path = require('path');
const sim = process.argv.includes('--sim') ? ['--sim'] : [];
const run = (name, file, args = []) => {
  const p = spawn(process.execPath, [path.join(__dirname, file), ...args], { stdio: 'inherit' });
  p.on('exit', (code) => { console.log(`[${name}] exited (${code})`); process.exit(code || 0); });
  return p;
};
const kids = [run('api', 'api/index.js'), run('collector', 'collector/index.js', sim)];
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => { kids.forEach((k) => k.kill(s)); });
