'use strict';
// Usage: npm run create-admin -- <username> <password> [role]      (role: admin | engineer | viewer, default admin)
const bcrypt = require('bcryptjs');
const cfg = require('../config');
const { createPool } = require('../db');
(async () => {
  const [username, argPassword, role = 'admin'] = process.argv.slice(2);
  const password = argPassword || process.env.EMS_ADMIN_PASSWORD;
  if (!username || !password || password.length < 8) { console.error('Usage: npm run create-admin -- <username> <password (min 8 characters)> [admin|engineer|viewer]'); process.exit(1); }
  const pool = createPool(cfg.databaseUrl, 1);
  const hash = await bcrypt.hash(password, 12);
  await pool.query(`INSERT INTO users (username, display_name, password_hash, role) VALUES ($1, $1, $2, $3)
                    ON CONFLICT (lower(username)) DO UPDATE SET password_hash = EXCLUDED.password_hash, role = EXCLUDED.role, is_active = true, failed_logins = 0, locked_until = NULL`, [username, hash, role]);
  console.log(`User "${username}" saved with role ${role}.`);
  await pool.end();
})().catch((e) => { console.error(e.message); process.exit(1); });
