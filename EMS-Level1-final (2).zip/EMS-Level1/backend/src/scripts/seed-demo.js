'use strict';
// Creates a demo plant (10 areas, 20 meters, a main incomer) so the UI can be tried with the simulated PLC.
// Does nothing if meters already exist.  Usage: npm run seed:demo
const cfg = require('../config');
const { createPool, tx } = require('../db');

// [code, name, area, plcIndex, hasBatch, runSource, idleThresholdKw, isMain]
const METERS = [
  ['MX-101', 'Mixer M-101', 'Blending', 0, true, 'plc', 1], ['EX-204', 'Extruder E-204', 'Extrusion', 1, true, 'plc', 1],
  ['CP-A', 'Compressor A', 'Utilities', 2, false, 'kw', 15], ['CH-1', 'Chiller CH-1', 'Utilities', 3, false, 'kw', 15],
  ['HV-1', 'HVAC Hall 1', 'Facility', 4, false, 'kw', 5], ['PS-1', 'Pump Station', 'Utilities', 5, false, 'kw', 5],
  ['LT-1', 'Lighting Hall 1', 'Facility', 6, false, 'kw', 2], ['MX-102', 'Mixer M-102', 'Blending', 7, true, 'plc', 1],
  ['OV-301', 'Oven O-301', 'Curing', 8, true, 'plc', 1], ['MAIN', 'Main incomer', 'Plant', 9, false, 'kw', 1, true],
  ['PK-1', 'Packing Line 1', 'Packing', 10, false, 'kw', 5], ['PK-2', 'Packing Line 2', 'Packing', 11, false, 'kw', 5],
  ['BH-1', 'Boiler 1', 'Boiler House', 12, false, 'kw', 5], ['BH-2', 'Boiler Feed Pump', 'Boiler House', 13, false, 'kw', 5],
  ['CS-1', 'Cold Room 1', 'Cold Storage', 14, false, 'kw', 5], ['CS-2', 'Cold Room 2', 'Cold Storage', 15, false, 'kw', 5],
  ['WT-1', 'RO Plant', 'Water Treatment', 16, false, 'kw', 5], ['WT-2', 'Effluent Plant', 'Water Treatment', 17, false, 'kw', 5],
  ['WH-1', 'Warehouse Lighting', 'Warehouse', 18, false, 'kw', 2], ['WH-2', 'Warehouse Dock', 'Warehouse', 19, false, 'kw', 2],
];
(async () => {
  const pool = createPool(cfg.databaseUrl, 2);
  if ((await pool.query('SELECT 1 FROM meters LIMIT 1')).rowCount) { console.log('Meters already exist - nothing to do.'); return pool.end(); }
  await tx(pool, null, async (c) => {
    const areas = {}; let order = 0;
    for (const a of [...new Set(METERS.map((m) => m[2]))]) {
      areas[a] = (await c.query('INSERT INTO areas (name, sort_order) VALUES ($1, $2) RETURNING id', [a, order++])).rows[0].id;
    }
    let i = 0;
    for (const [code, name, area, idx, batch, run, thr, main] of METERS) {
      await c.query(`INSERT INTO meters (code, name, area_id, plc_index, has_batch, run_source, idle_threshold_kw, is_main, sort_order)
                     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`, [code, name, areas[area], idx, batch, run, thr, !!main, i++]);
    }
    await c.query("INSERT INTO recipes (id, name) VALUES (12, 'Base paste R-12') ON CONFLICT DO NOTHING");
  });
  console.log(`Demo plant created: ${METERS.length} meters. Start the simulated collector with: npm run collector:sim`);
  await pool.end();
})().catch((e) => { console.error(e.message); process.exit(1); });
