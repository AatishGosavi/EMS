'use strict';
const { Pool, types } = require('pg');
types.setTypeParser(1700, (v) => (v === null ? null : parseFloat(v)));   // numeric -> number
types.setTypeParser(20, (v) => (v === null ? null : parseInt(v, 10)));   // bigint  -> number
function createPool(url, max = 10) {
  const pool = new Pool({ connectionString: url, max });
  pool.on('error', (e) => console.error('[db] idle client error:', e.message));
  return pool;
}
// Run fn inside a transaction. If userId is given, the audit triggers record who made the change.
async function tx(pool, userId, fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    if (userId) await c.query("SELECT set_config('ems.user_id', $1, true)", [String(userId)]);
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) { await c.query('ROLLBACK').catch(() => {}); throw e; } finally { c.release(); }
}
module.exports = { createPool, tx };
