'use strict';
// Database helpers used when the collector starts.
async function loadMeters(pool) {
  const { rows } = await pool.query(`SELECT id, code, name, area_id, plc_index, has_batch, run_source, idle_threshold_kw, multiplier, is_main
                                     FROM meters WHERE is_active ORDER BY plc_index`);
  return rows.map((r) => ({ id: r.id, code: r.code, name: r.name, areaId: r.area_id, plcIndex: r.plc_index, hasBatch: r.has_batch,
    runSource: r.run_source, idleThresholdKw: r.idle_threshold_kw, multiplier: r.multiplier, isMain: r.is_main }));
}
const loadRules = async (pool) => (await pool.query('SELECT * FROM alarm_rules WHERE is_active')).rows;

// After a restart: continue energy deltas from the last stored counters and keep batches that are still open.
async function seedState(c, pool) {
  const last = await pool.query(`SELECT DISTINCT ON (meter_id) meter_id, ts, kwh_import, kwh_export FROM readings
                                 WHERE kwh_import IS NOT NULL AND ts > now() - interval '7 days' ORDER BY meter_id, ts DESC`);
  for (const r of last.rows) c.deltas.seed(r.meter_id, { ts: r.ts.getTime(), kwhImport: r.kwh_import, kwhExport: r.kwh_export });
  const open = await pool.query('SELECT meter_id, batch_no, recipe_id, target_qty, actual_qty, start_ts FROM batches WHERE end_ts IS NULL');
  for (const b of open.rows) c.batches.seed(b.meter_id, { batchNo: b.batch_no, recipeId: b.recipe_id || 0, targetQty: b.target_qty, actualQty: b.actual_qty, startTs: b.start_ts });
  return { deltas: last.rowCount, batches: open.rowCount };
}

module.exports = { loadMeters, loadRules, seedState };
