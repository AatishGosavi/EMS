'use strict';
const STATE = { DOWN: 0, IDLE: 1, RUNNING: 2 };
const LABEL = ['Down', 'Idle', 'Running'];
const SCALED = ['iL1', 'iL2', 'iL3', 'kw', 'kvar', 'kva', 'kwhImport', 'kwhExport'];

// meters.multiplier (CT/PT ratio) applies to current, power and energy; not to voltage, PF or frequency.
function applyMultiplier(meter, p) {
  if (!meter.multiplier || meter.multiplier === 1) return p;
  const o = { ...p };
  for (const k of SCALED) if (o[k] != null) o[k] *= meter.multiplier;
  return o;
}

// Status rule: Down = comm fail or UpdateCount frozen too long; Running = PLC run bit or kW >= threshold; else Idle.
class StateTracker {
  constructor(staleMs) { this.staleMs = staleMs; this.seen = new Map(); }
  evaluate(meter, p, now) {
    let s = this.seen.get(meter.id);
    if (!s || s.count !== p.updateCount) { s = { count: p.updateCount, changedAt: now }; this.seen.set(meter.id, s); }
    const stale = now - s.changedAt > this.staleMs;
    if (!p.commOk || stale) return { state: STATE.DOWN, stale };
    const run = meter.runSource === 'plc' ? p.running : (p.kw ?? 0) >= (meter.idleThresholdKw ?? 1);
    return { state: run ? STATE.RUNNING : STATE.IDLE, stale: false };
  }
}

module.exports = { STATE, LABEL, StateTracker, applyMultiplier };
