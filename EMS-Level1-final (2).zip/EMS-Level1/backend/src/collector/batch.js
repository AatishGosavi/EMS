'use strict';
// Turns the PLC batch fields into start / end events. Only called while the meter is NOT down,
// so a communication loss never closes a batch by mistake.
class BatchTracker {
  constructor() { this.cur = new Map(); this.seen = new Set(); }
  // Tell the tracker which batch the database already has open for a meter (call before the first poll).
  seed(meterId, batch) { this.cur.set(meterId, { ...batch }); }
  open(meterId) { return this.cur.get(meterId) || null; }

  update(meter, p, ts) {
    if (!meter.hasBatch) return [];
    const first = !this.seen.has(meter.id); this.seen.add(meter.id);
    const cur = this.cur.get(meter.id);
    const ev = [], mk = (type, b, recovered) => ({
      type, meterId: meter.id, batchNo: b.batchNo, recipeId: b.recipeId, targetQty: b.targetQty, actualQty: b.actualQty,
      ts, kwhImport: p.kwhImport, kwhExport: p.kwhExport, recovered: !!recovered,
    });
    const now = { batchNo: p.batchNo, recipeId: p.recipeId, targetQty: p.targetQty, actualQty: p.actualQty };
    if (p.batchRunning) {
      if (!cur) { this.cur.set(meter.id, { ...now, startTs: ts }); ev.push(mk('start', now, first)); }
      else if (now.batchNo && cur.batchNo && now.batchNo !== cur.batchNo) {
        ev.push(mk('end', cur, first)); this.cur.set(meter.id, { ...now, startTs: ts }); ev.push(mk('start', now, first));
      } else { // same batch continues: remember the latest known values (the PLC may blank them after the end)
        if (now.batchNo) cur.batchNo = now.batchNo;
        if (now.actualQty != null) cur.actualQty = now.actualQty;
        cur.recipeId = now.recipeId || cur.recipeId; cur.targetQty = now.targetQty ?? cur.targetQty;
      }
    } else if (cur) { ev.push(mk('end', cur, first)); this.cur.delete(meter.id); }
    return ev;
  }
}
module.exports = { BatchTracker };
