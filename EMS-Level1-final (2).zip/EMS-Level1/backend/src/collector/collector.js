'use strict';
const { EventEmitter } = require('events');
const { SIZE, FLOATS, parseMeter } = require('./layout');
const { STATE, StateTracker, applyMultiplier } = require('./tracker');
const { BatchTracker } = require('./batch');
const { DeltaTracker } = require('./delta');

const COLS = [...FLOATS, 'kwhImport', 'kwhExport'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const defaults = {
  plc: { host: '192.168.0.10', port: 102, rack: 0, slot: 1, timeout: 5000 },
  db: { number: 100 },
  pollMs: 5000, logMs: 60000, staleMs: 30000, readTimeoutMs: 4000, chunkBytes: 200,
  retry: { minMs: 2000, maxMs: 30000 },
};

// Events:
//   'poll'      (snapshots[])  every poll: { meterId, ts, state, stale, values|null, dataValid }  -> upsert meter_latest, push to UI
//   'batch'     (event)        batch start/end                                                    -> insert/update batches
//   'log'       (rows[])       once per logMs, aligned to the clock: one row per meter            -> insert into readings
//   'plc_error' (Error)        PLC unreachable / bad read (all meters are reported Down)
class Collector extends EventEmitter {
  constructor({ cfg = {}, meters, reader }) {
    super();
    this.cfg = { ...defaults, ...cfg, plc: { ...defaults.plc, ...cfg.plc }, retry: { ...defaults.retry, ...cfg.retry } };
    this.meters = meters; this.reader = reader;
    this.length = (Math.max(...meters.map((m) => m.plcIndex)) + 1) * SIZE;
    this.tracker = new StateTracker(this.cfg.staleMs);
    this.batches = new BatchTracker();
    this.deltas = new DeltaTracker(this.cfg.logMs);
    this.latest = new Map(); this.running = false;
  }
  // Replace the meter list at runtime (meters added/changed in the database).
  setMeters(list) {
    this.meters = list;
    this.length = (Math.max(...list.map((m) => m.plcIndex)) + 1) * SIZE;
    for (const id of [...this.latest.keys()]) if (!list.some((m) => m.id === id)) this.latest.delete(id);
    if (this.reader.setMeters) this.reader.setMeters(list);
  }
  start() { this.running = true; this._scheduleLog(); this.done = this._loop(); return this; }
  async stop() { this.running = false; clearTimeout(this.logTimer); await this.done; await this.reader.close(); }

  async _loop() {
    let wait = this.cfg.retry.minMs;
    while (this.running) {
      const t0 = Date.now();
      const ok = await this._pollOnce().catch((e) => { this.emit('fault', e); return false; });
      if (ok) { wait = this.cfg.retry.minMs; await sleep(Math.max(0, this.cfg.pollMs - (Date.now() - t0))); }
      else { await sleep(wait); wait = Math.min(wait * 2, this.cfg.retry.maxMs); }
    }
  }

  async _pollOnce() {
    const ts = new Date();
    let buf;
    try { buf = await this.reader.readBlock(this.cfg.db.number, this.length); }
    catch (err) {
      this.emit('plc_error', err);
      for (const m of this.meters) this.latest.set(m.id, { meterId: m.id, ts, state: STATE.DOWN, stale: false, values: null, dataValid: false });
      this.emit('poll', [...this.latest.values()]);
      return false;
    }
    for (const m of this.meters) {
      const p = applyMultiplier(m, parseMeter(buf, m.plcIndex * SIZE));
      const { state, stale } = this.tracker.evaluate(m, p, ts.getTime());
      if (state !== STATE.DOWN) for (const ev of this.batches.update(m, p, ts)) this.emit('batch', ev);
      this.latest.set(m.id, { meterId: m.id, ts, state, stale, values: state === STATE.DOWN ? null : p, dataValid: p.dataValid });
    }
    this.emit('poll', [...this.latest.values()]);
    return true;
  }

  _scheduleLog() {
    const ms = this.cfg.logMs, next = Math.ceil((Date.now() + 1) / ms) * ms;
    this.logTimer = setTimeout(() => { this._log(new Date(next)); if (this.running) this._scheduleLog(); }, next - Date.now());
  }
  _log(ts) {
    const rows = [];
    for (const m of this.meters) {
      const s = this.latest.get(m.id); if (!s) continue;
      const v = s.values, d = this.deltas.next(m.id, ts.getTime(), v?.kwhImport ?? null, v?.kwhExport ?? null, !!v && s.dataValid);
      const row = { ts, meterId: m.id, state: s.state, kwhImportDelta: d.di, kwhExportDelta: d.de, quality: d.q };
      for (const k of COLS) row[k] = v ? v[k] : null;
      rows.push(row);
    }
    this.emit('log', rows);
  }
}
module.exports = { Collector, defaults };
