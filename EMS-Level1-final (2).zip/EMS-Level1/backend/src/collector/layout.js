'use strict';
// Byte layout of UDT_Meter (see EMS_PLC_Structures.scl). Offsets are relative to the start of one meter.
// S7 data is big-endian. If you change the UDT in TIA Portal, change ONLY this file.
const SIZE = 100;
const O = {
  status: 0, updateCount: 2,
  vL1: 4, vL2: 8, vL3: 12, iL1: 16, iL2: 20, iL3: 24,
  kw: 28, kvar: 32, kva: 36, pf: 40, freq: 44,
  kwhImport: 48, kwhExport: 56,
  batchStatus: 64, recipeId: 66, targetQty: 68, actualQty: 72, batchNo: 76, // String[20] = 22 bytes
};
const FLOATS = ['vL1', 'vL2', 'vL3', 'iL1', 'iL2', 'iL3', 'kw', 'kvar', 'kva', 'pf', 'freq'];
const BATCH_MAX = 20;

const rdF = (b, o) => { const v = b.readFloatBE(o); return Number.isFinite(v) ? v : null; };
const rdD = (b, o) => { const v = b.readDoubleBE(o); return Number.isFinite(v) ? v : null; };

function parseMeter(buf, base = 0) {
  const st = buf.readUInt16BE(base + O.status);
  const bs = buf.readUInt16BE(base + O.batchStatus);
  const n = Math.min(buf.readUInt8(base + O.batchNo + 1), buf.readUInt8(base + O.batchNo), BATCH_MAX);
  const p = {
    commOk: !!(st & 1), dataValid: !!(st & 2), running: !!(st & 4),
    updateCount: buf.readUInt16BE(base + O.updateCount),
  };
  for (const k of FLOATS) p[k] = rdF(buf, base + O[k]);
  p.kwhImport = rdD(buf, base + O.kwhImport);
  p.kwhExport = rdD(buf, base + O.kwhExport);
  p.batchRunning = !!(bs & 1);
  p.recipeId = buf.readInt16BE(base + O.recipeId);
  p.targetQty = rdF(buf, base + O.targetQty);
  p.actualQty = rdF(buf, base + O.actualQty);
  p.batchNo = buf.toString('latin1', base + O.batchNo + 2, base + O.batchNo + 2 + n).replace(/\0/g, '').trim();
  return p;
}

// Inverse of parseMeter (used by the simulator and the tests).
function encodeMeter(buf, base, m = {}) {
  buf.writeUInt16BE((m.commOk ? 1 : 0) | (m.dataValid ? 2 : 0) | (m.running ? 4 : 0), base + O.status);
  buf.writeUInt16BE((m.updateCount || 0) & 0xffff, base + O.updateCount);
  for (const k of FLOATS) buf.writeFloatBE(m[k] || 0, base + O[k]);
  buf.writeDoubleBE(m.kwhImport || 0, base + O.kwhImport);
  buf.writeDoubleBE(m.kwhExport || 0, base + O.kwhExport);
  buf.writeUInt16BE(m.batchRunning ? 1 : 0, base + O.batchStatus);
  buf.writeInt16BE(m.recipeId || 0, base + O.recipeId);
  buf.writeFloatBE(m.targetQty || 0, base + O.targetQty);
  buf.writeFloatBE(m.actualQty || 0, base + O.actualQty);
  const s = String(m.batchNo || '').slice(0, BATCH_MAX);
  buf.writeUInt8(BATCH_MAX, base + O.batchNo);
  buf.writeUInt8(s.length, base + O.batchNo + 1);
  buf.write(s, base + O.batchNo + 2, 'latin1');
}

module.exports = { SIZE, O, FLOATS, parseMeter, encodeMeter };
