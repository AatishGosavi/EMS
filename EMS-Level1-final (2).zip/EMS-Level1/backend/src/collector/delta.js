'use strict';
// Energy consumed since the previous logged sample. quality bits: 1 = counter reset, 2 = gap (data missing in between), 4 = invalid/no data.
class DeltaTracker {
  constructor(logMs) { this.logMs = logMs; this.last = new Map(); }
  // Seed with the last stored counters from the database after a restart.
  seed(meterId, { ts, kwhImport, kwhExport }) { this.last.set(meterId, { ts, i: kwhImport, e: kwhExport ?? 0 }); }
  next(meterId, ts, imp, exp, valid) {
    if (!valid || imp == null) return { di: null, de: null, q: 4 };
    let q = 0, di = 0, de = 0;
    const p = this.last.get(meterId);
    if (p) {
      if (ts - p.ts > 3 * this.logMs) q |= 2;
      di = imp - p.i; de = (exp ?? 0) - p.e;
      if (di < 0) { di = 0; q |= 1; }
      if (de < 0) { de = 0; q |= 1; }
    }
    this.last.set(meterId, { ts, i: imp, e: exp ?? 0 });
    return { di, de, q };
  }
}
module.exports = { DeltaTracker };
