'use strict';
// Stores what the collector emits: live values, one logged row per meter per minute, batch events.
// All writes run one after another (so batch start/end stay in order). Logged rows and batch events that
// cannot be stored (database down) are kept in memory and retried, so a short database outage loses nothing.
const SNAKE = { vL1: 'v_l1', vL2: 'v_l2', vL3: 'v_l3', iL1: 'i_l1', iL2: 'i_l2', iL3: 'i_l3', kw: 'kw', kvar: 'kvar', kva: 'kva',
  pf: 'pf', freq: 'freq', kwhImport: 'kwh_import', kwhExport: 'kwh_export' };
const VAL = Object.values(SNAKE);
const TYPES = VAL.map((c) => `${c} ${c.startsWith('kwh') ? 'double precision' : 'real'}`).join(', ');
const vals = (v) => { const o = {}; for (const [c, s] of Object.entries(SNAKE)) o[s] = v ? v[c] : null; return o; };

const LATEST_SQL = `
  INSERT INTO meter_latest (meter_id, ts, state, ${VAL.join(', ')}, batch_running, batch_no, recipe_id)
  SELECT x.meter_id, x.ts, x.state, ${VAL.map((c) => 'x.' + c).join(', ')}, x.batch_running, x.batch_no, x.recipe_id
  FROM jsonb_to_recordset($1::jsonb) AS x(meter_id int, ts timestamptz, state smallint, ${TYPES}, batch_running boolean, batch_no text, recipe_id int)
  ON CONFLICT (meter_id) DO UPDATE SET ts = EXCLUDED.ts, state = EXCLUDED.state,
    ${[...VAL, 'batch_running', 'batch_no', 'recipe_id'].map((c) => `${c} = EXCLUDED.${c}`).join(', ')}`;

const LOG_SQL = `
  INSERT INTO readings (ts, meter_id, state, ${VAL.join(', ')}, kwh_import_delta, kwh_export_delta, quality)
  SELECT x.ts, x.meter_id, x.state, ${VAL.map((c) => 'x.' + c).join(', ')}, x.kwh_import_delta, x.kwh_export_delta, x.quality
  FROM jsonb_to_recordset($1::jsonb) AS x(ts timestamptz, meter_id int, state smallint, ${TYPES},
       kwh_import_delta double precision, kwh_export_delta double precision, quality smallint)
  ON CONFLICT (meter_id, ts) DO NOTHING`;

class Writer {
  constructor(pool, { log = console, alarms = null, maxPendingLogs = 1440 } = {}) {
    this.pool = pool; this.log = log; this.alarms = alarms; this.maxPendingLogs = maxPendingLogs;
    this.q = Promise.resolve(); this.logs = []; this.batches = []; this.busyLatest = false;
    this.retry = setInterval(() => { if (this.logs.length || this.batches.length) this._enqueue(() => this._flush()); }, 10000);
    this.retry.unref();
  }
  attach(c) {
    c.on('poll', (s) => this.latest(s));
    c.on('log', (r) => this.logRows(r));
    c.on('batch', (e) => this.batch(e));
    c.on('plc_error', (e) => this.log.error(`[collector] PLC error: ${e.message}`));
    return this;
  }
  _enqueue(fn) { this.q = this.q.then(fn).catch((e) => this.log.error('[writer]', e.message)); return this.q; }

  // Live values: replaces the row of each meter in meter_latest and tells the API (NOTIFY) that new data is there.
  latest(snaps) {
    if (this.busyLatest) return this.q;                  // database is slow: skip this frame, the next one is fresher anyway
    this.busyLatest = true;
    return this._enqueue(async () => {
      try {
        const rows = snaps.map((s) => {
          const v = s.values, on = !!(v && v.batchRunning);
          return { meter_id: s.meterId, ts: s.ts, state: s.state, ...vals(v), batch_running: on, batch_no: on ? v.batchNo : null, recipe_id: on ? (v.recipeId || null) : null };
        });
        await this.pool.query(LATEST_SQL, [JSON.stringify(rows)]);
        await this.pool.query("SELECT pg_notify('ems_live', '')");
        if (this.alarms) await this.alarms.evaluate(snaps, Date.now());
      } finally { this.busyLatest = false; }
    });
  }

  logRows(rows) {
    this.logs.push(rows);
    if (this.logs.length > this.maxPendingLogs) this.logs.shift();
    return this._enqueue(() => this._flush());
  }
  batch(e) { this.batches.push(e); return this._enqueue(() => this._flush()); }

  async _flush() {
    while (this.batches.length) {                         // batch events first, in order
      const e = this.batches[0];
      try {
        if (e.type === 'start') await this.pool.query('SELECT batch_start($1,$2,$3,$4,$5,$6,$7,$8)', [e.meterId, e.batchNo, e.recipeId || null, e.targetQty, e.ts, e.kwhImport, e.kwhExport, e.recovered]);
        else await this.pool.query('SELECT batch_end($1,$2,$3,$4,$5,$6)', [e.meterId, e.ts, e.actualQty, e.kwhImport, e.kwhExport, e.recovered]);
        this.batches.shift();
      } catch (err) { this.log.error('[writer] batch write failed, will retry:', err.message); return; }
    }
    while (this.logs.length) {
      const rows = this.logs[0].map((r) => ({ ts: r.ts, meter_id: r.meterId, state: r.state, ...vals(r),
        kwh_import_delta: r.kwhImportDelta, kwh_export_delta: r.kwhExportDelta, quality: r.quality }));
      try { await this.pool.query(LOG_SQL, [JSON.stringify(rows)]); this.logs.shift(); }
      catch (err) { this.log.error('[writer] log write failed, will retry:', err.message); return; }
    }
  }
  async close() { clearInterval(this.retry); await this.q; await this._enqueue(() => this._flush()); }
}
module.exports = { Writer };
