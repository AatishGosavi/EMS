'use strict';
const { SIZE, encodeMeter } = require('./layout');

// Reader interface: async readBlock(db, length) -> Buffer, async close().
class Nodes7Reader {
  constructor(cfg, factory = () => new (require('nodes7'))({ silent: true })) {
    this.cfg = cfg; this.factory = factory; this.conn = null; this.key = null;
  }
  _connect() {
    return new Promise((resolve, reject) => {
      const c = this.factory(); let done = false;
      const fail = (e) => { if (done) return; done = true; try { c.dropConnection(() => {}); } catch (_) {} reject(e instanceof Error ? e : new Error(String(e))); };
      const t = setTimeout(() => fail(new Error('connect timeout')), (this.cfg.plc.timeout || 5000) + 1000);
      c.initiateConnection({ port: this.cfg.plc.port, host: this.cfg.plc.host, rack: this.cfg.plc.rack, slot: this.cfg.plc.slot, timeout: this.cfg.plc.timeout, debug: false }, (err) => {
        clearTimeout(t);
        if (err) return fail(err);
        if (done) return; done = true; this.conn = c; this.key = null; resolve();
      });
    });
  }
  async readBlock(db, length) {
    const key = db + ':' + length;
    if (this.conn && this.key && this.key !== key) await this.close();     // block size changed (meters added): start over
    if (!this.conn) await this._connect();
    const chunk = this.cfg.chunkBytes || 200, n = Math.ceil(length / chunk);
    if (!this.key) {                                                         // register the chunks once per connection
      const vars = {};
      for (let i = 0; i < n; i++) vars['c' + i] = `DB${db},BYTE${i * chunk}.${Math.min(chunk, length - i * chunk)}`;
      this.conn.setTranslationCB((tag) => vars[tag]);
      this.conn.addItems(Object.keys(vars));
      this.key = key;
    }
    try {
      const values = await new Promise((resolve, reject) => {
        const t = setTimeout(() => reject(new Error('read timeout')), this.cfg.readTimeoutMs || 4000);
        this.conn.readAllItems((bad, v) => { clearTimeout(t); bad ? reject(new Error('PLC returned bad quality')) : resolve(v); });
      });
      const parts = [];
      for (let i = 0; i < n; i++) {
        const v = values['c' + i];
        if (v === undefined) throw new Error('missing chunk ' + i);
        parts.push(Buffer.from(Array.isArray(v) ? v : [v]));
      }
      const buf = Buffer.concat(parts);
      if (buf.length !== length) throw new Error(`expected ${length} bytes, got ${buf.length}`);
      return buf;
    } catch (e) { await this.close(); throw e; }                             // next call reconnects from scratch
  }
  close() {
    const c = this.conn; this.conn = null; this.key = null;
    return new Promise((res) => { if (!c) return res(); try { c.dropConnection(() => res()); } catch (_) { res(); } setTimeout(res, 500); });
  }
}

// Simulated PLC: builds the same byte layout the real DB has, so everything can be tried without hardware.
class SimReader {
  constructor(meters) {
    this.meters = meters; this.t0 = Date.now(); this.last = Date.now(); this.kwh = new Map(); this.count = 0;
    this.base = [210, 380, 9, 240, 118, 22, 60, 95];     // kW by plcIndex; other indexes get a value derived from the index
  }
  setMeters(list) { this.meters = list; }
  async readBlock(db, length) {
    const now = Date.now(), t = now - this.t0, dt = (now - this.last) / 3.6e6; this.last = now; this.count++;
    const buf = Buffer.alloc(length), kws = new Map();
    const isDown = (m) => m.plcIndex === 5;                                   // one meter with a communication fault
    for (const m of this.meters) {
      const b = this.base[m.plcIndex] ?? 30 + (m.plcIndex % 7) * 8;
      kws.set(m.id, isDown(m) ? 0 : b * (0.92 + 0.08 * Math.sin(t / 15000 + m.plcIndex)));
    }
    const total = this.meters.filter((m) => !m.isMain).reduce((s, m) => s + kws.get(m.id), 0);
    for (const m of this.meters) {
      const kw = m.isMain ? total : kws.get(m.id), down = isDown(m);
      const bOn = !!m.hasBatch && Math.floor(t / 60000) % 5 < 4;              // 4 min batch, 1 min pause
      this.kwh.set(m.id, (this.kwh.get(m.id) ?? 1000 * (m.plcIndex + 1)) + kw * dt);
      encodeMeter(buf, m.plcIndex * SIZE, {
        commOk: !down, dataValid: !down, running: m.runSource === 'plc' ? (m.hasBatch ? bOn : true) : false,
        updateCount: down ? 0 : this.count,
        vL1: 230, vL2: 231, vL3: 229, iL1: kw * 1.5, iL2: kw * 1.5, iL3: kw * 1.5, kw, kvar: kw * 0.3, kva: kw * 1.05, pf: 0.95, freq: 50,
        kwhImport: this.kwh.get(m.id),
        batchRunning: bOn, batchNo: bOn ? `B-${24000 + Math.floor(t / 300000)}-${m.plcIndex}` : '', recipeId: bOn ? 12 : 0,
        targetQty: bOn ? 500 : 0, actualQty: bOn ? (t % 300000) / 600 : 0,
      });
    }
    return buf;
  }
  async close() {}
}
module.exports = { Nodes7Reader, SimReader };
