'use strict';
// Collector process: reads the S7-1200 (or a simulated PLC with --sim) and stores everything in PostgreSQL.
// Usage: node src/collector/index.js [--sim]
const cfg = require('../config');
const { createPool } = require('../db');
const { Collector } = require('./collector');
const { Nodes7Reader, SimReader } = require('./readers');
const { Writer } = require('./writer');
const { AlarmEngine } = require('./alarms');
const { loadMeters, loadRules, seedState } = require('./boot');

const SIM = process.argv.includes('--sim');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(`[${new Date().toISOString()}] [collector]`, ...a);

async function main() {
  const pool = createPool(cfg.databaseUrl, 5);
  let meters = [];
  for (;;) {
    try { meters = await loadMeters(pool); } catch (e) { log(`database not reachable yet (${e.message}) - retrying in 10 s`); await sleep(10000); continue; }
    if (meters.length) break;
    log('no active meters in the database yet - waiting (add meters in the app, or run: npm run seed:demo)'); await sleep(10000);
  }
  const ccfg = { plc: cfg.plc, db: cfg.db, pollMs: cfg.pollMs, logMs: cfg.logMs, staleMs: cfg.staleSeconds * 1000 };
  const reader = SIM ? new SimReader(meters) : new Nodes7Reader({ plc: cfg.plc, chunkBytes: 200, readTimeoutMs: 4000 });
  const c = new Collector({ cfg: ccfg, meters, reader });
  log(SIM ? `simulated PLC, ${meters.length} meters` : `PLC ${cfg.plc.host} DB${cfg.db.number}, ${meters.length} meters`, JSON.stringify(await seedState(c, pool)));

  const engine = new AlarmEngine({
    rules: await loadRules(pool), meters,
    raise: async (rule, meter, ts, value, msg) => { await pool.query('SELECT alarm_raise($1,$2,$3,$4,$5)', [rule, meter, ts, value, msg]); log('ALARM', msg); },
    clear: async (rule, meter, ts) => { await pool.query('SELECT alarm_clear($1,$2,$3)', [rule, meter, ts]); },
  });
  engine.seedOpen((await pool.query('SELECT rule_id, meter_id FROM alarm_events WHERE cleared_at IS NULL')).rows);
  const writer = new Writer(pool, { alarms: engine, log: { error: (...a) => console.error(`[${new Date().toISOString()}]`, ...a) } }).attach(c);
  c.on('batch', (e) => log(`batch ${e.type} meter ${e.meterId} ${e.batchNo}${e.recovered ? ' (recovered)' : ''}`));

  // The API tells us (NOTIFY ems_config) when meters or alarm rules were changed: reload without a restart.
  const listener = await pool.connect();
  await listener.query('LISTEN ems_config');
  listener.on('notification', async () => {
    try {
      const m = await loadMeters(pool);
      if (m.length) { c.setMeters(m); engine.setMeters(m); }
      engine.setRules(await loadRules(pool));
      log(`configuration reloaded: ${m.length} meters`);
    } catch (e) { log('reload failed:', e.message); }
  });

  c.start();
  const stop = async () => { log('stopping...'); await c.stop(); await writer.close(); listener.release(); await pool.end(); process.exit(0); };
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}
main().catch((e) => { console.error(e); process.exit(1); });
