'use strict';
// Checks the alarm rules against every poll. A rule fires when its condition has been true for for_seconds,
// and clears when it is no longer true. Meters without data (down) neither raise nor clear measurement alarms.
const FIELD = { kw: 'kw', kvar: 'kvar', kva: 'kva', pf: 'pf', freq: 'freq', v_l1: 'vL1', v_l2: 'vL2', v_l3: 'vL3', i_l1: 'iL1', i_l2: 'iL2', i_l3: 'iL3' };
const CMP = { '>': (a, b) => a > b, '>=': (a, b) => a >= b, '<': (a, b) => a < b, '<=': (a, b) => a <= b, '=': (a, b) => a === b };

class AlarmEngine {
  constructor({ rules = [], meters = [], raise, clear, log = console }) {
    this.rules = rules; this.meters = new Map(meters.map((m) => [m.id, m])); this.raise = raise; this.clear = clear; this.log = log;
    this.st = new Map();                                                    // "rule:meter" -> { since, raised }
  }
  setRules(rules) { this.rules = rules; }
  setMeters(meters) { this.meters = new Map(meters.map((m) => [m.id, m])); }
  // Alarms that are already open in the database (after a restart), so they can still be cleared later.
  seedOpen(list) { for (const o of list) this.st.set(`${o.rule_id}:${o.meter_id}`, { since: Date.now(), raised: true }); }

  applies(rule, snap) {
    if (rule.scope === 'all') return true;
    if (rule.scope === 'meter') return rule.meter_id === snap.meterId;
    return this.meters.get(snap.meterId)?.areaId === rule.area_id;
  }
  async evaluate(snaps, now) {
    for (const rule of this.rules) {
      if (!rule.is_active) continue;
      for (const snap of snaps) {
        if (!this.applies(rule, snap)) continue;
        const value = rule.metric === 'state' ? snap.state : (snap.values ? snap.values[FIELD[rule.metric]] : null);
        if (value === null || value === undefined) continue;                // no data: keep the current situation
        const key = `${rule.id}:${snap.meterId}`, hit = CMP[rule.operator](value, rule.threshold);
        let s = this.st.get(key);
        if (hit) {
          if (!s) { s = { since: now, raised: false }; this.st.set(key, s); }
          if (!s.raised && now - s.since >= rule.for_seconds * 1000) {
            const m = this.meters.get(snap.meterId);
            await this.raise(rule.id, snap.meterId, new Date(now), value,
              `${rule.name}: ${m ? m.name : 'meter ' + snap.meterId} ${rule.metric} ${rule.operator} ${rule.threshold} (value ${Math.round(value * 100) / 100})`);
            s.raised = true;
          }
        } else if (s) {
          if (s.raised) await this.clear(rule.id, snap.meterId, new Date(now));
          this.st.delete(key);
        }
      }
    }
  }
}
module.exports = { AlarmEngine };
