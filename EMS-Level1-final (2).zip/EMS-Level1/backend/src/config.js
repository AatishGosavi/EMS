'use strict';
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env'), quiet: true });
const e = process.env;
const config = {
  databaseUrl: e.DATABASE_URL || 'postgres://postgres:postgres@localhost:5432/ems',
  port: +e.PORT || 3000,
  jwtSecret: e.JWT_SECRET || 'dev-only-change-me-dev-only-change-me',
  accessTtlMin: 15,
  refreshTtlDays: 14,
  staleSeconds: +e.STALE_SECONDS || 30,
  plc: { host: e.PLC_HOST || '192.168.0.10', port: +e.PLC_PORT || 102, rack: +(e.PLC_RACK ?? 0), slot: +(e.PLC_SLOT ?? 1), timeout: 5000 },
  db: { number: +e.PLC_DB || 100 },
  pollMs: +e.POLL_MS || 5000,
  logMs: +e.LOG_MS || 60000,
  staticDir: e.STATIC_DIR || path.join(__dirname, '..', 'public'),
};
if (e.NODE_ENV === 'production' && (!e.JWT_SECRET || e.JWT_SECRET.length < 32)) {
  throw new Error('JWT_SECRET (at least 32 characters) must be set in production');
}
module.exports = config;
