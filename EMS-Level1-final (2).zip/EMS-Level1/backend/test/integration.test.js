'use strict';
// Integration tests against a REAL PostgreSQL + TimescaleDB database (schema installed with ems_install.sql).
// Run:  TEST_DATABASE_URL=postgres://user:pass@localhost:5432/ems_test npm test
// WARNING: the tables of that database are emptied. The database name must contain "test".
const test = require('node:test');
const { after } = test;
const assert = require('node:assert/strict');
const http = require('http');
const path = require('path');
const { execFileSync } = require('child_process');

const TEST_URL = process.env.TEST_DATABASE_URL;
if (!TEST_URL || !/test/i.test(TEST_URL.split('/').pop())) {
  test('integration tests skipped (set TEST_DATABASE_URL to an empty database whose name contains "test")', { skip: true }, () => {});
} else {
  process.env.DATABASE_URL = TEST_URL;
  process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-123';
  integration();
}

function integration() {
  const WebSocket = require('ws');
  const ExcelJS = require('exceljs');
  const config = require('../src/config');
  const { createPool } = require('../src/db');
  const { createApp } = require('../src/api/app');
  const { attachWs } = require('../src/api/ws');
  const { fetchLive } = require('../src/api/routes/live');
  const { Collector } = require('../src/collector/collector');
  const { SimReader } = require('../src/collector/readers');
  const { Writer } = require('../src/collector/writer');
  const { AlarmEngine } = require('../src/collector/alarms');
  const boot = require('../src/collector/boot');

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const pool = createPool(TEST_URL, 5);
  let server, wsServer, base, today; const tok = {};

  const call = async (method, url, body, token) => {
    const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const text = await r.text(); let json; try { json = JSON.parse(text); } catch (_) {}
    return { status: r.status, json, text, headers: r.headers };
  };
  const login = async (username, password) => (await call('POST', '/api/auth/login', { username, password })).json;

  async function runCollector(ms, { alarms = false } = {}) {
    const meters = await boot.loadMeters(pool);
    const c = new Collector({ cfg: { pollMs: 40, logMs: 250, staleMs: 30000 }, meters, reader: new SimReader(meters) });
    await boot.seedState(c, pool);
    let engine = null;
    if (alarms) {
      engine = new AlarmEngine({ rules: await boot.loadRules(pool), meters,
        raise: (r, m, ts, v, msg) => pool.query('SELECT alarm_raise($1,$2,$3,$4,$5)', [r, m, ts, v, msg]),
        clear: (r, m, ts) => pool.query('SELECT alarm_clear($1,$2,$3)', [r, m, ts]) });
      engine.seedOpen((await pool.query('SELECT rule_id, meter_id FROM alarm_events WHERE cleared_at IS NULL')).rows);
    }
    const w = new Writer(pool, { alarms: engine, log: { error: console.error } }).attach(c);
    c.start(); await sleep(ms); await c.stop(); await w.close();
  }

  after(async () => { if (wsServer) await wsServer.close(); if (server) server.close(); await pool.end(); });

  test('setup: empty tables, demo plant, first admin', async () => {
    await pool.query(`TRUNCATE alarm_events, alarm_rules, batches, meter_latest, readings, report_templates, tariff_periods, tariffs,
                      user_sessions, audit_log, recipes, users, meters, areas RESTART IDENTITY CASCADE`);
    await pool.query("CALL refresh_continuous_aggregate('readings_15min', NULL, NULL)");
    await pool.query("CALL refresh_continuous_aggregate('readings_daily', NULL, NULL)");
    const env = { ...process.env };
    execFileSync(process.execPath, [path.join(__dirname, '../src/scripts/seed-demo.js')], { env });
    execFileSync(process.execPath, [path.join(__dirname, '../src/scripts/create-admin.js'), 'admin', 'Admin-pass-1', 'admin'], { env });
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM meters')).rows[0].n, 20);
    today = (await pool.query("SELECT (now() AT TIME ZONE value)::date::text AS d FROM app_settings WHERE key = 'plant_timezone'")).rows[0].d;
    server = http.createServer(createApp({ pool, config }));
    wsServer = attachWs({ server, pool, config, fetchLive: () => fetchLive(pool, config.staleSeconds) });
    await new Promise((r) => server.listen(0, r)); base = `http://localhost:${server.address().port}`;
  });

  test('collector + writer: live values, logged rows, batches and restart without duplicates', async () => {
    await runCollector(1400);
    const q = async (s) => (await pool.query(s)).rows[0];
    assert.equal((await q('SELECT count(*)::int AS n FROM meter_latest')).n, 20);
    assert.ok((await q('SELECT count(*)::int AS n FROM readings')).n >= 20);
    assert.equal((await q('SELECT count(*)::int AS n FROM batches WHERE end_ts IS NULL')).n, 4);      // 4 meters carry batches
    const m = await q(`SELECT (SELECT kw FROM meter_latest l JOIN meters m ON m.id = l.meter_id WHERE m.is_main) AS main,
                              (SELECT sum(kw) FROM meter_latest l JOIN meters m ON m.id = l.meter_id WHERE NOT m.is_main) AS parts`);
    assert.ok(Math.abs(m.main - m.parts) / m.parts < 0.01);                                              // main incomer = sum of the others (sim)
    await runCollector(900);                                                                              // "restart"
    assert.equal((await q('SELECT count(*)::int AS n FROM batches')).n, 4);                              // no duplicate batches
    assert.equal((await q('SELECT count(*)::int AS n FROM batches WHERE end_ts IS NULL')).n, 4);
    const dup = await q('SELECT count(*)::int AS n FROM (SELECT meter_id, ts FROM readings GROUP BY 1, 2 HAVING count(*) > 1) x');
    assert.equal(dup.n, 0);
  });

  test('auth: login, wrong password, refresh rotation, logout, protected routes', async () => {
    assert.equal((await call('GET', '/api/live/meters')).status, 401);
    assert.equal((await call('POST', '/api/auth/login', { username: 'admin', password: 'nope' })).status, 401);
    const a = await login('ADMIN', 'Admin-pass-1');                                                      // user names are not case sensitive
    assert.ok(a.accessToken && a.refreshToken); assert.equal(a.user.role, 'admin'); tok.admin = a.accessToken;
    assert.equal((await call('GET', '/api/auth/me', null, tok.admin)).json.username, 'admin');
    const r1 = await call('POST', '/api/auth/refresh', { refreshToken: a.refreshToken });
    assert.equal(r1.status, 200); assert.notEqual(r1.json.refreshToken, a.refreshToken);
    assert.equal((await call('POST', '/api/auth/refresh', { refreshToken: a.refreshToken })).status, 401);   // old token is single-use
    await call('POST', '/api/auth/logout', { refreshToken: r1.json.refreshToken });
    assert.equal((await call('POST', '/api/auth/refresh', { refreshToken: r1.json.refreshToken })).status, 401);
    assert.equal((await call('GET', '/api/live/meters', null, 'garbage')).status, 401);
    assert.equal((await call('GET', '/api/health')).json.collectorAlive, true);
  });

  test('users: create roles, password rules, lockout, role enforcement', async () => {
    const mk = (username, role) => call('POST', '/api/users', { username, password: 'Start-pass-1', role, mustChangePassword: false }, tok.admin);
    assert.equal((await mk('eng', 'engineer')).status, 201); assert.equal((await mk('view', 'viewer')).status, 201); assert.equal((await mk('locky', 'viewer')).status, 201);
    assert.equal((await mk('ENG', 'viewer')).status, 409);                                              // duplicate user name (any case)
    assert.equal((await call('POST', '/api/users', { username: 'x', password: 'short' }, tok.admin)).status, 400);
    assert.equal((await call('POST', '/api/users', { username: 'y', password: 'long-enough-1', role: 'boss' }, tok.admin)).status, 400);
    tok.eng = (await login('eng', 'Start-pass-1')).accessToken; tok.view = (await login('view', 'Start-pass-1')).accessToken;
    for (let i = 0; i < 5; i++) assert.equal((await call('POST', '/api/auth/login', { username: 'locky', password: 'wrong' })).status, 401);
    assert.equal((await call('POST', '/api/auth/login', { username: 'locky', password: 'Start-pass-1' })).status, 423);   // locked even with the right password
    assert.equal((await call('GET', '/api/users', null, tok.view)).status, 403);
    assert.equal((await call('POST', '/api/areas', { name: 'X' }, tok.eng)).status, 403);
    assert.equal((await call('POST', '/api/alarm-rules', {}, tok.view)).status, 403);
    assert.equal((await call('GET', '/api/audit', null, tok.eng)).status, 403);
    const me = (await call('GET', '/api/auth/me', null, tok.admin)).json;
    assert.equal((await call('PATCH', `/api/users/${me.id}`, { isActive: false }, tok.admin)).status, 400);   // cannot lock yourself out
    const viewId = (await call('GET', '/api/users', null, tok.admin)).json.find((u) => u.username === 'view').id;
    assert.equal((await call('PATCH', `/api/users/${viewId}`, { password: 'Reset-pass-9' }, tok.admin)).status, 200);
    assert.equal((await call('POST', '/api/auth/login', { username: 'view', password: 'Start-pass-1' })).status, 401);
    tok.view = (await login('view', 'Reset-pass-9')).accessToken;
    assert.equal((await call('POST', '/api/auth/change-password', { currentPassword: 'wrong', newPassword: 'Another-pass-1' }, tok.eng)).status, 400);
    assert.equal((await call('POST', '/api/auth/change-password', { currentPassword: 'Start-pass-1', newPassword: 'Another-pass-1' }, tok.eng)).status, 200);
    assert.equal((await call('POST', '/api/auth/login', { username: 'eng', password: 'Another-pass-1' })).status, 200);
  });

  test('live meters and dashboard', async () => {
    await runCollector(600);                                                                              // fresh data (younger than 30 s)
    const live = (await call('GET', '/api/live/meters', null, tok.view)).json;
    assert.equal(live.length, 20);
    const by = (n) => live.find((m) => m.name === n);
    assert.equal(by('Pump Station').status, 'Down'); assert.equal(by('Pump Station').kw, null);          // communication fault: no values shown
    assert.equal(by('Compressor A').status, 'Idle'); assert.equal(by('Chiller CH-1').status, 'Running');
    assert.ok(by('Mixer M-101').batch && /^B-24000-0/.test(by('Mixer M-101').batch.no)); assert.equal(by('Chiller CH-1').batch, null);
    assert.ok(live.every((m) => typeof m.energyToday === 'number'));
    assert.equal(live[0].area, 'Blending');                                                               // areas follow their sort order
    const d = (await call('GET', '/api/dashboard', null, tok.view)).json;
    assert.equal(d.usesMainMeter, true); assert.ok(d.plantKwNow > 1000);
    assert.equal(d.metersTotal, 19); assert.equal(d.metersOnline, 18); assert.equal(d.batchesRunning, 4);
    assert.ok(Array.isArray(d.trend.today) && Array.isArray(d.trend.yesterday) && d.trend.bucketMinutes === 30);
    assert.ok(d.areaEnergyToday.every((a) => a.area !== 'Plant') && d.energyTodayKwh >= 0 && d.peakDemandKw > 0);
    const id = by('Mixer M-101').id;
    const t = (await call('GET', `/api/meters/${id}/trend`, null, tok.view)).json;
    assert.equal(t.resolution, 'minute'); assert.ok(t.rows.length > 5);
    assert.equal((await call('GET', `/api/meters/${id}/trend?from=2020-01-01T00:00:00Z&to=2020-01-01T00:00:00Z`, null, tok.view)).status, 400);
  });

  test('batches: list, detail, completed batch', async () => {
    const run = (await call('GET', '/api/batches?status=running', null, tok.view)).json;
    assert.equal(run.length, 4); assert.ok(run.every((b) => b.status === 'running' && b.kwhImport >= 0));
    const first = run.find((b) => b.meterName === 'Mixer M-101');
    await pool.query('SELECT batch_end($1, now(), 480, 5000, 0)', [first.meterId]);
    const done = (await call('GET', '/api/batches?status=completed', null, tok.view)).json;
    assert.equal(done.length, 1); assert.equal(done[0].actualQty, 480);
    const det = (await call('GET', `/api/batches/${done[0].id}`, null, tok.view)).json;
    assert.equal(det.batch.batchNo, first.batchNo); assert.ok(Array.isArray(det.curve)); assert.equal(det.previous, null);
    assert.equal((await call('GET', '/api/batches/999999', null, tok.view)).status, 404);
    assert.equal((await call('GET', '/api/batches?status=bogus', null, tok.view)).status, 400);
    assert.equal((await call('GET', '/api/batches?from=yesterday', null, tok.view)).status, 400);
    assert.equal((await call('GET', `/api/batches?from=${today}&to=${today}`, null, tok.view)).json.length, 4);
  });

  test('reports: run, export csv/xlsx, validation, templates and sharing', async () => {
    const meta = (await call('GET', '/api/reports/meta', null, tok.view)).json;
    assert.equal(meta.fields.length, 16); assert.ok(meta.dimensions.some((x) => x.code === 'month')); assert.equal(meta.meters.length, 20);
    const def = { groupBy: ['day'], range: { from: today, to: today }, fields: [{ code: 'energy_kwh' }, { code: 'kw_peak' }] };
    const run = (await call('POST', '/api/reports/run', { definition: def }, tok.view)).json;
    assert.deepEqual(run.columns.map((c) => c.key), ['day', 'energy_kwh_sum', 'kw_peak_max']); assert.equal(run.rows.length, 1); assert.equal(run.rows[0].day, today);
    const csv = await call('POST', '/api/reports/export', { definition: def, format: 'csv' }, tok.view);
    assert.equal(csv.status, 200); assert.match(csv.headers.get('content-disposition'), /\.csv/); assert.ok(csv.text.replace(/^\ufeff/, '').startsWith('Day,Energy consumed (kWh)'));
    const raw = new Uint8Array(await (await fetch(base + '/api/reports/export', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + tok.view }, body: JSON.stringify({ definition: def, format: 'csv' }) })).arrayBuffer());
    assert.deepEqual([...raw.slice(0, 3)], [0xef, 0xbb, 0xbf]);                                          // BOM so Excel opens it as UTF-8
    const x = await fetch(base + '/api/reports/export', { method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + tok.view }, body: JSON.stringify({ definition: def, format: 'xlsx' }) });
    const wb = new ExcelJS.Workbook(); await wb.xlsx.load(Buffer.from(await x.arrayBuffer()));
    assert.equal(wb.getWorksheet('Report').getRow(1).getCell(1).value, 'Day'); assert.equal(wb.getWorksheet('Report').rowCount, 2);
    const bad = async (d) => (await call('POST', '/api/reports/run', { definition: d }, tok.view));
    assert.equal((await bad({ ...def, fields: [{ code: 'nope' }] })).status, 400);
    assert.equal((await bad({ ...def, fields: [{ code: 'energy_kwh', agg: 'avg' }] })).status, 400);
    assert.equal((await bad({ ...def, groupBy: ['day; DROP TABLE meters'] })).status, 400);
    assert.equal((await bad({ ...def, range: { from: today } })).status, 400);
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM meters')).rows[0].n, 20);              // still there
    // templates
    assert.equal((await call('POST', '/api/reports/templates', { name: 'Mine', definition: def }, tok.view)).status, 201);
    assert.equal((await call('POST', '/api/reports/templates', { name: 'Shared by viewer', definition: def, isShared: true }, tok.view)).status, 403);
    assert.equal((await call('POST', '/api/reports/templates', { name: 'Broken', definition: { ...def, fields: [{ code: 'x' }] } }, tok.eng)).status, 400);
    const sh = await call('POST', '/api/reports/templates', { name: 'Team report', definition: def, isShared: true }, tok.eng);
    assert.equal(sh.status, 201);
    const seen = (await call('GET', '/api/reports/templates', null, tok.view)).json.map((t) => t.name).sort();
    assert.deepEqual(seen, ['Mine', 'Team report']);
    assert.equal((await call('PUT', `/api/reports/templates/${sh.json.id}`, { name: 'Hijack' }, tok.view)).status, 403);
    assert.equal((await call('PUT', `/api/reports/templates/${sh.json.id}`, { name: 'Team report v2' }, tok.eng)).status, 200);
    assert.equal((await call('DELETE', `/api/reports/templates/${sh.json.id}`, null, tok.admin)).status, 200);   // admin may delete any
  });

  test('admin: meters, audit trail, areas, recipes, tariffs and cost', async () => {
    const meters = (await call('GET', '/api/meters', null, tok.view)).json, m1 = meters.find((m) => m.code === 'MX-101');
    assert.equal((await call('PATCH', `/api/meters/${m1.id}`, { name: 'Mixer M-101 (renamed)' }, tok.view)).status, 403);
    assert.equal((await call('PATCH', `/api/meters/${m1.id}`, { name: 'Mixer M-101 (renamed)', multiplier: 2 }, tok.admin)).status, 200);
    const dup = await call('PATCH', `/api/meters/${m1.id}`, { plcIndex: 1 }, tok.admin);
    assert.equal(dup.status, 409); assert.match(dup.json.error, /PLC index/);
    assert.equal((await call('PATCH', `/api/meters/${m1.id}`, { plcIndex: 80 }, tok.admin)).status, 400);
    assert.equal((await call('PATCH', `/api/meters/${m1.id}`, { runSource: 'magic' }, tok.admin)).status, 400);
    const nm = await call('POST', '/api/meters', { code: 'NEW-1', name: 'New meter', areaId: m1.areaId, plcIndex: 25 }, tok.admin);
    assert.equal(nm.status, 201); assert.equal(nm.json.runSource, 'kw');
    const audit = (await call('GET', '/api/audit?entity=meters', null, tok.admin)).json;
    const upd = audit.find((a) => a.action === 'UPDATE');
    assert.equal(upd.username, 'admin'); assert.equal(upd.details.name.new, 'Mixer M-101 (renamed)'); assert.equal(upd.details.multiplier.new, 2);
    const area = await call('POST', '/api/areas', { name: 'Test area' }, tok.admin); assert.equal(area.status, 201);
    assert.equal((await call('DELETE', `/api/areas/${m1.areaId}`, null, tok.admin)).status, 400);        // still has meters
    assert.equal((await call('DELETE', `/api/areas/${area.json.id}`, null, tok.admin)).status, 200);
    assert.equal((await call('PUT', '/api/recipes/12', { name: 'Base paste (renamed)' }, tok.eng)).status, 200);
    assert.equal((await call('PUT', '/api/recipes/12', { name: 'x' }, tok.view)).status, 403);
    const tariff = await call('POST', '/api/tariffs', { name: 'Industrial', validFrom: '2026-01-01', defaultRatePerKwh: 6, currency: 'INR',
      periods: [{ name: 'Peak', startTime: '18:00', endTime: '22:00', ratePerKwh: 9 }] }, tok.admin);
    assert.equal(tariff.status, 201); assert.equal(tariff.json.periods.length, 1); assert.equal(tariff.json.periods[0].startTime, '18:00');
    const cost = await call('GET', `/api/reports/cost?from=${today}&to=${today}`, null, tok.view);
    assert.equal(cost.status, 200); assert.ok(Array.isArray(cost.json) && cost.json.every((c) => c.cost === null || c.cost >= 0));
    assert.equal((await call('GET', '/api/reports/cost?from=bad&to=bad', null, tok.view)).status, 400);
    assert.equal((await call('GET', '/api/settings', null, tok.view)).json.plantTimezone.length > 2, true);
  });

  test('alarms: rule -> collector raises -> acknowledge', async () => {
    const ps = (await call('GET', '/api/meters', null, tok.view)).json.find((m) => m.code === 'PS-1');
    const rule = await call('POST', '/api/alarm-rules', { name: 'Pump station down', scope: 'meter', meterId: ps.id, metric: 'state', operator: '=', threshold: 0, forSeconds: 0, severity: 'critical' }, tok.eng);
    assert.equal(rule.status, 201);
    assert.equal((await call('POST', '/api/alarm-rules', { name: 'bad', scope: 'meter', metric: 'kw', operator: '>', threshold: 1 }, tok.eng)).status, 400);   // meter scope needs a meter
    await runCollector(700, { alarms: true });
    const act = (await call('GET', '/api/alarms?active=true', null, tok.view)).json;
    assert.equal(act.length, 1); assert.equal(act[0].ruleName, 'Pump station down'); assert.equal(act[0].meterName, 'Pump Station'); assert.equal(act[0].severity, 'critical');
    await runCollector(500, { alarms: true });                                                            // restart: still one open alarm
    assert.equal((await call('GET', '/api/alarms?active=true', null, tok.view)).json.length, 1);
    assert.equal((await call('POST', `/api/alarms/${act[0].id}/ack`, null, tok.view)).status, 403);
    assert.equal((await call('POST', `/api/alarms/${act[0].id}/ack`, null, tok.eng)).status, 200);
    assert.equal((await call('POST', `/api/alarms/${act[0].id}/ack`, null, tok.eng)).status, 409);
    assert.equal((await call('GET', '/api/alarms?active=true', null, tok.view)).json[0].acknowledgedBy, 'eng');
  });

  test('incomplete database setup gives a clear message (not "Internal error") and health says what is missing', async () => {
    const h = (await call('GET', '/api/health')).json; assert.equal(h.schemaOk, true); assert.deepEqual(h.missing, []);
    await pool.query('ALTER VIEW v_alarms RENAME TO v_alarms_off');
    try {
      const r = await call('GET', '/api/alarms', null, tok.view);
      assert.equal(r.status, 500); assert.match(r.json.error, /Database setup is incomplete/); assert.match(r.json.error, /v_alarms/);
      const h2 = await call('GET', '/api/health'); assert.equal(h2.json.schemaOk, false); assert.deepEqual(h2.json.missing, ['v_alarms']);
    } finally { await pool.query('ALTER VIEW v_alarms_off RENAME TO v_alarms'); }
    assert.equal((await call('GET', '/api/alarms', null, tok.view)).status, 200);
  });

  test('websocket: needs a valid token, sends live data on connect and when new data arrives', async () => {
    const url = `ws://localhost:${server.address().port}/ws`;
    await new Promise((resolve) => { const w = new WebSocket(url + '?token=garbage'); w.on('error', resolve); w.on('unexpected-response', (_, res) => { assert.equal(res.statusCode, 401); resolve(); }); });
    const msgs = []; const w = new WebSocket(url + '?token=' + tok.view);
    w.on('message', (d) => msgs.push(JSON.parse(d)));
    await new Promise((r) => w.on('open', r));
    for (let i = 0; i < 30 && !msgs.length; i++) await sleep(100);
    assert.equal(msgs[0].type, 'live'); assert.equal(msgs[0].meters.length, 21);                         // 20 demo meters + the one added in the admin test
    await sleep(300); await pool.query("SELECT pg_notify('ems_live', '')");
    for (let i = 0; i < 40 && msgs.length < 2; i++) await sleep(100);
    assert.ok(msgs.length >= 2, 'a second message should follow the NOTIFY');
    w.close();
  });
}
