'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { AlarmEngine } = require('../src/collector/alarms');

const mk = (rules, meters = [{ id: 1, name: 'Mixer', areaId: 10 }, { id: 2, name: 'Pump', areaId: 11 }]) => {
  const log = []; const e = new AlarmEngine({ rules, meters, raise: async (...a) => log.push(['raise', a[0], a[1], a[3]]), clear: async (...a) => log.push(['clear', a[0], a[1]]) });
  return { e, log };
};
const snap = (meterId, kw, state = 2) => ({ meterId, state, values: kw === null ? null : { kw } });

test('alarm: raises only after for_seconds, clears when condition ends', async () => {
  const { e, log } = mk([{ id: 1, is_active: true, scope: 'meter', meter_id: 1, metric: 'kw', operator: '>', threshold: 250, for_seconds: 60, name: 'Overload' }]);
  await e.evaluate([snap(1, 300)], 0);       assert.deepEqual(log, []);
  await e.evaluate([snap(1, 300)], 30000);   assert.deepEqual(log, []);
  await e.evaluate([snap(1, 310)], 61000);   assert.deepEqual(log, [['raise', 1, 1, 310]]);
  await e.evaluate([snap(1, 320)], 70000);   assert.equal(log.length, 1);                 // already raised: no duplicate
  await e.evaluate([snap(1, 100)], 80000);   assert.deepEqual(log[1], ['clear', 1, 1]);
  await e.evaluate([snap(1, 300)], 90000);   await e.evaluate([snap(1, 100)], 95000);     // short spike: nothing
  assert.equal(log.length, 2);
});

test('alarm: scopes (meter / area / all), state rule, no data does nothing', async () => {
  const { e, log } = mk([
    { id: 1, is_active: true, scope: 'area', area_id: 11, metric: 'state', operator: '=', threshold: 0, for_seconds: 0, name: 'Down' },
    { id: 2, is_active: true, scope: 'all', metric: 'kw', operator: '<', threshold: 5, for_seconds: 0, name: 'Low' },
    { id: 3, is_active: false, scope: 'all', metric: 'kw', operator: '>', threshold: 0, for_seconds: 0, name: 'Off' }]);
  await e.evaluate([snap(1, null, 0), snap(2, null, 0)], 1000);                           // both down, no values
  assert.deepEqual(log, [['raise', 1, 2, 0]]);                                            // only the area-11 meter, state alarm; kW rule ignores "no data"
  await e.evaluate([snap(2, null, 2)], 2000);                                              // pump back up -> state alarm clears
  assert.deepEqual(log[1], ['clear', 1, 2]);
  await e.evaluate([snap(1, 2)], 3000);                                                    // 2 kW < 5 -> Low raised for meter 1
  assert.deepEqual(log[2], ['raise', 2, 1, 2]);
});

test('alarm: seedOpen lets a restarted collector clear alarms that are already open', async () => {
  const { e, log } = mk([{ id: 1, is_active: true, scope: 'meter', meter_id: 1, metric: 'kw', operator: '>', threshold: 250, for_seconds: 0, name: 'O' }]);
  e.seedOpen([{ rule_id: 1, meter_id: 1 }]);
  await e.evaluate([snap(1, 300)], 1000);  assert.deepEqual(log, []);                     // still open: nothing new
  await e.evaluate([snap(1, 100)], 2000);  assert.deepEqual(log, [['clear', 1, 1]]);
});
