'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { SIZE, parseMeter, encodeMeter } = require('../src/collector/layout');
const { StateTracker, STATE, applyMultiplier } = require('../src/collector/tracker');
const { BatchTracker } = require('../src/collector/batch');
const { DeltaTracker } = require('../src/collector/delta');
const { Nodes7Reader, SimReader } = require('../src/collector/readers');
const { Collector } = require('../src/collector/collector');
const loadMeters = async () => { const m = (id, code, name, plcIndex, hasBatch, runSource, idleThresholdKw = 1, multiplier = 1) => ({ id, code, name, plcIndex, hasBatch, runSource, idleThresholdKw, multiplier }); return [m(1,'MX-101','Mixer M-101',0,true,'plc'), m(2,'EX-204','Extruder E-204',1,true,'plc'), m(3,'CP-A','Compressor A',2,false,'kw',15), m(4,'CH-1','Chiller CH-1',3,false,'kw',15), m(5,'HV-1','HVAC Hall 1',4,false,'kw',5), m(6,'PS-1','Pump Station',5,false,'kw',5)]; };

const base = { commOk: true, dataValid: true, running: false, updateCount: 1, kw: 100 };

test('layout: encode/parse round trip, incl. LReal and batch string', () => {
  const buf = Buffer.alloc(SIZE * 3), m = { ...base, running: true, vL1: 231.5, iL2: 12.25, kvar: -3.5, pf: -0.97, freq: 50.01,
    kwhImport: 123456789.125, kwhExport: 42.5, batchRunning: true, recipeId: -7, targetQty: 500, actualQty: 123.5, batchNo: 'B-24091' };
  encodeMeter(buf, SIZE * 2, m);                       // meter index 2 starts at byte 200
  const p = parseMeter(buf, SIZE * 2);
  for (const k of ['commOk', 'dataValid', 'running', 'updateCount', 'vL1', 'iL2', 'kvar', 'pf', 'freq', 'kwhImport', 'kwhExport', 'batchRunning', 'recipeId', 'targetQty', 'actualQty', 'batchNo'])
    typeof m[k] === 'number' ? assert.ok(Math.abs(p[k] - m[k]) < 1e-4, k) : assert.equal(p[k], m[k], k);   // Real = 32-bit float, so compare with tolerance
  assert.equal(parseMeter(buf, 0).commOk, false);       // untouched slot = down
});

test('layout: offsets match the UDT (spot check against the .scl comments)', () => {
  const buf = Buffer.alloc(SIZE); encodeMeter(buf, 0, { kw: 1, kwhImport: 2, batchNo: 'X' });
  assert.equal(buf.readFloatBE(28), 1); assert.equal(buf.readDoubleBE(48), 2); assert.equal(buf.readUInt8(76), 20); assert.equal(buf.readUInt8(77), 1);
});

test('state: down / running / idle and stale detection', () => {
  const t = new StateTracker(30000), plc = { id: 1, runSource: 'plc' }, kw = { id: 2, runSource: 'kw', idleThresholdKw: 15 };
  assert.equal(t.evaluate(plc, { ...base, commOk: false }, 0).state, STATE.DOWN);
  assert.equal(t.evaluate(plc, { ...base, running: true }, 1000).state, STATE.RUNNING);
  assert.equal(t.evaluate(plc, { ...base, running: false, updateCount: 3 }, 2000).state, STATE.IDLE);
  assert.equal(t.evaluate(kw, { ...base, kw: 20 }, 0).state, STATE.RUNNING);
  assert.equal(t.evaluate(kw, { ...base, kw: 5, updateCount: 2 }, 1000).state, STATE.IDLE);
  assert.equal(t.evaluate(kw, { ...base, kw: 5, updateCount: 2 }, 20000).state, STATE.IDLE);          // frozen, not stale yet
  const r = t.evaluate(kw, { ...base, kw: 50, updateCount: 2 }, 40000);                               // frozen > 30 s
  assert.equal(r.state, STATE.DOWN); assert.equal(r.stale, true);
  assert.equal(t.evaluate(kw, { ...base, kw: 50, updateCount: 3 }, 41000).state, STATE.RUNNING);      // counter moves again
});

test('multiplier scales current, power and energy only', () => {
  const o = applyMultiplier({ multiplier: 10 }, { vL1: 230, iL1: 1, kw: 2, pf: 0.9, kwhImport: 3, kwhExport: null });
  assert.deepEqual([o.vL1, o.iL1, o.kw, o.pf, o.kwhImport, o.kwhExport], [230, 10, 20, 0.9, 30, null]);
});

test('batch: start, continue, end (values blanked by PLC), change, recovery', () => {
  const b = new BatchTracker(), m = { id: 1, hasBatch: true }, T = (n) => new Date(n);
  const run = (no, qty) => ({ batchRunning: true, batchNo: no, recipeId: 12, targetQty: 500, actualQty: qty, kwhImport: 10 });
  let ev = b.update(m, run('B1', 10), T(1)); assert.deepEqual(ev.map((e) => e.type), ['start']); assert.equal(ev[0].recovered, true); // first sight = recovered
  assert.equal(b.update(m, run('B1', 250), T(2)).length, 0);
  ev = b.update(m, { batchRunning: false, batchNo: '', recipeId: 0, actualQty: 0, kwhImport: 20 }, T(3));
  assert.equal(ev[0].type, 'end'); assert.equal(ev[0].batchNo, 'B1'); assert.equal(ev[0].actualQty, 250);
  b.update(m, run('B2', 1), T(4)); ev = b.update(m, run('B3', 1), T(5));
  assert.deepEqual(ev.map((e) => e.type + e.batchNo), ['endB2', 'startB3']);
  assert.equal(b.update({ id: 9, hasBatch: false }, run('X', 1), T(6)).length, 0);
  const s = new BatchTracker(); s.seed(1, { batchNo: 'B1', startTs: T(0) });                // DB says B1 is open
  assert.equal(s.update(m, run('B1', 5), T(7)).length, 0);                                  // same batch: no event
  const s2 = new BatchTracker(); s2.seed(1, { batchNo: 'B1', startTs: T(0) });
  assert.deepEqual(s2.update(m, { batchRunning: false, batchNo: '' }, T(8)).map((e) => e.type), ['end']);
});

test('delta: normal, counter reset, gap, invalid', () => {
  const d = new DeltaTracker(60000);
  assert.deepEqual(d.next(1, 0, 100, 5, true), { di: 0, de: 0, q: 0 });
  assert.deepEqual(d.next(1, 60000, 101.5, 5, true), { di: 1.5, de: 0, q: 0 });
  assert.deepEqual(d.next(1, 120000, 3, 0, true), { di: 0, de: 0, q: 1 });                  // reset
  assert.equal(d.next(1, 600000, 10, 0, true).q, 2);                                        // 8 min gap
  assert.equal(d.next(1, 660000, null, null, false).q, 4);
  assert.equal(d.next(1, 720000, 12, 0, true).di, 2);                                       // delta continues from last valid
});

test('nodes7 reader: chunking, assembly, reconnect after error', async () => {
  const mem = Buffer.from(Array.from({ length: 450 }, (_, i) => i % 256));
  let conns = 0, failNext = false, items;
  const factory = () => { conns++; let tr;
    return { initiateConnection: (o, cb) => { assert.equal(o.rack, 0); assert.equal(o.slot, 1); setImmediate(cb); },
      setTranslationCB: (f) => { tr = f; }, addItems: (a) => { items = a.map(tr); },
      readAllItems: (cb) => { if (failNext) { failNext = false; return cb(true, {}); }
        const v = {}; for (const k of items.keys()) { const [, off, len] = /BYTE(\d+)\.(\d+)/.exec(items[k]); v['c' + k] = [...mem.subarray(+off, +off + +len)]; } cb(false, v); },
      dropConnection: (cb) => cb && cb() }; };
  const r = new Nodes7Reader({ plc: { host: 'x', port: 102, rack: 0, slot: 1, timeout: 100 }, chunkBytes: 200, readTimeoutMs: 500 }, factory);
  const buf = await r.readBlock(100, 450);
  assert.deepEqual(items, ['DB100,BYTE0.200', 'DB100,BYTE200.200', 'DB100,BYTE400.50']);
  assert.ok(buf.equals(mem));
  failNext = true; await assert.rejects(r.readBlock(100, 450), /bad quality/);
  assert.ok((await r.readBlock(100, 450)).equals(mem)); assert.equal(conns, 2);              // reconnected
});

test('collector with simulated PLC: states, log rows, batch events', async () => {
  const meters = await loadMeters(), c = new Collector({ cfg: { pollMs: 20, logMs: 100 }, meters, reader: new SimReader(meters) });
  const polls = [], logs = [], batches = [];
  c.on('poll', (s) => polls.push(s)); c.on('log', (r) => logs.push(r)); c.on('batch', (e) => batches.push(e));
  c.start(); while (!logs.length) await new Promise((r) => setTimeout(r, 20)); await c.stop();
  const st = Object.fromEntries(polls.at(-1).map((s) => [s.meterId, s.state]));
  assert.deepEqual(st, { 1: 2, 2: 2, 3: 1, 4: 2, 5: 2, 6: 0 });          // running x4 (incl. kW rule), compressor idle, pump station down
  assert.equal(logs[0].length, 6);
  const down = logs[0].find((r) => r.meterId === 6); assert.equal(down.state, 0); assert.equal(down.kw, null); assert.equal(down.quality, 4);
  assert.equal(logs[0].find((r) => r.meterId === 1).kwhImport > 0, true);
  assert.deepEqual(batches.map((e) => e.type), ['start', 'start']);       // two batch meters running
});

test('collector: PLC unreachable -> plc_error and all meters Down', async () => {
  const meters = await loadMeters(); let err = 0, snap;
  const c = new Collector({ cfg: { pollMs: 20, logMs: 1000, retry: { minMs: 10, maxMs: 20 } }, meters, reader: { readBlock: async () => { throw new Error('no route'); }, close: async () => {} } });
  c.on('plc_error', () => err++); c.on('poll', (s) => { snap = s; });
  c.start(); await new Promise((r) => setTimeout(r, 80)); await c.stop();
  assert.ok(err >= 2); assert.ok(snap.every((s) => s.state === 0 && s.values === null));
});
