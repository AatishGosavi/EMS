'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Writer } = require('../src/collector/writer');

const quiet = { error() {} };
const row = (id, kw) => ({ ts: new Date(), meterId: id, state: 2, kw, kwhImport: 1, kwhImportDelta: 0.1, kwhExportDelta: 0, quality: 0 });

test('writer: logged rows and batch events survive a database outage and are stored in order', async () => {
  const calls = []; let down = true;
  const pool = { query: async (sql, p) => { if (down) throw new Error('db down'); calls.push({ sql: sql.slice(0, 40).replace(/\s+/g, ' '), p }); return { rows: [] }; } };
  const w = new Writer(pool, { log: quiet });
  w.batch({ type: 'start', meterId: 1, batchNo: 'B1', recipeId: 12, targetQty: 5, ts: new Date(), kwhImport: 1, kwhExport: 0, recovered: false });
  w.logRows([row(1, 100)]);
  await w.q;
  assert.equal(calls.length, 0); assert.equal(w.batches.length, 1); assert.equal(w.logs.length, 1);   // nothing lost
  down = false;
  w.logRows([row(1, 101)]);                                                                            // next tick: everything is retried
  await w.close();
  assert.equal(w.batches.length + w.logs.length, 0);
  assert.match(calls[0].sql, /batch_start/);                                                           // batch first, then the rows in order
  assert.deepEqual(calls.slice(1).map((c) => JSON.parse(c.p[0]).map((r) => r.kw)), [[100], [101]]);
});

test('writer: log rows are idempotent (ON CONFLICT DO NOTHING) and pending queue is capped', async () => {
  const sqls = []; const pool = { query: async (sql) => { sqls.push(sql); throw new Error('down'); } };
  const w = new Writer(pool, { log: quiet, maxPendingLogs: 3 });
  for (let i = 0; i < 5; i++) w.logRows([row(1, i)]);
  await w.q; clearInterval(w.retry);
  assert.equal(w.logs.length, 3);                                                                      // oldest dropped, memory stays bounded
  assert.ok(sqls.every((s) => /ON CONFLICT \(meter_id, ts\) DO NOTHING/.test(s)));
});

test('writer: live frames are skipped while the previous one is still being written', async () => {
  let n = 0, release; const gate = new Promise((r) => { release = r; });
  const pool = { query: async () => { n++; await gate; return { rows: [] }; } };
  const w = new Writer(pool, { log: quiet }); const snap = [{ meterId: 1, ts: new Date(), state: 2, values: null }];
  w.latest(snap); w.latest(snap); w.latest(snap);
  release(); await w.close();
  assert.equal(n, 2);                                                                                  // upsert + NOTIFY of the first frame only
});
