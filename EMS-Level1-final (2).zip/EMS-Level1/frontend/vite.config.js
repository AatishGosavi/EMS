import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// In development the UI runs on :5173 and talks to the backend on :3000 through this proxy.
export default defineConfig({
  plugins: [react()],
  server: { proxy: { '/api': 'http://localhost:3000', '/ws': { target: 'ws://localhost:3000', ws: true } } },
});
