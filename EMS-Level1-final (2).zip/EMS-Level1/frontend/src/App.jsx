import { useEffect, useState } from 'react';
import { currentUser, logout, onUser, restore } from './api';
import { LiveProvider, useLive } from './live';
import Login from './components/Login';
import ChangePassword from './components/ChangePassword';
import Dashboard from './components/Dashboard';
import Meters from './components/Meters';
import Batches from './components/Batches';
import Reports from './components/Reports';
import Alarms from './components/Alarms';
import Settings from './components/Settings';
import { usePoll } from './hooks';
import { get } from './api';

const PAGES = [['dash', 'Dashboard', Dashboard], ['meters', 'Meters', Meters], ['batches', 'Batches', Batches], ['alarms', 'Alarms', Alarms], ['reports', 'Reports', Reports], ['settings', 'Settings', Settings, 'engineer']];
const RANK = { viewer: 1, engineer: 2, admin: 3 };

function Shell({ user, openPassword, dark, setDark }) {
  const [page, setPage] = useState('dash');
  const { meters, connected, loaded } = useLive();
  const pages = PAGES.filter((p) => !p[3] || RANK[user.role] >= RANK[p[3]]);
  const [, title, Page] = pages.find((p) => p[0] === page);
  const [aTick, setATick] = useState(0);
  useEffect(() => { const f = () => setATick((t) => t + 1); window.addEventListener('ems-alarms', f); return () => window.removeEventListener('ems-alarms', f); }, []);
  const { data: active } = usePoll(() => get('/api/alarms?active=true&limit=200'), 15000, [aTick]);
  const open = (active || []).filter((a) => !a.acknowledgedAt).length;
  const noData = loaded && meters.length > 0 && meters.every((m) => m.stale);
  return (
    <div className="app">
      <aside id="nav"><b>Plant Energy</b>
        {pages.map(([id, label]) => <button key={id} className={id === page ? 'on' : ''} onClick={() => setPage(id)}>{label}{id === 'alarms' && open > 0 && <span className="count" title="Unacknowledged active alarms">{open}</span>}</button>)}
      </aside>
      <main>
        <header><h1>{title}</h1>
          <span className="chip" title={connected ? 'Receiving live data' : 'Live connection lost, retrying'}><span className={`dot ${connected ? '' : 'down'}`} />{connected ? 'Live' : 'Offline'}</span>
          <span className="sp" />
          <span className="note">{user.displayName} · {user.role}</span>
          <button className="btn" onClick={() => setDark(!dark)}>Switch theme</button>
          <button className="btn" onClick={openPassword}>Password</button>
          <button className="btn" onClick={logout}>Sign out</button>
        </header>
        {noData && <div className="banner" role="alert">No fresh data from the collector. All meters are shown as Down until data arrives.</div>}
        <Page />
      </main>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(currentUser()), [ready, setReady] = useState(false), [pw, setPw] = useState(false);
  const [dark, setDark] = useState(() => window.matchMedia('(prefers-color-scheme: dark)').matches);
  useEffect(() => { document.documentElement.dataset.theme = dark ? 'dark' : 'light'; }, [dark]);
  useEffect(() => { const off = onUser(setUser); restore().finally(() => setReady(true)); return off; }, []);
  if (!ready) return <div className="center">Loading…</div>;
  if (!user) return <Login />;
  if (user.mustChangePassword || pw) return <ChangePassword forced={user.mustChangePassword} onDone={() => setPw(false)} />;
  return <LiveProvider><Shell user={user} openPassword={() => setPw(true)} dark={dark} setDark={setDark} /></LiveProvider>;
}
