import { createContext, useContext, useEffect, useState } from 'react';
import { get, liveUrl } from './api';

const Ctx = createContext({ meters: [], connected: false });
export const useLive = () => useContext(Ctx);

// Live meter values over a WebSocket (pushed when the collector stores new data), with REST as a fallback.
export function LiveProvider({ children }) {
  const [state, setState] = useState({ meters: [], connected: false, loaded: false });
  useEffect(() => {
    let ws, stop = false, timer, poll;
    const apply = (meters, connected) => setState((s) => ({ meters, connected: connected ?? s.connected, loaded: true }));
    get('/api/live/meters').then((m) => apply(m)).catch(() => {});
    async function connect() {
      try {
        ws = new WebSocket(await liveUrl());
        ws.onopen = () => setState((s) => ({ ...s, connected: true }));
        ws.onmessage = (e) => { const m = JSON.parse(e.data); if (m.type === 'live') apply(m.meters, true); };
        ws.onclose = () => { setState((s) => ({ ...s, connected: false })); if (!stop) timer = setTimeout(connect, 3000); };
        ws.onerror = () => ws.close();
      } catch (_) { timer = setTimeout(connect, 3000); }
    }
    connect();
    poll = setInterval(() => { if (ws && ws.readyState !== 1) get('/api/live/meters').then((m) => apply(m, false)).catch(() => {}); }, 5000);
    return () => { stop = true; clearTimeout(timer); clearInterval(poll); if (ws) ws.close(); };
  }, []);
  return <Ctx.Provider value={state}>{children}</Ctx.Provider>;
}
