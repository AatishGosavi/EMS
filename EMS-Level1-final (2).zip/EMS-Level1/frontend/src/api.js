// Thin client for the EMS backend: sign-in, automatic token refresh, JSON/blob requests, live WebSocket URL.
const REFRESH_KEY = 'ems.refresh';
let access = null, expiresAt = 0, me = null, refreshing = null;
const subs = new Set();
const emit = () => subs.forEach((f) => f(me));

export class ApiError extends Error { constructor(status, message) { super(message); this.status = status; } }
export const onUser = (f) => { subs.add(f); return () => subs.delete(f); };
export const currentUser = () => me;

function setSession(s) {
  access = s.accessToken; expiresAt = Date.now() + (s.expiresInSeconds - 30) * 1000; me = s.user;
  localStorage.setItem(REFRESH_KEY, s.refreshToken); emit();
}
function clearSession() { access = null; me = null; localStorage.removeItem(REFRESH_KEY); emit(); }

async function rawPost(path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new ApiError(r.status, j.error || 'Request failed');
  return j;
}
export async function login(username, password) { setSession(await rawPost('/api/auth/login', { username, password })); return me; }
async function refresh() {
  const rt = localStorage.getItem(REFRESH_KEY);
  if (!rt) return false;
  if (!refreshing) refreshing = rawPost('/api/auth/refresh', { refreshToken: rt }).then((s) => { setSession(s); return true; })
    .catch(() => { clearSession(); return false; }).finally(() => { refreshing = null; });
  return refreshing;
}
export async function restore() { return (await refresh()) ? me : null; }
export async function logout() {
  const rt = localStorage.getItem(REFRESH_KEY);
  try { if (rt) await rawPost('/api/auth/logout', { refreshToken: rt }); } catch (_) {}
  clearSession();
}
export async function token() { if (!access || Date.now() > expiresAt) await refresh(); return access; }

export async function api(method, path, body, opts = {}) {
  const send = async () => fetch(path, {
    method, headers: { ...(body !== undefined ? { 'content-type': 'application/json' } : {}), authorization: 'Bearer ' + (await token()) },
    body: body !== undefined ? JSON.stringify(body) : undefined });
  let r = await send();
  if (r.status === 401 && (await refresh())) r = await send();
  if (r.status === 401) { clearSession(); throw new ApiError(401, 'Please sign in again'); }
  if (opts.blob) {
    if (!r.ok) throw new ApiError(r.status, (await r.json().catch(() => ({}))).error || 'Request failed');
    const m = /filename="([^"]+)"/.exec(r.headers.get('content-disposition') || '');
    return { blob: await r.blob(), filename: m ? m[1] : 'report' };
  }
  const j = await r.json().catch(() => null);
  if (!r.ok) throw new ApiError(r.status, (j && j.error) || 'Request failed');
  return j;
}
export const get = (p) => api('GET', p);
export const post = (p, b) => api('POST', p, b ?? {});
export const put = (p, b) => api('PUT', p, b);
export async function liveUrl() {
  const t = await token();
  return `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws?token=${encodeURIComponent(t)}`;
}
