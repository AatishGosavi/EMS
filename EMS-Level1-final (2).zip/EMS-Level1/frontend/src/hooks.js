import { useEffect, useRef, useState } from 'react';

// Runs fn now and then every ms milliseconds; returns { data, error, loading }.
export function usePoll(fn, ms = 15000, deps = []) {
  const [s, setS] = useState({ data: null, error: null, loading: true });
  const ref = useRef(fn); ref.current = fn;
  useEffect(() => {
    let stop = false, timer;
    const run = async () => {
      try { const data = await ref.current(); if (!stop) setS({ data, error: null, loading: false }); }
      catch (e) { if (!stop) setS((p) => ({ data: p.data, error: e.message, loading: false })); }
      if (!stop && ms) timer = setTimeout(run, ms);
    };
    run();
    return () => { stop = true; clearTimeout(timer); };
  }, deps); // eslint-disable-line
  return s;
}
