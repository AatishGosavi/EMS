import { useState } from 'react';
import { useLive } from '../live';
import { stateKey, STATE_LABEL, num, avg3, duration, dash } from '../utils';
import Status from './Status';

export function MeterTable({ rows }) {
  const head = ['Meter', 'Area', 'Power (kW)', 'Energy today (kWh)', 'PF', 'Status', 'Batch'];
  return (
    <table>
      <thead><tr>{head.map((h, i) => <th key={h} className={i > 1 && i < 5 ? 'n' : ''}>{h}</th>)}</tr></thead>
      <tbody>{rows.map((m) => (
        <tr key={m.id}><td>{m.name}</td><td>{m.area}</td><td className="n">{num(m.kw, 1)}</td><td className="n">{num(m.energyToday)}</td>
          <td className="n">{m.state ? num(m.pf, 2) : dash}</td><td><Status s={stateKey(m)} /></td>
          <td>{m.batch && <span className="tag">{m.batch.no}</span>}</td></tr>
      ))}</tbody>
    </table>
  );
}

function MeterCard({ m }) {
  const k = stateKey(m), up = m.state !== 0, b = m.batch;
  const params = [['Voltage', up && `${num(avg3(m.vL1, m.vL2, m.vL3))} V`], ['Current', up && `${num(avg3(m.iL1, m.iL2, m.iL3))} A`], ['Power factor', up && num(m.pf, 2)],
    ['Frequency', up && `${num(m.freq, 2)} Hz`], ['Reactive', up && `${num(m.kvar)} kVAR`], ['Energy today', `${num(m.energyToday)} kWh`]];
  return (
    <div className={`card ${k}`}>
      <div className="hd"><b>{m.name}<i>{m.area}</i></b><span className="badge">{STATE_LABEL[k]}</span></div>
      <div className="kw">{up ? num(m.kw, 1) : dash}<small>kW</small></div>
      <div className="bt">
        {b ? <><span className="tag">{b.no}</span> {b.recipe}<div className="sub">{duration(b.seconds)} · {num(b.kwhSoFar)} kWh so far</div></>
          : <span className="none">{m.hasBatch ? 'No batch running' : dash}</span>}
      </div>
      <div className="pg">{params.map(([n, v]) => <div key={n}><span>{n}</span>{v || dash}</div>)}</div>
    </div>
  );
}

export default function Meters() {
  const { meters, loaded } = useLive();
  const [view, setView] = useState('cards'), [tab, setTab] = useState(''), [sf, setSf] = useState('');
  const areas = [...new Set(meters.map((m) => m.area))];
  const inTab = meters.filter((m) => !tab || m.area === tab);
  const shown = inTab.filter((m) => !sf || stateKey(m) === sf);
  const count = (k) => inTab.filter((m) => stateKey(m) === k).length;
  const kw = inTab.filter((m) => !m.isMain || tab).reduce((t, m) => t + (m.state ? m.kw : 0), 0);
  const tabs = [['', 'All areas', meters.length, false], ...areas.map((a) => [a, a, meters.filter((m) => m.area === a).length, meters.some((m) => m.area === a && m.state === 0)])];
  if (loaded && !meters.length) return <div className="panel empty">No meters are configured yet. An administrator can add them (API: POST /api/meters).</div>;
  return (
    <>
      <div className="tools">
        <div className="seg">{['cards', 'table'].map((v) => <button key={v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>{v === 'cards' ? 'Cards' : 'Table'}</button>)}</div>
        {view === 'cards' && (
          <select className="btn" aria-label="Filter by status" value={sf} onChange={(e) => setSf(e.target.value)}>
            <option value="">All statuses</option>{Object.entries(STATE_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </select>)}
        <span className="sp" />
        <span className="note">{inTab.length} meters · {num(kw)} kW now · {count('running')} running · {count('idle')} idle · {count('down')} down</span>
      </div>
      {view === 'cards' ? (
        <>
          <div className="tabs" role="tablist" aria-label="Areas">
            {tabs.map(([id, label, n, down]) => (
              <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>
                {label}<em>{n}</em>{down && <span className="dot down" title="A meter is down" />}</button>))}
          </div>
          <div className="cards">{shown.map((m) => <MeterCard key={m.id} m={m} />)}</div>
        </>
      ) : <div className="panel"><div className="wrap"><MeterTable rows={meters} /></div></div>}
    </>
  );
}
