import { useState } from 'react';
import { login } from '../api';

export default function Login() {
  const [u, setU] = useState(''), [p, setP] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await login(u.trim(), p); } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  return (
    <form className="login" onSubmit={submit}>
      <h1>Plant Energy</h1><p>Sign in to continue</p>
      <label htmlFor="u">Username</label><input id="u" value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" autoFocus />
      <label htmlFor="p">Password</label><input id="p" type="password" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
      {err && <p className="err" role="alert">{err}</p>}
      <button className="btn pri" disabled={busy || !u || !p}>{busy ? 'Signing in…' : 'Sign in'}</button>
    </form>
  );
}
