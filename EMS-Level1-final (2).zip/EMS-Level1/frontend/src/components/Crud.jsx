import { useState } from 'react';
import { usePoll } from '../hooks';

const empty = (f) => (f.type === 'checkbox' ? false : f.type === 'periods' ? [] : '');
const blank = (fields) => Object.fromEntries(fields.map((f) => [f.key, f.default ?? empty(f)]));
const fromRow = (fields, row) => Object.fromEntries(fields.map((f) => [f.key, row[f.key] ?? empty(f)]));
const DAYS = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

function Periods({ value, onChange }) {
  const upd = (i, k, x) => onChange(value.map((p, j) => (j === i ? { ...p, [k]: x } : p)));
  const toggle = (i, d) => { const days = value[i].days || [1, 2, 3, 4, 5, 6, 7]; upd(i, 'days', days.includes(d) ? days.filter((x) => x !== d) : [...days, d].sort()); };
  return (
    <div className="periods"><label>Time-of-use periods (plant local time; the highest rate wins where periods overlap)</label>
      {value.map((p, i) => (
        <div className="p" key={i}>
          <input type="text" placeholder="Name" aria-label="Period name" value={p.name || ''} onChange={(e) => upd(i, 'name', e.target.value)} required />
          <input type="time" aria-label="From" value={p.startTime || ''} onChange={(e) => upd(i, 'startTime', e.target.value)} required />
          <input type="time" aria-label="To" value={p.endTime || ''} onChange={(e) => upd(i, 'endTime', e.target.value)} required />
          <input type="number" step="any" min="0" placeholder="Rate per kWh" aria-label="Rate per kWh" value={p.ratePerKwh ?? ''} onChange={(e) => upd(i, 'ratePerKwh', e.target.value)} required />
          <span className="days">{DAYS.map((d, k) => <label key={k}><input type="checkbox" checked={(p.days || [1, 2, 3, 4, 5, 6, 7]).includes(k + 1)} onChange={() => toggle(i, k + 1)} />{d}</label>)}</span>
          <button type="button" className="btn sm danger" onClick={() => onChange(value.filter((_, j) => j !== i))}>Remove</button>
        </div>))}
      <button type="button" className="btn sm" onClick={() => onChange([...value, { name: '', startTime: '', endTime: '', ratePerKwh: '', days: [1, 2, 3, 4, 5, 6, 7] }])}>Add period</button>
    </div>
  );
}

function Field({ f, v, set, editing }) {
  const id = 'f_' + f.key, val = v[f.key];
  if (f.type === 'periods') return <Periods value={val} onChange={(x) => set(f.key, x)} />;
  if (f.type === 'checkbox') return <label className="chk"><input type="checkbox" checked={!!val} onChange={(e) => set(f.key, e.target.checked)} />{f.label}</label>;
  const common = { id, value: val ?? '', onChange: (e) => set(f.key, e.target.value), required: f.required && !(editing && f.omitEmpty), disabled: f.onlyCreate && editing };
  return (
    <div><label htmlFor={id}>{f.label}{f.required ? ' *' : ''}</label>
      {f.type === 'select'
        ? <select {...common}>{f.allowEmpty && <option value="">{f.emptyLabel || '–'}</option>}{(f.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>
        : <input type={f.type || 'text'} {...(f.type === 'number' ? { step: 'any', min: f.min, max: f.max } : {})} {...common} autoComplete={f.type === 'password' ? 'new-password' : 'off'} />}
      {f.help && <div className="help">{f.help}</div>}</div>
  );
}

// Generic list + add/edit form used by every Settings tab.
export default function Crud({ title, load, columns, fields, save, remove, canEdit = true, addLabel = 'Add', emptyText = 'Nothing here yet.', toolbar }) {
  const [tick, setTick] = useState(0), [ed, setEd] = useState(null), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  const { data, error } = usePoll(load, 0, [tick, load.key]);
  const open = (row) => { setErr(''); setEd({ row, v: row ? fromRow(fields, row) : blank(fields) }); };
  const set = (k, x) => setEd((s) => ({ ...s, v: { ...s.v, [k]: x } }));
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try {
      const out = {};
      for (const f of fields) {
        if ((f.showIf && !f.showIf(ed.v)) || (f.onlyCreate && ed.row)) continue;
        let x = ed.v[f.key];
        if (x === '' && f.omitEmpty) continue;
        if (f.type === 'number' || (f.type === 'select' && f.numeric)) x = x === '' || x == null ? null : Number(x);
        else if (x === '' && f.type !== 'text' && f.type !== 'password') x = null;
        out[f.key] = x;
      }
      await save(out, ed.row); setEd(null); setTick((t) => t + 1);
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  const del = async (row) => { if (!window.confirm('Delete this entry?')) return; try { await remove(row); setTick((t) => t + 1); } catch (x) { setErr(x.message); } };
  return (
    <div className="panel">
      <div className="titlebar"><h2>{title}</h2><span className="sp" />{toolbar}{canEdit && !ed && <button className="btn pri sm" onClick={() => open(null)}>{addLabel}</button>}</div>
      {ed && (
        <form onSubmit={submit} style={{ borderBottom: '1px solid var(--line)', marginBottom: 14 }}>
          <div className="editor">{fields.filter((f) => !f.showIf || f.showIf(ed.v)).filter((f) => !(f.onlyCreate && ed.row && f.hideOnEdit)).map((f) => <Field key={f.key} f={f} v={ed.v} set={set} editing={!!ed.row} />)}</div>
          {err && <p className="err" role="alert">{err}</p>}
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}><button className="btn pri" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button><button type="button" className="btn" onClick={() => setEd(null)}>Cancel</button></div>
        </form>)}
      {!ed && err && <p className="err" role="alert">{err}</p>}
      {error && <p className="err" role="alert">{error}</p>}
      {data && (data.length ? <div className="wrap"><table>
        <thead><tr>{columns.map((c) => <th key={c.key} className={c.n ? 'n' : ''}>{c.label}</th>)}{canEdit && <th />}</tr></thead>
        <tbody>{data.map((r, i) => (
          <tr key={r.id ?? r.key ?? i}>{columns.map((c) => <td key={c.key} className={c.n ? 'n' : ''}>{c.render ? c.render(r) : r[c.key]}</td>)}
            {canEdit && <td><div className="tbl-actions"><button className="btn sm" onClick={() => open(r)}>Edit</button>{remove && <button className="btn sm danger" onClick={() => del(r)}>Delete</button>}</div></td>}</tr>))}</tbody></table></div>
        : <div className="empty">{emptyText}</div>)}
    </div>
  );
}
