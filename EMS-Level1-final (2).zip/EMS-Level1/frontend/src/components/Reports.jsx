import { useEffect, useMemo, useState } from 'react';
import { api, get, post, put } from '../api';
import { addDays, ymd, num } from '../utils';

const PERIODS = [['last7', 'Last 7 days'], ['last30', 'Last 30 days'], ['month', 'This month'], ['lastmonth', 'Last month'], ['custom', 'Custom range']];

function range(period, today, custom) {
  if (period === 'last7') return { from: addDays(today, -6), to: today };
  if (period === 'last30') return { from: addDays(today, -29), to: today };
  if (period === 'month') return { from: today.slice(0, 8) + '01', to: today };
  if (period === 'lastmonth') { const first = today.slice(0, 8) + '01'; return { from: addDays(first, -1).slice(0, 8) + '01', to: addDays(first, -1) }; }
  return custom;
}

export default function Reports() {
  const [meta, setMeta] = useState(null), [tz, setTz] = useState(null), [templates, setTemplates] = useState([]);
  const [g1, setG1] = useState('day'), [g2, setG2] = useState(''), [period, setPeriod] = useState('last7'), [custom, setCustom] = useState({ from: '', to: '' });
  const [target, setTarget] = useState('meters'), [fields, setFields] = useState({ energy_kwh: 'sum', kw_peak: 'max', kw_avg: 'avg' });
  const [res, setRes] = useState(null), [err, setErr] = useState(''), [msg, setMsg] = useState('');

  const loadTemplates = () => get('/api/reports/templates').then(setTemplates).catch(() => {});
  useEffect(() => { get('/api/reports/meta').then(setMeta); get('/api/settings').then((s) => setTz(s.plantTimezone)); loadTemplates(); }, []);
  const today = tz ? ymd(new Date(), tz) : null;
  useEffect(() => { if (today && !custom.from) setCustom({ from: addDays(today, -6), to: today }); }, [today]); // eslint-disable-line

  const definition = useMemo(() => {
    if (!today) return null;
    const def = { groupBy: [g1, g2].filter(Boolean), range: range(period, today, custom), fields: Object.entries(fields).map(([code, agg]) => ({ code, agg })) };
    if (target === 'plant') def.scope = 'plant';
    else if (target.startsWith('area:')) def.areas = [Number(target.slice(5))];
    return def;
  }, [g1, g2, period, custom, target, fields, today]);

  useEffect(() => {                       // the preview updates itself, like in the approved design
    if (!definition) return;
    if (!definition.fields.length) { setRes(null); setErr('Pick at least one field.'); return; }
    let stop = false;
    const t = setTimeout(() => post('/api/reports/run', { definition }).then((r) => { if (!stop) { setRes(r); setErr(''); } }).catch((e) => { if (!stop) { setRes(null); setErr(e.message); } }), 300);
    return () => { stop = true; clearTimeout(t); };
  }, [definition]);

  const download = async (format) => {
    try { const { blob, filename } = await api('POST', '/api/reports/export', { definition, format }, { blob: true });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; a.click(); URL.revokeObjectURL(a.href); }
    catch (e) { setErr(e.message); }
  };
  const save = async () => {
    const name = window.prompt('Name for this report template'); if (!name) return;
    try { await post('/api/reports/templates', { name, definition }); setMsg('Template saved'); loadTemplates(); } catch (e) { setErr(e.message); }
  };
  const load = (id) => {
    const t = templates.find((x) => String(x.id) === id); if (!t) return; const d = t.definition;
    const gb = Array.isArray(d.groupBy) ? d.groupBy : d.groupBy ? [d.groupBy] : [];
    setG1(gb[0] || ''); setG2(gb[1] || ''); setPeriod('custom'); setCustom(d.range);
    setTarget(d.scope === 'plant' ? 'plant' : d.areas && d.areas[0] ? 'area:' + d.areas[0] : 'meters');
    setFields(Object.fromEntries((d.fields || []).map((f) => [f.code, f.agg || meta.fields.find((x) => x.code === f.code)?.defaultAgg])));
    setMsg(`Loaded "${t.name}"`);
  };
  const toggle = (f) => setFields((p) => { const n = { ...p }; if (n[f.code]) delete n[f.code]; else n[f.code] = f.defaultAgg; return n; });

  if (!meta) return <div className="panel empty">Loading…</div>;
  const dims = meta.dimensions;
  const valueCols = res ? res.columns.filter((c) => c.kind === 'value') : [], dimCols = res ? res.columns.filter((c) => c.kind === 'dimension') : [];
  const barKey = valueCols[0]?.key, max = res && barKey ? Math.max(1, ...res.rows.map((r) => Math.abs(r[barKey] || 0))) : 1;
  return (
    <div className="two rep">
      <div className="panel form"><h2>Build a report</h2>
        {templates.length > 0 && <><label>Saved templates</label>
          <select value="" onChange={(e) => load(e.target.value)}><option value="">Load a template…</option>{templates.map((t) => <option key={t.id} value={t.id}>{t.name}{t.isShared ? ' (shared)' : ''}</option>)}</select></>}
        <label>Group by</label>
        <select value={g1} onChange={(e) => setG1(e.target.value)}><option value="">Total only</option>{dims.map((d) => <option key={d.code} value={d.code}>{d.label}</option>)}</select>
        {g1 && <><label>Then by</label><select value={g2} onChange={(e) => setG2(e.target.value)}><option value="">Nothing</option>{dims.filter((d) => d.code !== g1).map((d) => <option key={d.code} value={d.code}>{d.label}</option>)}</select></>}
        <label>Period</label>
        <select value={period} onChange={(e) => setPeriod(e.target.value)}>{PERIODS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
        {period === 'custom' && <div className="row"><input type="date" aria-label="From" value={custom.from} onChange={(e) => setCustom({ ...custom, from: e.target.value })} />
          <input type="date" aria-label="To" value={custom.to} onChange={(e) => setCustom({ ...custom, to: e.target.value })} /></div>}
        <label>Meters</label>
        <select value={target} onChange={(e) => setTarget(e.target.value)}><option value="meters">All meters</option>
          {meta.areas.map((a) => <option key={a.id} value={'area:' + a.id}>Area: {a.name}</option>)}<option value="plant">Plant total (main meter)</option></select>
        <label>Fields</label>
        {meta.fields.map((f) => <label key={f.code}><input type="checkbox" checked={!!fields[f.code]} onChange={() => toggle(f)} /> {f.label}{f.unit ? ` (${f.unit})` : ''}</label>)}
        <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
          <button className="btn pri" onClick={save} disabled={!definition || !definition.fields.length}>Save template</button>
          <button className="btn" onClick={() => download('xlsx')} disabled={!res}>Export Excel</button>
          <button className="btn" onClick={() => download('csv')} disabled={!res}>CSV</button></div>
        {msg && <p className="ok" style={{ marginTop: 10 }}>{msg}</p>}
      </div>
      <div className="panel"><h2>Preview</h2>
        {err && <p className="err" role="alert">{err}</p>}
        {res && (res.rows.length ? <>
          <div className="wrap"><table>
            <thead><tr>{res.columns.map((c) => <th key={c.key} className={c.kind === 'value' ? 'n' : ''}>{c.label}</th>)}</tr></thead>
            <tbody>{res.rows.map((r, i) => <tr key={i}>{res.columns.map((c) => <td key={c.key} className={c.kind === 'value' ? 'n' : ''}>{c.kind === 'value' ? num(r[c.key], 1) : r[c.key]}</td>)}</tr>)}</tbody></table></div>
          {dimCols.length > 0 && barKey && res.rows.length <= 40 && <div style={{ marginTop: 14 }}>{res.rows.map((r, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '6px 0' }}>
              <span style={{ width: 150, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{dimCols.map((c) => r[c.key]).join(' · ')}</span>
              <div className="bar" style={{ flex: 1 }}><i style={{ width: `${(Math.abs(r[barKey] || 0) / max) * 100}%` }} /></div></div>))}</div>}
        </> : <div className="empty">No data for this selection.</div>)}
      </div>
    </div>
  );
}
