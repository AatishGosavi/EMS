// Small dependency-free SVG line chart.
// series: [{ d: (number|null)[], c: color, k: strokeWidth, n?: number of x positions }]; null values break the line.
const niceMax = (v) => { if (!(v > 0)) return 10; const p = 10 ** Math.floor(Math.log10(v)), f = v / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p; };

export default function Chart({ series, max, labels = [], w = 640, h = 190 }) {
  const top = max || niceMax(Math.max(0, ...series.flatMap((s) => s.d.filter((v) => v != null))) * 1.05);
  const X = (i, n) => 34 + (n > 1 ? (i / (n - 1)) * (w - 34) : 0);
  const path = (s) => { const n = s.n || s.d.length; let out = '', pen = false;
    s.d.forEach((v, i) => { if (v == null) { pen = false; return; } out += `${pen ? 'L' : 'M'}${X(i, n).toFixed(1)} ${(h - (v / top) * h).toFixed(1)}`; pen = true; });
    return out; };
  return (
    <svg viewBox={`0 0 ${w} ${h + 22}`} role="img" aria-label="Trend chart">
      {[0, 1, 2, 3, 4].map((i) => {
        const y = (h / 4) * i;
        return <g key={i}><line x1="34" x2={w} y1={y} y2={y} stroke="var(--line)" />
          <text x="0" y={y + 4} fill="var(--mute)" fontSize="11">{Math.round(top * (1 - i / 4))}</text></g>;
      })}
      {series.map((s, k) => <path key={k} d={path(s)} fill="none" stroke={s.c} strokeWidth={s.k || 2} />)}
      {labels.map((t, i) => <text key={i} x={X(i, labels.length)} y={h + 16} fill="var(--mute)" fontSize="11" textAnchor="middle">{t}</text>)}
    </svg>
  );
}
