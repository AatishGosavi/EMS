import { STATE_LABEL } from '../utils';
export default function Status({ s }) {
  return <><span className={`dot ${s === 'running' ? '' : s}`} />{STATE_LABEL[s]}</>;
}
