import Chart from './Chart';
import { MeterTable } from './Meters';
import { useLive } from '../live';
import { usePoll } from '../hooks';
import { get } from '../api';
import { num, duration, clock, dash } from '../utils';

export default function Dashboard() {
  const { meters } = useLive();
  const { data: d, error } = usePoll(() => get('/api/dashboard'), 15000);
  const { data: running } = usePoll(() => get('/api/batches?status=running'), 15000);
  if (!d) return <div className="panel empty">{error || 'Loading…'}</div>;

  const today = d.trend.today, yest = new Map(d.trend.yesterday.map((p) => [new Date(p.t).getTime(), p.kw]));
  const labels = today.length ? [0, 0.25, 0.5, 0.75, 1].map((f) => clock(today[Math.round(f * (today.length - 1))].t)) : [];
  const maxA = Math.max(1, ...d.areaEnergyToday.map((a) => a.kwh));
  const byName = new Map(meters.map((m) => [m.id, m]));
  return (
    <>
      <div className="panel hero">
        <div>
          <div className="big">{num(d.plantKwNow)}<small>kW now</small></div>
          <div className="leg" style={{ margin: '10px 0 4px' }}>
            <span><i style={{ background: 'var(--amber)' }} />Plant load, last 24 h</span><span><i style={{ background: 'var(--mute)' }} />Yesterday</span></div>
          {today.length > 1 ? <Chart labels={labels} series={[
            { d: today.map((p) => yest.get(new Date(p.t).getTime()) ?? null), c: 'var(--mute)', k: 1.5 }, { d: today.map((p) => p.kw), c: 'var(--amber)', k: 2.5 }]} />
            : <div className="empty">The trend appears after the first minutes of logged data.</div>}
        </div>
        <dl><dt>Energy today</dt><dd>{num(d.energyTodayKwh)} kWh</dd>
          <dt>Peak demand today</dt><dd>{d.peakDemandKw == null ? dash : `${num(d.peakDemandKw)} kW`} {d.peakAt && <span className="note">at {clock(d.peakAt)}</span>}</dd>
          <dt>Meters online</dt><dd>{d.metersOnline} of {d.metersTotal}</dd>
          <dt>Batches running</dt><dd>{d.batchesRunning}</dd></dl>
      </div>
      <div className="two">
        <div className="panel"><h2>Batches running now</h2><div className="wrap">
          {running && running.length ? <table>
            <thead><tr><th>Batch</th><th>Machine</th><th>Elapsed</th><th>Energy so far</th><th className="n">Power</th></tr></thead>
            <tbody>{running.map((b) => (
              <tr key={b.id}><td><span className="tag">{b.batchNo}</span></td><td>{b.meterName}</td><td>{duration(b.durationSeconds)}</td><td>{num(b.kwhImport)} kWh</td>
                <td className="n">{num(b.currentKw ?? byName.get(b.meterId)?.kw)} kW</td></tr>))}</tbody></table>
            : <div className="empty">No batch is running.</div>}</div></div>
        <div className="panel"><h2>Energy today by area (kWh)</h2>
          {d.areaEnergyToday.length ? d.areaEnergyToday.map((a) => (
            <div key={a.area} style={{ display: 'flex', alignItems: 'center', gap: 10, margin: '8px 0' }}>
              <span style={{ width: 110 }}>{a.area}</span><div className="bar" style={{ flex: 1 }}><i style={{ width: `${(a.kwh / maxA) * 100}%` }} /></div>
              <span style={{ width: 60, textAlign: 'right' }}>{num(a.kwh)}</span></div>)) : <div className="empty">No energy recorded yet today.</div>}
        </div>
      </div>
      <div className="panel"><h2>Meters, live</h2><div className="wrap"><MeterTable rows={meters.filter((m) => !m.isMain).slice(0, 8)} /></div></div>
    </>
  );
}
