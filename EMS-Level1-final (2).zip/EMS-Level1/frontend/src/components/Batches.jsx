import { useEffect, useState } from 'react';
import Chart from './Chart';
import { usePoll } from '../hooks';
import { get } from '../api';
import { num, duration, stamp, dash } from '../utils';

const byMinute = (curve, len) => { const a = Array(len).fill(null); for (const p of curve) if (p.minute >= 0 && p.minute < len) a[p.minute] = p.kw; return a; };

export default function Batches() {
  const { data: list, error } = usePoll(() => get('/api/batches?limit=100'), 20000);
  const [sel, setSel] = useState(null), [det, setDet] = useState(null);
  useEffect(() => { if (list && list.length && sel == null) setSel(list[0].id); }, [list, sel]);
  useEffect(() => { if (sel != null) get('/api/batches/' + sel).then(setDet).catch(() => setDet(null)); }, [sel]);
  if (!list) return <div className="panel empty">{error || 'Loading…'}</div>;
  if (!list.length) return <div className="panel empty">No batches have been recorded yet.</div>;

  const head = ['Batch', 'Machine', 'Recipe', 'Started', 'Duration', 'Energy (kWh)', 'Peak (kW)', 'Status'], nc = (j) => (j === 5 || j === 6 ? 'n' : '');
  let chart = null;
  if (det && det.batch.id === sel) {
    const len = Math.max(2, ...det.curve.map((p) => p.minute + 1), ...det.previousCurve.map((p) => p.minute + 1));
    const step = Math.max(1, Math.round(len / 4));
    const c = det.comparison;
    chart = (
      <div className="panel">
        <h2>Batch {det.batch.batchNo} {det.previous ? `compared with the previous batch of the same recipe (${det.previous.batchNo})` : ''}</h2>
        <div className="leg"><span><i style={{ background: 'var(--amber)' }} />This batch{det.batch.status === 'running' ? ' (running)' : ''}</span>
          {det.previous && <span><i style={{ background: 'var(--mute)' }} />Previous batch</span>}</div>
        <Chart labels={[0, 1, 2, 3, 4].map((i) => `${i * step} min`)} series={[
          ...(det.previous ? [{ d: byMinute(det.previousCurve, len), c: 'var(--mute)', k: 1.5, n: len }] : []), { d: byMinute(det.curve, len), c: 'var(--amber)', k: 2.5, n: len }]} />
        <p style={{ color: 'var(--mute)', margin: '8px 0 0' }}>
          {c && c.pctDiff != null ? `At ${duration(c.elapsedMin * 60)} this batch has used ${Math.abs(c.pctDiff)}% ${c.pctDiff >= 0 ? 'more' : 'less'} energy than the previous batch at the same point.`
            : 'There is no earlier batch of this recipe on this machine to compare with.'}
          {det.batch.kwhPerUnit != null && ` Energy per unit produced: ${num(det.batch.kwhPerUnit, 2)} kWh.`}</p>
      </div>);
  }
  return (
    <>
      <div className="panel"><h2>Batch history</h2><div className="wrap"><table>
        <thead><tr>{head.map((h, j) => <th key={h} className={nc(j)}>{h}</th>)}</tr></thead>
        <tbody>{list.map((b) => (
          <tr key={b.id} className={b.id === sel ? 'sel' : ''} style={{ cursor: 'pointer' }} onClick={() => setSel(b.id)}>
            {[b.batchNo, b.meterName, b.recipeName || dash, stamp(b.startTs), duration(b.durationSeconds), num(b.kwhImport), num(b.peakKw), b.status === 'running' ? 'Running' : 'Done']
              .map((v, j) => <td key={j} className={nc(j)}>{v}</td>)}</tr>))}</tbody></table></div></div>
      {chart}
    </>
  );
}
