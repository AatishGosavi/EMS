import { useMemo, useState } from 'react';
import Crud from './Crud';
import { usePoll } from '../hooks';
import { api, get, post, put } from '../api';
import { currentUser } from '../api';
import { stamp } from '../utils';

const yes = (v) => (v ? 'Yes' : '–');
const opts = (rows, label = 'name') => (rows || []).map((r) => ({ value: r.id, label: r[label] }));
const loader = (path) => { const f = () => get(path); f.key = path; return f; };

function MetersTab() {
  const areas = usePoll(() => get('/api/areas'), 0).data;
  const fields = [
    { key: 'code', label: 'Code', required: true, help: 'Short tag, e.g. MX-101' }, { key: 'name', label: 'Name', required: true },
    { key: 'areaId', label: 'Area', type: 'select', numeric: true, required: true, options: opts(areas) },
    { key: 'plcIndex', label: 'PLC index (0-79)', type: 'number', min: 0, max: 79, required: true, help: 'Position in the EMS_Data array in the PLC' },
    { key: 'runSource', label: 'Running status from', type: 'select', default: 'kw', options: [{ value: 'kw', label: 'Power (kW above the idle limit)' }, { value: 'plc', label: 'PLC run signal' }] },
    { key: 'idleThresholdKw', label: 'Idle limit (kW)', type: 'number', default: 1 }, { key: 'multiplier', label: 'CT/PT multiplier', type: 'number', default: 1 },
    { key: 'sortOrder', label: 'Sort order', type: 'number', default: 0 },
    { key: 'hasBatch', label: 'Meter carries batch data' }, { key: 'isMain', label: 'Main (incomer) meter' }, { key: 'isActive', label: 'Active', default: true },
  ].map((f) => (['hasBatch', 'isMain', 'isActive'].includes(f.key) ? { ...f, type: 'checkbox' } : f));
  return <Crud title="Meters" load={loader('/api/meters')} addLabel="Add meter" fields={fields}
    columns={[{ key: 'plcIndex', label: 'PLC #', n: true }, { key: 'code', label: 'Code' }, { key: 'name', label: 'Name' }, { key: 'area', label: 'Area' },
      { key: 'runSource', label: 'Status from', render: (r) => (r.runSource === 'plc' ? 'PLC signal' : `kW ≥ ${r.idleThresholdKw}`) },
      { key: 'hasBatch', label: 'Batch', render: (r) => yes(r.hasBatch) }, { key: 'isMain', label: 'Main', render: (r) => yes(r.isMain) }, { key: 'isActive', label: 'Active', render: (r) => yes(r.isActive) }]}
    save={(v, row) => (row ? api('PATCH', '/api/meters/' + row.id, v) : post('/api/meters', v))} />;
}

function AreasTab() {
  const areas = usePoll(() => get('/api/areas'), 0).data;
  return <Crud title="Areas" load={loader('/api/areas')} addLabel="Add area"
    fields={[{ key: 'name', label: 'Name', required: true }, { key: 'sortOrder', label: 'Sort order', type: 'number', default: 0 },
      { key: 'parentId', label: 'Parent area (optional)', type: 'select', numeric: true, allowEmpty: true, emptyLabel: 'None (top level)', options: opts(areas) }]}
    columns={[{ key: 'name', label: 'Name' }, { key: 'meterCount', label: 'Meters', n: true }, { key: 'sortOrder', label: 'Sort order', n: true }]}
    save={(v, row) => (row ? api('PATCH', '/api/areas/' + row.id, v) : post('/api/areas', v))}
    remove={(row) => api('DELETE', '/api/areas/' + row.id)} emptyText="No areas yet." />;
}

function RecipesTab() {
  return <Crud title="Recipes" load={loader('/api/recipes')} addLabel="Add recipe"
    fields={[{ key: 'id', label: 'Recipe number (as sent by the PLC)', type: 'number', required: true, onlyCreate: true }, { key: 'name', label: 'Name', required: true }]}
    columns={[{ key: 'id', label: 'Number', n: true }, { key: 'name', label: 'Name' }]}
    save={(v, row) => put('/api/recipes/' + (row ? row.id : v.id), { name: v.name })}
    emptyText="Recipes appear here when the PLC reports a new recipe number during a batch." />;
}

function AlarmRulesTab() {
  const meters = usePoll(() => get('/api/meters'), 0).data, areas = usePoll(() => get('/api/areas'), 0).data;
  const name = (list, id) => (list || []).find((x) => x.id === id)?.name || id;
  const fields = [
    { key: 'name', label: 'Name', required: true }, { key: 'severity', label: 'Severity', type: 'select', default: 'warning', options: ['info', 'warning', 'critical'].map((x) => ({ value: x, label: x })) },
    { key: 'scope', label: 'Applies to', type: 'select', default: 'meter', options: [{ value: 'meter', label: 'One meter' }, { value: 'area', label: 'All meters of an area' }, { value: 'all', label: 'All meters' }] },
    { key: 'meterId', label: 'Meter', type: 'select', numeric: true, required: true, options: opts(meters), showIf: (v) => v.scope === 'meter' },
    { key: 'areaId', label: 'Area', type: 'select', numeric: true, required: true, options: opts(areas), showIf: (v) => v.scope === 'area' },
    { key: 'metric', label: 'Measurement', type: 'select', default: 'kw', options: [['kw', 'Power (kW)'], ['kvar', 'Reactive power (kVAR)'], ['kva', 'Apparent power (kVA)'], ['pf', 'Power factor'], ['freq', 'Frequency (Hz)'],
      ['v_l1', 'Voltage L1 (V)'], ['v_l2', 'Voltage L2 (V)'], ['v_l3', 'Voltage L3 (V)'], ['i_l1', 'Current L1 (A)'], ['i_l2', 'Current L2 (A)'], ['i_l3', 'Current L3 (A)'], ['state', 'Status (0 Down, 1 Idle, 2 Running)']].map(([value, label]) => ({ value, label })) },
    { key: 'operator', label: 'Condition', type: 'select', default: '>', options: ['>', '>=', '<', '<=', '='].map((x) => ({ value: x, label: x })) },
    { key: 'threshold', label: 'Limit', type: 'number', required: true }, { key: 'forSeconds', label: 'Must last (seconds)', type: 'number', default: 0, help: '0 = alarm immediately' },
    { key: 'isActive', label: 'Active', type: 'checkbox', default: true },
  ];
  return <Crud title="Alarm rules" load={loader('/api/alarm-rules')} addLabel="Add rule" fields={fields}
    columns={[{ key: 'name', label: 'Name' }, { key: 'severity', label: 'Severity', render: (r) => <span className={`sev ${r.severity}`}>{r.severity}</span> },
      { key: 'target', label: 'Applies to', render: (r) => (r.scope === 'meter' ? name(meters, r.meterId) : r.scope === 'area' ? 'Area: ' + name(areas, r.areaId) : 'All meters') },
      { key: 'cond', label: 'Condition', render: (r) => `${r.metric} ${r.operator} ${r.threshold}${r.forSeconds ? ` for ${r.forSeconds} s` : ''}` }, { key: 'isActive', label: 'Active', render: (r) => yes(r.isActive) }]}
    save={(v, row) => (row ? put('/api/alarm-rules/' + row.id, v) : post('/api/alarm-rules', v))} remove={(row) => api('DELETE', '/api/alarm-rules/' + row.id)}
    emptyText="No alarm rules yet. Example: a meter is Down (Status = 0) for 60 seconds." />;
}

function TariffsTab() {
  const prep = (v) => ({ ...v, periods: (v.periods || []).map((p) => ({ ...p, ratePerKwh: Number(p.ratePerKwh), days: p.days || [1, 2, 3, 4, 5, 6, 7] })) });
  return <Crud title="Tariffs (for the cost report)" load={loader('/api/tariffs')} addLabel="Add tariff"
    fields={[{ key: 'name', label: 'Name', required: true }, { key: 'validFrom', label: 'Valid from', type: 'date', required: true }, { key: 'validTo', label: 'Valid to (optional)', type: 'date' },
      { key: 'currency', label: 'Currency (e.g. INR)' }, { key: 'defaultRatePerKwh', label: 'Normal rate per kWh', type: 'number', required: true, min: 0 }, { key: 'periods', label: 'Periods', type: 'periods' }]}
    columns={[{ key: 'name', label: 'Name' }, { key: 'validFrom', label: 'Valid from', render: (r) => String(r.validFrom).slice(0, 10) }, { key: 'validTo', label: 'Valid to', render: (r) => (r.validTo ? String(r.validTo).slice(0, 10) : 'open') },
      { key: 'defaultRatePerKwh', label: `Normal rate`, n: true, render: (r) => `${r.defaultRatePerKwh} ${r.currency || ''}` }, { key: 'periods', label: 'Periods', n: true, render: (r) => r.periods.length }]}
    save={(v, row) => (row ? put('/api/tariffs/' + row.id, prep(v)) : post('/api/tariffs', prep(v)))} remove={(row) => api('DELETE', '/api/tariffs/' + row.id)} emptyText="No tariff defined: the cost report stays empty." />;
}

function UsersTab() {
  return <Crud title="Users" load={loader('/api/users')} addLabel="Add user"
    fields={[{ key: 'username', label: 'Username', required: true, onlyCreate: true }, { key: 'displayName', label: 'Display name' }, { key: 'email', label: 'E-mail' },
      { key: 'role', label: 'Role', type: 'select', default: 'viewer', options: [{ value: 'viewer', label: 'Viewer: sees everything, own reports' }, { value: 'engineer', label: 'Engineer: + shares reports, acknowledges alarms, alarm rules' }, { value: 'admin', label: 'Admin: everything' }] },
      { key: 'password', label: 'Password (at least 8 characters)', type: 'password', required: true, omitEmpty: true, help: 'When editing: leave empty to keep the current password' },
      { key: 'mustChangePassword', label: 'Must change the password at next sign-in', type: 'checkbox', default: true }, { key: 'isActive', label: 'Active', type: 'checkbox', default: true }]}
    columns={[{ key: 'username', label: 'Username' }, { key: 'displayName', label: 'Name' }, { key: 'role', label: 'Role' }, { key: 'isActive', label: 'Active', render: (r) => yes(r.isActive) },
      { key: 'lastLoginAt', label: 'Last sign-in', render: (r) => (r.lastLoginAt ? stamp(r.lastLoginAt) : 'never') }]}
    save={(v, row) => (row ? api('PATCH', '/api/users/' + row.id, v) : post('/api/users', v))} />;
}

function AuditTab() {
  const [entity, setEntity] = useState('');
  const load = useMemo(() => { const f = () => get('/api/audit?limit=200' + (entity ? '&entity=' + entity : '')); f.key = 'audit' + entity; return f; }, [entity]);
  const sum = (d) => { const s = JSON.stringify(d || {}); return s.length > 110 ? s.slice(0, 110) + '…' : s; };
  return <Crud title="Audit log (who changed what)" load={load} canEdit={false}
    toolbar={<select className="btn" aria-label="Filter" value={entity} onChange={(e) => setEntity(e.target.value)}><option value="">All tables</option>
      {['meters', 'areas', 'users', 'recipes', 'alarm_rules', 'tariffs', 'report_templates', 'app_settings'].map((x) => <option key={x}>{x}</option>)}</select>}
    columns={[{ key: 'ts', label: 'Time', render: (r) => stamp(r.ts) }, { key: 'username', label: 'User', render: (r) => r.username || 'database' }, { key: 'action', label: 'Action' },
      { key: 'entity', label: 'Table' }, { key: 'entityId', label: 'Id' }, { key: 'details', label: 'Details', render: (r) => <span className="muted">{sum(r.details)}</span> }]}
    emptyText="Nothing logged yet." />;
}

const RANK = { viewer: 1, engineer: 2, admin: 3 };
const TABS = [['Meters', 'admin', MetersTab], ['Areas', 'admin', AreasTab], ['Recipes', 'engineer', RecipesTab], ['Alarm rules', 'engineer', AlarmRulesTab],
  ['Tariffs', 'admin', TariffsTab], ['Users', 'admin', UsersTab], ['Audit log', 'admin', AuditTab]];

export default function Settings() {
  const role = currentUser()?.role || 'viewer';
  const tabs = TABS.filter(([, min]) => RANK[role] >= RANK[min]);
  const [sel, setSel] = useState(tabs[0]?.[0]);
  const Tab = (tabs.find((t) => t[0] === sel) || tabs[0])?.[2];
  if (!Tab) return <div className="panel empty">Settings are available to engineers and administrators.</div>;
  return (
    <>
      <div className="tabs" role="tablist" aria-label="Settings">{tabs.map(([label]) => <button key={label} role="tab" aria-selected={label === sel} className={label === sel ? 'on' : ''} onClick={() => setSel(label)}>{label}</button>)}</div>
      <Tab key={sel} />
    </>
  );
}
