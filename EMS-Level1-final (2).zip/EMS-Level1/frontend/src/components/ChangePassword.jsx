import { useState } from 'react';
import { post, logout } from '../api';

export default function ChangePassword({ forced, onDone }) {
  const [cur, setCur] = useState(''), [n1, setN1] = useState(''), [n2, setN2] = useState(''), [msg, setMsg] = useState(null);
  const submit = async (e) => {
    e.preventDefault();
    if (n1 !== n2) return setMsg({ err: 'The new passwords do not match' });
    try { await post('/api/auth/change-password', { currentPassword: cur, newPassword: n1 }); await logout(); }
    catch (x) { setMsg({ err: x.message }); }
  };
  return (
    <form className="login pw" onSubmit={submit}>
      <h1>Change password</h1><p>{forced ? 'You must choose a new password before continuing.' : 'You will be signed out afterwards.'}</p>
      <label htmlFor="c">Current password</label><input id="c" type="password" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" />
      <label htmlFor="n">New password (at least 8 characters)</label><input id="n" type="password" value={n1} onChange={(e) => setN1(e.target.value)} autoComplete="new-password" />
      <label htmlFor="n2">Repeat new password</label><input id="n2" type="password" value={n2} onChange={(e) => setN2(e.target.value)} autoComplete="new-password" />
      {msg && <p className="err" role="alert">{msg.err}</p>}
      <div className="row" style={{ display: 'flex', gap: 8 }}>
        <button className="btn pri" disabled={!cur || n1.length < 8}>Change password</button>
        {!forced && <button type="button" className="btn" onClick={onDone}>Cancel</button>}
      </div>
    </form>
  );
}
