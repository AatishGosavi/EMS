import { useState } from 'react';
import { usePoll } from '../hooks';
import { api, get, currentUser } from '../api';
import { stamp, num } from '../utils';

export default function Alarms() {
  const [view, setView] = useState('active'), [tick, setTick] = useState(0), [err, setErr] = useState('');
  const canAck = ['engineer', 'admin'].includes(currentUser()?.role);
  const { data, error } = usePoll(() => get(`/api/alarms?${view === 'active' ? 'active=true&' : ''}limit=200`), 10000, [view, tick]);
  const ack = async (id) => { try { await api('POST', `/api/alarms/${id}/ack`, {}); setErr(''); setTick((t) => t + 1); window.dispatchEvent(new Event('ems-alarms')); } catch (e) { setErr(e.message); } };
  return (
    <>
      <div className="tools"><div className="seg">{[['active', 'Active'], ['history', 'History']].map(([v, l]) => <button key={v} className={view === v ? 'on' : ''} onClick={() => setView(v)}>{l}</button>)}</div>
        <span className="sp" /><span className="note">Alarms are checked by the collector; rules are in Settings → Alarm rules</span></div>
      <div className="panel">
        {(err || error) && <p className="err" role="alert">{err || error}</p>}
        {!data ? <div className="empty">Loading…</div> : data.length ? <div className="wrap"><table>
          <thead><tr><th>Started</th><th>Severity</th><th>Alarm</th><th>Meter</th><th>Area</th><th className="n">Value</th><th>Status</th><th>Acknowledged</th></tr></thead>
          <tbody>{data.map((a) => (
            <tr key={a.id}><td>{stamp(a.startedAt)}</td><td><span className={`sev ${a.severity}`}>{a.severity}</span></td><td title={a.message}>{a.ruleName}</td><td>{a.meterName}</td><td>{a.areaName}</td>
              <td className="n">{num(a.value, 1)}</td><td>{a.active ? 'Active' : `Cleared ${stamp(a.clearedAt)}`}</td>
              <td>{a.acknowledgedAt ? `${a.acknowledgedBy || ''} ${stamp(a.acknowledgedAt)}` : canAck && a.active ? <button className="btn sm" onClick={() => ack(a.id)}>Acknowledge</button> : '–'}</td></tr>))}</tbody></table></div>
          : <div className="empty">{view === 'active' ? 'No active alarms.' : 'No alarms recorded yet.'}</div>}
      </div>
    </>
  );
}
