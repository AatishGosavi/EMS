export const STATE_KEY = ['down', 'idle', 'running'];
export const STATE_LABEL = { running: 'Running', idle: 'Idle', down: 'Down' };
export const stateKey = (m) => STATE_KEY[m.state] || 'down';
export const dash = '–';
export const num = (v, d = 0) => (v == null || Number.isNaN(v) ? dash : Number(v).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }));
export const avg3 = (a, b, c) => (a == null ? null : (a + b + c) / 3);
export function duration(seconds) {
  if (seconds == null) return dash;
  const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60);
  return h ? `${h} h ${String(m).padStart(2, '0')} m` : `${m} m`;
}
export const clock = (t) => new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
export const stamp = (t) => new Date(t).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
// YYYY-MM-DD in the plant time zone, plus date arithmetic on such strings
export const ymd = (d, tz) => new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
export const addDays = (s, n) => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); };
