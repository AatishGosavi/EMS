-- =====================================================================
-- EMS Level 1 - Step 4: batches
-- Run after ems_schema_v2_aggregates.sql.
-- The collector calls batch_start() / batch_end() when it sees a batch start/stop from the PLC.
-- Energy per batch comes from the meter counters at start and end (exact); if a counter was reset
-- during the batch, the logged 1-minute deltas are used instead (approximate).
-- =====================================================================

-- Recipe names (the PLC only sends a number). Unknown numbers are added automatically as 'Recipe <n>'; rename them in the UI.
CREATE TABLE recipes (
  id   int PRIMARY KEY,
  name text NOT NULL
);

CREATE TABLE batches (
  id               bigserial PRIMARY KEY,
  meter_id         int  NOT NULL REFERENCES meters(id),
  batch_no         text NOT NULL,
  recipe_id        int,
  target_qty       real,
  actual_qty       real,
  start_ts         timestamptz NOT NULL,
  end_ts           timestamptz,                         -- NULL while running
  status           text NOT NULL DEFAULT 'running' CHECK (status IN ('running','completed')),
  recovered        boolean NOT NULL DEFAULT false,      -- start or end was reconstructed after a restart (times/energy approximate)
  kwh_import_start double precision, kwh_import_end double precision,
  kwh_export_start double precision, kwh_export_end double precision,
  kwh_import       double precision,                    -- energy used by the batch (filled when it ends)
  kwh_export       double precision,
  peak_kw          real,
  avg_kw           real,
  CHECK ((status = 'running') = (end_ts IS NULL)),
  CHECK (end_ts IS NULL OR end_ts >= start_ts)
);
CREATE INDEX batches_meter_start ON batches (meter_id, start_ts DESC);
CREATE INDEX batches_batch_no    ON batches (batch_no);
CREATE INDEX batches_recipe      ON batches (recipe_id, start_ts DESC);
CREATE UNIQUE INDEX batches_one_open_per_meter ON batches (meter_id) WHERE end_ts IS NULL;

-- End the open batch of a meter. Returns the batch id, or NULL if nothing was open (safe to call twice).
CREATE FUNCTION batch_end(p_meter int, p_ts timestamptz, p_actual_qty real,
                          p_kwh_import double precision, p_kwh_export double precision,
                          p_recovered boolean DEFAULT false)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE b batches%ROWTYPE; ki double precision; ke double precision;
        pk real; av real; sdi double precision; sde double precision; t_end timestamptz;
BEGIN
  SELECT * INTO b FROM batches WHERE meter_id = p_meter AND end_ts IS NULL FOR UPDATE;
  IF NOT FOUND THEN RETURN NULL; END IF;
  t_end := greatest(p_ts, b.start_ts);
  SELECT max(kw), avg(kw), sum(kwh_import_delta), sum(kwh_export_delta) INTO pk, av, sdi, sde
    FROM readings WHERE meter_id = p_meter AND ts > b.start_ts AND ts <= t_end;
  ki := p_kwh_import - b.kwh_import_start;
  IF ki IS NULL OR ki < 0 THEN ki := sdi; END IF;          -- counter missing or reset: use logged deltas
  ke := p_kwh_export - b.kwh_export_start;
  IF ke IS NULL OR ke < 0 THEN ke := sde; END IF;
  UPDATE batches SET end_ts = t_end, status = 'completed',
         actual_qty = coalesce(p_actual_qty, actual_qty),
         kwh_import_end = p_kwh_import, kwh_export_end = p_kwh_export,
         kwh_import = ki, kwh_export = ke, peak_kw = pk, avg_kw = av,
         recovered = recovered OR p_recovered
   WHERE id = b.id;
  RETURN b.id;
END $$;

-- Start a batch. If the same batch number is already open it does nothing; if another batch is open it is closed first.
CREATE FUNCTION batch_start(p_meter int, p_batch_no text, p_recipe int, p_target real, p_ts timestamptz,
                            p_kwh_import double precision, p_kwh_export double precision,
                            p_recovered boolean DEFAULT false)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE o batches%ROWTYPE; new_id bigint; no text := coalesce(nullif(trim(p_batch_no), ''), '(no number)');
BEGIN
  SELECT * INTO o FROM batches WHERE meter_id = p_meter AND end_ts IS NULL;
  IF FOUND THEN
    IF o.batch_no = no THEN RETURN o.id; END IF;
    PERFORM batch_end(p_meter, p_ts, NULL, p_kwh_import, p_kwh_export, true);
  END IF;
  IF p_recipe IS NOT NULL AND p_recipe <> 0 THEN
    INSERT INTO recipes (id, name) VALUES (p_recipe, 'Recipe ' || p_recipe) ON CONFLICT DO NOTHING;
  END IF;
  INSERT INTO batches (meter_id, batch_no, recipe_id, target_qty, start_ts, kwh_import_start, kwh_export_start, recovered)
  VALUES (p_meter, no, nullif(p_recipe, 0), p_target, p_ts, p_kwh_import, p_kwh_export, p_recovered)
  RETURNING id INTO new_id;
  RETURN new_id;
END $$;

-- One row per batch, with live numbers for running batches. This is what the Batches screen and the meter cards read.
CREATE VIEW v_batches AS
SELECT b.id, b.meter_id, m.name AS meter_name, a.name AS area_name,
       b.batch_no, b.recipe_id, coalesce(r.name, CASE WHEN b.recipe_id IS NOT NULL THEN 'Recipe ' || b.recipe_id END) AS recipe_name,
       b.target_qty, b.actual_qty, b.start_ts, b.end_ts, b.status, b.recovered,
       coalesce(b.end_ts, now()) - b.start_ts AS duration,
       CASE WHEN b.status = 'running' THEN greatest(l.kwh_import - b.kwh_import_start, 0) ELSE b.kwh_import END AS kwh_import,
       CASE WHEN b.status = 'running' THEN x.pk ELSE b.peak_kw END AS peak_kw,
       CASE WHEN b.status = 'running' THEN x.av ELSE b.avg_kw END AS avg_kw,
       CASE WHEN b.status = 'running' THEN l.kw END AS current_kw,
       CASE WHEN coalesce(b.actual_qty, 0) > 0 THEN
         (CASE WHEN b.status = 'running' THEN l.kwh_import - b.kwh_import_start ELSE b.kwh_import END) / b.actual_qty END AS kwh_per_unit
FROM batches b
JOIN meters m ON m.id = b.meter_id
JOIN areas a ON a.id = m.area_id
LEFT JOIN recipes r ON r.id = b.recipe_id
LEFT JOIN meter_latest l ON l.meter_id = b.meter_id AND b.status = 'running'
LEFT JOIN LATERAL (SELECT max(kw) AS pk, avg(kw) AS av FROM readings
                   WHERE meter_id = b.meter_id AND ts > b.start_ts AND b.status = 'running') x ON true;

-- Power curve of a batch (minute 0 = start): used for the batch detail chart and for comparing batches.
CREATE FUNCTION batch_curve(p_batch bigint) RETURNS TABLE (minute int, kw real)
LANGUAGE sql STABLE AS $$
  SELECT floor(extract(epoch FROM r.ts - b.start_ts) / 60)::int, r.kw
  FROM batches b JOIN readings r ON r.meter_id = b.meter_id AND r.ts > b.start_ts AND r.ts <= coalesce(b.end_ts, now())
  WHERE b.id = p_batch ORDER BY r.ts $$;

-- The previous completed batch of the same recipe on the same meter.
CREATE FUNCTION batch_previous(p_batch bigint) RETURNS bigint LANGUAGE sql STABLE AS $$
  SELECT p.id FROM batches b
  JOIN batches p ON p.meter_id = b.meter_id AND p.recipe_id IS NOT DISTINCT FROM b.recipe_id
                AND p.status = 'completed' AND p.start_ts < b.start_ts
  WHERE b.id = p_batch ORDER BY p.start_ts DESC LIMIT 1 $$;

-- "At minute N this batch has used x% more/less energy than the previous batch at the same point."
CREATE FUNCTION batch_vs_previous(p_batch bigint)
RETURNS TABLE (previous_id bigint, elapsed_min int, kwh_this numeric, kwh_prev numeric, pct_diff numeric)
LANGUAGE sql STABLE AS $$
  WITH c AS (SELECT * FROM batches WHERE id = p_batch),
       p AS (SELECT * FROM batches WHERE id = batch_previous(p_batch)),
       e AS (SELECT floor(extract(epoch FROM coalesce(c.end_ts, now()) - c.start_ts) / 60)::int AS mins FROM c),
       s AS (
         SELECT p.id AS pid, e.mins,
           (SELECT sum(r.kwh_import_delta)::numeric FROM readings r
             WHERE r.meter_id = c.meter_id AND r.ts > c.start_ts AND r.ts <= c.start_ts + e.mins * interval '1 minute') AS a,
           (SELECT sum(r.kwh_import_delta)::numeric FROM readings r
             WHERE r.meter_id = p.meter_id AND r.ts > p.start_ts AND r.ts <= p.start_ts + e.mins * interval '1 minute') AS b
         FROM c, p, e)
  SELECT pid, mins, round(a, 2), round(b, 2), round((a - b) / nullif(b, 0) * 100, 1) FROM s $$;
