-- =====================================================================
-- EMS Level 1 - database schema v1 (Step 1 + Step 2)
-- Requires PostgreSQL with TimescaleDB 2.18 or newer.
-- Run as a superuser (or the DB owner) on an empty database, e.g. "ems".
--   psql -U postgres -d ems -f ems_schema_v1.sql
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ---------------------------------------------------------------------
-- STEP 1: master data
-- ---------------------------------------------------------------------
CREATE TABLE areas (
  id         serial PRIMARY KEY,
  parent_id  int REFERENCES areas(id),          -- NULL = top-level (the tabs in the UI)
  name       text NOT NULL,
  sort_order int  NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX areas_unique_name ON areas (coalesce(parent_id, 0), name);

CREATE TABLE meters (
  id                serial PRIMARY KEY,
  code              text UNIQUE NOT NULL,        -- short tag, e.g. 'MX-101'
  name              text NOT NULL,               -- e.g. 'Mixer M-101'
  area_id           int  NOT NULL REFERENCES areas(id),
  plc_index         smallint UNIQUE NOT NULL CHECK (plc_index BETWEEN 0 AND 79),  -- slot in the PLC array
  has_batch         boolean NOT NULL DEFAULT false,
  multiplier        numeric NOT NULL DEFAULT 1,  -- CT/PT scaling if the PLC does not apply it
  run_source        text NOT NULL DEFAULT 'kw' CHECK (run_source IN ('plc','kw')),
  idle_threshold_kw real NOT NULL DEFAULT 1,     -- used only when run_source = 'kw'
  is_active         boolean NOT NULL DEFAULT true,
  sort_order        int NOT NULL DEFAULT 0,
  created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX meters_area_idx ON meters (area_id, sort_order);

-- ---------------------------------------------------------------------
-- STEP 2a: latest values (one row per meter, upserted on every PLC poll)
-- state: 0 = down, 1 = idle, 2 = running
-- The API treats a row with ts older than ~30 s as DOWN, even if state says otherwise.
-- ---------------------------------------------------------------------
CREATE TABLE meter_latest (
  meter_id      int PRIMARY KEY REFERENCES meters(id),
  ts            timestamptz NOT NULL,
  state         smallint NOT NULL DEFAULT 0 CHECK (state IN (0,1,2)),
  v_l1 real, v_l2 real, v_l3 real,
  i_l1 real, i_l2 real, i_l3 real,
  kw real, kvar real, kva real, pf real, freq real,
  kwh_import    double precision,
  kwh_export    double precision,
  batch_running boolean NOT NULL DEFAULT false,
  batch_no      text,
  recipe_id     int
);

-- ---------------------------------------------------------------------
-- STEP 2b: raw readings (one row per meter per logging interval)
-- quality bit flags: 1 = counter reset, 2 = gap/estimated, 4 = invalid data
-- kwh_*_delta = consumption since the previous logged sample (0 on reset)
-- ---------------------------------------------------------------------
CREATE TABLE readings (
  ts               timestamptz NOT NULL,
  meter_id         int NOT NULL REFERENCES meters(id),
  state            smallint NOT NULL CHECK (state IN (0,1,2)),
  v_l1 real, v_l2 real, v_l3 real,
  i_l1 real, i_l2 real, i_l3 real,
  kw real, kvar real, kva real, pf real, freq real,
  kwh_import       double precision,
  kwh_export       double precision,
  kwh_import_delta double precision,
  kwh_export_delta double precision,
  quality          smallint NOT NULL DEFAULT 0,
  PRIMARY KEY (meter_id, ts)
);

-- ---------------------------------------------------------------------
-- STEP 2c: make it a time-series table (TimescaleDB hypertable)
-- ---------------------------------------------------------------------
SELECT create_hypertable('readings', 'ts', chunk_time_interval => INTERVAL '7 days');

-- Columnar compression (called "columnstore" in TimescaleDB 2.18+)
ALTER TABLE readings SET (
  timescaledb.enable_columnstore = true,
  timescaledb.segmentby = 'meter_id',
  timescaledb.orderby   = 'ts DESC'
);
CALL add_columnstore_policy('readings', INTERVAL '7 days');     -- compress chunks older than 7 days (a procedure, so CALL)

-- Keep raw data for 2 years (aggregates in Step 3 will be kept longer). Adjust as needed.
SELECT add_retention_policy('readings', INTERVAL '2 years');

-- ---------------------------------------------------------------------
-- OPTIONAL TEST DATA (delete this block for production)
-- ---------------------------------------------------------------------
-- INSERT INTO areas (name, sort_order) VALUES ('Blending', 1), ('Extrusion', 2);
-- INSERT INTO meters (code, name, area_id, plc_index, has_batch, run_source)
--   VALUES ('MX-101', 'Mixer M-101', 1, 0, true, 'plc'), ('EX-204', 'Extruder E-204', 2, 1, true, 'plc');
-- INSERT INTO readings (ts, meter_id, state, kw, kwh_import, kwh_import_delta)
--   VALUES (now(), 1, 2, 212.4, 3120.5, 3.5);

-- ---------------------------------------------------------------------
-- VERIFY (run these after the script)
-- ---------------------------------------------------------------------
-- SELECT extversion FROM pg_extension WHERE extname = 'timescaledb';
-- SELECT hypertable_name, num_chunks FROM timescaledb_information.hypertables;
-- SELECT job_id, proc_name, hypertable_name, schedule_interval FROM timescaledb_information.jobs;
