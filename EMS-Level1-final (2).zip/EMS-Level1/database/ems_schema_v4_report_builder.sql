-- =====================================================================
-- EMS Level 1 - Step 5: dynamic report builder
-- Run after ems_schema_v3_batches.sql.
-- The UI shows the fields/dimensions from the two registry tables. A report is a JSON definition;
-- run_report() validates it against the registry and builds the SQL itself, so the API never
-- accepts raw SQL and a user can only reach fields listed here.
--
-- Definition example:
--   { "groupBy": ["month","area"],
--     "range":   { "from": "2026-01-01", "to": "2026-06-30" },       -- dates in the plant time zone, both inclusive
--     "fields":  [ {"code":"energy_kwh","agg":"sum"}, {"code":"kw_peak"} ],
--     "scope":   "meters",              -- "meters" (default, excludes main meters), "plant" (main meters only), "all"
--     "meters":  [1,2,3] }              -- optional filters: "meters": [ids], "areas": [ids]
-- Usage:  SELECT * FROM run_report('{...}'::jsonb);   -- one JSON object per row
-- =====================================================================

CREATE TABLE report_dimensions (
  code        text PRIMARY KEY,
  label       text NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('time','entity')),
  expr_daily  text,              -- SQL on readings_daily t (NULL = not available at day resolution)
  expr_15min  text,              -- SQL on readings_15min t
  fmt         text,              -- to_char format for time dimensions (plant local time)
  sort_order  int NOT NULL DEFAULT 0
);
INSERT INTO report_dimensions (code, label, kind, expr_daily, expr_15min, fmt, sort_order) VALUES
 ('hour',  'Hour',  'time',   NULL,                                   $$time_bucket('1 hour', t.bucket, {tz})$$, 'YYYY-MM-DD HH24:MI', 1),
 ('day',   'Day',   'time',   't.day',                                $$time_bucket('1 day', t.bucket, {tz})$$,  'YYYY-MM-DD', 2),
 ('week',  'Week',  'time',   $$date_trunc('week', t.day, {tz})$$,    $$date_trunc('week', t.bucket, {tz})$$,    'YYYY-MM-DD', 3),
 ('month', 'Month', 'time',   $$date_trunc('month', t.day, {tz})$$,   $$date_trunc('month', t.bucket, {tz})$$,   'YYYY-MM', 4),
 ('meter', 'Meter', 'entity', 'm.name',                               'm.name',                                  NULL, 5),
 ('area',  'Area',  'entity', 'a.name',                               'a.name',                                  NULL, 6);

CREATE TABLE report_fields (
  code         text PRIMARY KEY,
  label        text NOT NULL,
  unit         text,
  column_name  text NOT NULL,     -- column in readings_daily / readings_15min
  default_agg  text NOT NULL,
  allowed_aggs text[] NOT NULL,   -- subset of sum, avg, min, max
  scale        numeric NOT NULL DEFAULT 1,
  sort_order   int NOT NULL DEFAULT 0,
  CHECK (default_agg = ANY (allowed_aggs)),
  CHECK (allowed_aggs <@ ARRAY['sum','avg','min','max'])
);
-- Averages of averages are equal-weight averages of the periods (fine for 1-minute logging with few gaps).
-- running/idle/down hours assume 1-minute logging (samples / 60).
INSERT INTO report_fields (code, label, unit, column_name, default_agg, allowed_aggs, scale, sort_order) VALUES
 ('energy_kwh',        'Energy consumed',  'kWh',  'kwh_import',      'sum', ARRAY['sum'], 1, 1),
 ('energy_export_kwh', 'Energy exported',  'kWh',  'kwh_export',      'sum', ARRAY['sum'], 1, 2),
 ('kw_avg',            'Average power',    'kW',   'kw_avg',          'avg', ARRAY['avg','min','max'], 1, 3),
 ('kw_peak',           'Peak power',       'kW',   'kw_max',          'max', ARRAY['max','avg'], 1, 4),
 ('kw_min',            'Minimum power',    'kW',   'kw_min',          'min', ARRAY['min','avg'], 1, 5),
 ('kvar_avg',          'Reactive power',   'kVAR', 'kvar_avg',        'avg', ARRAY['avg','max'], 1, 6),
 ('kva_avg',           'Apparent power',   'kVA',  'kva_avg',         'avg', ARRAY['avg','max'], 1, 7),
 ('pf_avg',            'Power factor',     '',     'pf_avg',          'avg', ARRAY['avg','min'], 1, 8),
 ('freq_avg',          'Frequency',        'Hz',   'freq_avg',        'avg', ARRAY['avg','min','max'], 1, 9),
 ('v_l1_avg',          'Voltage L1',       'V',    'v_l1_avg',        'avg', ARRAY['avg','min','max'], 1, 10),
 ('v_l2_avg',          'Voltage L2',       'V',    'v_l2_avg',        'avg', ARRAY['avg','min','max'], 1, 11),
 ('v_l3_avg',          'Voltage L3',       'V',    'v_l3_avg',        'avg', ARRAY['avg','min','max'], 1, 12),
 ('current_max',       'Maximum current',  'A',    'i_max',           'max', ARRAY['max','avg'], 1, 13),
 ('running_hours',     'Running time',     'h',    'running_samples', 'sum', ARRAY['sum'], 1.0/60, 14),
 ('idle_hours',        'Idle time',        'h',    'idle_samples',    'sum', ARRAY['sum'], 1.0/60, 15),
 ('down_hours',        'Down time',        'h',    'down_samples',    'sum', ARRAY['sum'], 1.0/60, 16);

CREATE TABLE report_templates (
  id          serial PRIMARY KEY,
  name        text NOT NULL,
  owner_id    int,                          -- becomes a foreign key to users in Step 6
  is_shared   boolean NOT NULL DEFAULT false,
  definition  jsonb NOT NULL CHECK (jsonb_typeof(definition) = 'object' AND definition ? 'fields'),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX report_templates_owner ON report_templates (owner_id);

CREATE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;
CREATE TRIGGER report_templates_updated BEFORE UPDATE ON report_templates FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE FUNCTION run_report(def jsonb) RETURNS SETOF jsonb
LANGUAGE plpgsql STABLE AS $fn$
DECLARE
  tz     text  := (SELECT value FROM app_settings WHERE key = 'plant_timezone');
  gb     jsonb := CASE WHEN jsonb_typeof(def->'groupBy') = 'string' THEN jsonb_build_array(def->'groupBy')
                       ELSE coalesce(def->'groupBy', '[]'::jsonb) END;
  from_d date  := (def #>> '{range,from}')::date;
  to_d   date  := (def #>> '{range,to}')::date;
  scope  text  := coalesce(def->>'scope', 'meters');
  use15  boolean; src text; tcol text; lo timestamptz; hi timestamptz;
  sel text[] := '{}'; ord text[] := '{}'; w text[] := '{}'; n int := 0;
  d report_dimensions; f report_fields; fld jsonb; dcode text; agg text; e text;
BEGIN
  IF tz IS NULL THEN RAISE EXCEPTION 'plant_timezone is missing in app_settings'; END IF;
  IF from_d IS NULL OR to_d IS NULL OR to_d < from_d THEN
    RAISE EXCEPTION 'range.from and range.to (dates, to >= from) are required'; END IF;
  IF jsonb_typeof(def->'fields') IS DISTINCT FROM 'array' OR jsonb_array_length(def->'fields') = 0 THEN
    RAISE EXCEPTION 'at least one field is required'; END IF;
  IF jsonb_array_length(gb) > 2 THEN RAISE EXCEPTION 'at most two groupBy dimensions'; END IF;
  IF scope NOT IN ('meters','plant','all') THEN RAISE EXCEPTION 'scope must be meters, plant or all'; END IF;

  use15 := EXISTS (SELECT 1 FROM report_dimensions WHERE code IN (SELECT jsonb_array_elements_text(gb)) AND expr_daily IS NULL);
  IF use15 AND to_d - from_d > 62 THEN RAISE EXCEPTION 'hourly reports are limited to 62 days'; END IF;
  src  := CASE WHEN use15 THEN 'readings_15min' ELSE 'readings_daily' END;
  tcol := CASE WHEN use15 THEN 'bucket' ELSE 'day' END;
  lo := from_d::timestamp AT TIME ZONE tz;
  hi := (to_d + 1)::timestamp AT TIME ZONE tz;

  FOR dcode IN SELECT jsonb_array_elements_text(gb) LOOP
    SELECT * INTO d FROM report_dimensions WHERE code = dcode;
    IF NOT FOUND THEN RAISE EXCEPTION 'unknown groupBy dimension: %', dcode; END IF;
    e := replace(CASE WHEN use15 THEN d.expr_15min ELSE d.expr_daily END, '{tz}', quote_literal(tz));
    IF d.kind = 'time' THEN e := format('to_char((%s) AT TIME ZONE %L, %L)', e, tz, d.fmt); END IF;
    n := n + 1; sel := sel || format('%s AS %I', e, d.code); ord := ord || n::text;
  END LOOP;

  FOR fld IN SELECT jsonb_array_elements(def->'fields') LOOP
    SELECT * INTO f FROM report_fields WHERE code = fld->>'code';
    IF NOT FOUND THEN RAISE EXCEPTION 'unknown field: %', fld->>'code'; END IF;
    agg := lower(coalesce(fld->>'agg', f.default_agg));
    IF NOT agg = ANY (f.allowed_aggs) THEN RAISE EXCEPTION 'aggregate % not allowed for field %', agg, f.code; END IF;
    sel := sel || format('round((%s(t.%I) * %s::numeric)::numeric, 3) AS %I', agg, f.column_name, f.scale, f.code || '_' || agg);
  END LOOP;

  w := w || format('t.%I >= %L AND t.%I < %L', tcol, lo, tcol, hi);
  w := w || CASE scope WHEN 'meters' THEN 'NOT m.is_main' WHEN 'plant' THEN 'm.is_main' ELSE 'true' END;
  IF jsonb_typeof(def->'meters') = 'array' THEN
    w := w || format('t.meter_id = ANY (%L::int[])', ARRAY(SELECT jsonb_array_elements_text(def->'meters'))::int[]); END IF;
  IF jsonb_typeof(def->'areas') = 'array' THEN
    w := w || format('m.area_id = ANY (%L::int[])', ARRAY(SELECT jsonb_array_elements_text(def->'areas'))::int[]); END IF;

  RETURN QUERY EXECUTE format(
    'SELECT to_jsonb(q) FROM (SELECT %s FROM %I t JOIN meters m ON m.id = t.meter_id JOIN areas a ON a.id = m.area_id WHERE %s %s LIMIT 10000) q',
    array_to_string(sel, ', '), src, array_to_string(w, ' AND '),
    CASE WHEN n > 0 THEN 'GROUP BY ' || array_to_string(ord, ', ') || ' ORDER BY ' || array_to_string(ord, ', ') ELSE '' END);
END $fn$;
