-- =====================================================================
-- EMS Level 1 - Step 7 (optional): alarms and tariffs / cost
-- Run after ems_schema_v5_users_audit.sql.
-- Alarm rules are stored here; the collector/API evaluates them and calls alarm_raise() / alarm_clear().
-- =====================================================================

-- ---------------------------------------------------------------------
-- Alarms
-- ---------------------------------------------------------------------
CREATE TABLE alarm_rules (
  id          serial PRIMARY KEY,
  name        text NOT NULL,
  scope       text NOT NULL DEFAULT 'meter' CHECK (scope IN ('meter','area','all')),
  meter_id    int REFERENCES meters(id),
  area_id     int REFERENCES areas(id),
  metric      text NOT NULL CHECK (metric IN ('kw','kvar','kva','pf','freq','v_l1','v_l2','v_l3','i_l1','i_l2','i_l3','state')),
  operator    text NOT NULL CHECK (operator IN ('>','>=','<','<=','=')),
  threshold   double precision NOT NULL,            -- for metric 'state': 0 = down, 1 = idle, 2 = running
  for_seconds int NOT NULL DEFAULT 0,               -- condition must hold this long before the alarm is raised
  severity    text NOT NULL DEFAULT 'warning' CHECK (severity IN ('info','warning','critical')),
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  CHECK ((scope = 'meter' AND meter_id IS NOT NULL) OR (scope = 'area' AND area_id IS NOT NULL) OR scope = 'all')
);

CREATE TABLE alarm_events (
  id              bigserial PRIMARY KEY,
  rule_id         int NOT NULL REFERENCES alarm_rules(id) ON DELETE CASCADE,
  meter_id        int NOT NULL REFERENCES meters(id),
  started_at      timestamptz NOT NULL,
  cleared_at      timestamptz,
  value           double precision,                 -- value that triggered it
  message         text,
  acknowledged_by int REFERENCES users(id) ON DELETE SET NULL,
  acknowledged_at timestamptz
);
CREATE UNIQUE INDEX alarm_one_open ON alarm_events (rule_id, meter_id) WHERE cleared_at IS NULL;
CREATE INDEX alarm_events_started ON alarm_events (started_at DESC);
CREATE INDEX alarm_events_meter   ON alarm_events (meter_id, started_at DESC);

-- Raise an alarm (does nothing if the same rule/meter alarm is already open). Returns the event id.
CREATE FUNCTION alarm_raise(p_rule int, p_meter int, p_ts timestamptz, p_value double precision, p_message text DEFAULT NULL)
RETURNS bigint LANGUAGE plpgsql AS $$
DECLARE eid bigint;
BEGIN
  INSERT INTO alarm_events (rule_id, meter_id, started_at, value, message) VALUES (p_rule, p_meter, p_ts, p_value, p_message)
  ON CONFLICT (rule_id, meter_id) WHERE cleared_at IS NULL DO NOTHING RETURNING id INTO eid;
  RETURN eid;                                       -- NULL if it was already open
END $$;

CREATE FUNCTION alarm_clear(p_rule int, p_meter int, p_ts timestamptz) RETURNS bigint LANGUAGE sql AS $$
  UPDATE alarm_events SET cleared_at = p_ts WHERE rule_id = p_rule AND meter_id = p_meter AND cleared_at IS NULL RETURNING id $$;

CREATE FUNCTION alarm_ack(p_event bigint, p_user int) RETURNS boolean LANGUAGE sql AS $$
  WITH u AS (UPDATE alarm_events SET acknowledged_by = p_user, acknowledged_at = now()
             WHERE id = p_event AND acknowledged_at IS NULL RETURNING 1) SELECT EXISTS (SELECT 1 FROM u) $$;

CREATE VIEW v_alarms AS
SELECT e.id, e.started_at, e.cleared_at, (e.cleared_at IS NULL) AS active, r.name AS rule_name, r.severity,
       e.meter_id, m.name AS meter_name, a.name AS area_name, e.value, e.message,
       e.acknowledged_at, u.username AS acknowledged_by
FROM alarm_events e
JOIN alarm_rules r ON r.id = e.rule_id
JOIN meters m ON m.id = e.meter_id
JOIN areas a ON a.id = m.area_id
LEFT JOIN users u ON u.id = e.acknowledged_by;

-- ---------------------------------------------------------------------
-- Tariffs (flat rate, or time-of-use periods in plant local time) and energy cost
-- ---------------------------------------------------------------------
CREATE TABLE tariffs (
  id                   serial PRIMARY KEY,
  name                 text NOT NULL,
  valid_from           date NOT NULL,
  valid_to             date,                                  -- NULL = open ended
  currency             text,
  default_rate_per_kwh numeric NOT NULL,                      -- used when no time-of-use period matches
  demand_rate_per_kw   numeric NOT NULL DEFAULT 0,            -- stored for later; not used by energy_cost()
  fixed_monthly_charge numeric NOT NULL DEFAULT 0,            -- stored for later; not used by energy_cost()
  CHECK (valid_to IS NULL OR valid_to >= valid_from)
);

CREATE TABLE tariff_periods (
  id           serial PRIMARY KEY,
  tariff_id    int NOT NULL REFERENCES tariffs(id) ON DELETE CASCADE,
  name         text NOT NULL,                                 -- e.g. 'Peak'
  start_time   time NOT NULL,                                 -- local time; start >= end means it crosses midnight
  end_time     time NOT NULL,
  days         int[] NOT NULL DEFAULT ARRAY[1,2,3,4,5,6,7],   -- ISO weekdays, 1 = Monday
  rate_per_kwh numeric NOT NULL
);
CREATE INDEX tariff_periods_tariff ON tariff_periods (tariff_id);

-- Cost per local day and meter, from the 15-minute aggregate. With p_meters = NULL it uses all meters except main meters.
-- Where several periods overlap, the highest rate wins. The tariff valid on each local date is used.
CREATE FUNCTION energy_cost(p_from date, p_to date, p_meters int[] DEFAULT NULL)
RETURNS TABLE (day date, meter_id int, kwh numeric, cost numeric, currency text)
LANGUAGE sql STABLE AS $$
  WITH z AS (SELECT value AS tz FROM app_settings WHERE key = 'plant_timezone'),
  b AS (
    SELECT r.meter_id, r.kwh_import, (r.bucket AT TIME ZONE z.tz) AS lt
    FROM readings_15min r CROSS JOIN z JOIN meters m ON m.id = r.meter_id
    WHERE r.bucket >= (p_from::timestamp AT TIME ZONE z.tz) AND r.bucket < ((p_to + 1)::timestamp AT TIME ZONE z.tz)
      AND CASE WHEN p_meters IS NULL THEN NOT m.is_main ELSE m.id = ANY (p_meters) END)
  SELECT b.lt::date, b.meter_id, sum(b.kwh_import)::numeric,
         sum(b.kwh_import * coalesce(p.rate_per_kwh, t.default_rate_per_kwh))::numeric, max(t.currency)
  FROM b
  LEFT JOIN LATERAL (SELECT * FROM tariffs t WHERE t.valid_from <= b.lt::date AND (t.valid_to IS NULL OR t.valid_to >= b.lt::date)
                     ORDER BY t.valid_from DESC LIMIT 1) t ON true
  LEFT JOIN LATERAL (SELECT tp.rate_per_kwh FROM tariff_periods tp
                     WHERE tp.tariff_id = t.id AND extract(isodow FROM b.lt)::int = ANY (tp.days)
                       AND ((tp.start_time < tp.end_time AND b.lt::time >= tp.start_time AND b.lt::time < tp.end_time)
                         OR (tp.start_time >= tp.end_time AND (b.lt::time >= tp.start_time OR b.lt::time < tp.end_time)))
                     ORDER BY tp.rate_per_kwh DESC LIMIT 1) p ON true
  GROUP BY 1, 2 ORDER BY 1, 2 $$;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['alarm_rules','tariffs','tariff_periods'] LOOP
    EXECUTE format('CREATE TRIGGER %I AFTER INSERT OR UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION audit_row_change()', 'audit_' || t, t);
  END LOOP;
END $$;
