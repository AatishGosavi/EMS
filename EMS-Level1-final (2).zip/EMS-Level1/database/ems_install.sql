-- =====================================================================
-- EMS Level 1 - installs the whole database in the right order (psql only).
-- 1. Create an empty database:   psql -U postgres -c "CREATE DATABASE ems;"
-- 2. Open a terminal IN THIS FOLDER (the \i lines use relative paths), then run:
--      psql -U postgres -d ems -f ems_install.sql
-- Plant time zone: edit 'Asia/Kolkata' in ems_schema_v2_aggregates.sql first if your plant is elsewhere.
-- Using pgAdmin or DBeaver instead? Open and run ems_all_in_one.sql (one file, no psql commands).
-- Requires PostgreSQL with the TimescaleDB extension loaded.
-- =====================================================================
\set ON_ERROR_STOP on
\i ems_schema_v1.sql
\i ems_schema_v2_aggregates.sql
\i ems_schema_v3_batches.sql
\i ems_schema_v4_report_builder.sql
\i ems_schema_v5_users_audit.sql
\i ems_schema_v6_alarms_tariffs.sql
\echo 'EMS database installed.'
