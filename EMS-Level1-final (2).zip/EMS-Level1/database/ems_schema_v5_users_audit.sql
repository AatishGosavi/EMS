-- =====================================================================
-- EMS Level 1 - Step 6: users, roles, sessions, audit log
-- Run after ems_schema_v4_report_builder.sql.
--
-- Roles (enforced by the API):
--   viewer   : dashboards, meters, batches, run and export reports, own report templates
--   engineer : viewer + share report templates, edit recipe names, acknowledge alarms
--   admin    : engineer + users, meters, areas, tariffs, alarm rules, settings
-- Passwords: the API stores only a hash (bcrypt or argon2) in users.password_hash. Never store a password.
-- Audit: before changing a config table, the API runs   SET LOCAL ems.user_id = '<user id>';   inside the same
-- transaction, and the triggers below record who changed what (old and new values).
-- =====================================================================

CREATE TABLE users (
  id                   serial PRIMARY KEY,
  username             text NOT NULL,
  display_name         text,
  email                text,
  password_hash        text NOT NULL,
  role                 text NOT NULL DEFAULT 'viewer' CHECK (role IN ('admin','engineer','viewer')),
  is_active            boolean NOT NULL DEFAULT true,
  must_change_password boolean NOT NULL DEFAULT false,
  failed_logins        int NOT NULL DEFAULT 0,
  locked_until         timestamptz,
  last_login_at        timestamptz,
  created_at           timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_username_ci ON users (lower(username));

-- Refresh-token sessions (store only a hash of the token)
CREATE TABLE user_sessions (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id            int NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token_hash text NOT NULL,
  created_at         timestamptz NOT NULL DEFAULT now(),
  expires_at         timestamptz NOT NULL,
  revoked_at         timestamptz,
  ip                 inet,
  user_agent         text
);
CREATE INDEX user_sessions_user ON user_sessions (user_id, expires_at);

ALTER TABLE report_templates
  ADD CONSTRAINT report_templates_owner_fk FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
  id        bigserial PRIMARY KEY,
  ts        timestamptz NOT NULL DEFAULT now(),
  user_id   int,                    -- from ems.user_id (NULL = changed directly in the database)
  action    text NOT NULL,          -- INSERT / UPDATE / DELETE
  entity    text NOT NULL,          -- table name
  entity_id text,
  details   jsonb                   -- INSERT/DELETE: the row; UPDATE: {column: {old, new}}
);
CREATE INDEX audit_log_ts     ON audit_log (ts DESC);
CREATE INDEX audit_log_entity ON audit_log (entity, entity_id, ts DESC);
CREATE INDEX audit_log_user   ON audit_log (user_id, ts DESC);

CREATE FUNCTION audit_row_change() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE o jsonb := CASE WHEN TG_OP <> 'INSERT' THEN to_jsonb(OLD) END;
        n jsonb := CASE WHEN TG_OP <> 'DELETE' THEN to_jsonb(NEW) END;
        d jsonb; pw_changed boolean := false;
BEGIN
  IF TG_TABLE_NAME = 'users' THEN                       -- never copy password hashes into the log
    IF TG_OP = 'UPDATE' THEN pw_changed := (o->>'password_hash') IS DISTINCT FROM (n->>'password_hash'); END IF;
    o := o - 'password_hash' - 'failed_logins' - 'locked_until' - 'last_login_at';
    n := n - 'password_hash' - 'failed_logins' - 'locked_until' - 'last_login_at';
  END IF;
  IF TG_OP = 'UPDATE' THEN
    SELECT jsonb_object_agg(k, jsonb_build_object('old', o->k, 'new', n->k)) INTO d
      FROM jsonb_object_keys(n) AS k WHERE o->k IS DISTINCT FROM n->k AND k <> 'updated_at';
    IF pw_changed THEN d := coalesce(d, '{}'::jsonb) || '{"password":"changed"}'; END IF;
    IF d IS NULL THEN RETURN NEW; END IF;                -- nothing worth logging
  ELSIF TG_OP = 'INSERT' THEN d := n;
  ELSE d := o; END IF;
  INSERT INTO audit_log (user_id, action, entity, entity_id, details)
  VALUES (nullif(current_setting('ems.user_id', true), '')::int, TG_OP, TG_TABLE_NAME,
          coalesce(n->>'id', n->>'key', o->>'id', o->>'key'), d);
  RETURN coalesce(NEW, OLD);
END $$;

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['areas','meters','recipes','report_templates','users','app_settings','report_fields'] LOOP
    EXECUTE format('CREATE TRIGGER %I AFTER INSERT OR UPDATE OR DELETE ON %I FOR EACH ROW EXECUTE FUNCTION audit_row_change()', 'audit_' || t, t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- First administrator (run once, then log in and change the password). Needs the pgcrypto extension:
--   CREATE EXTENSION IF NOT EXISTS pgcrypto;
--   INSERT INTO users (username, display_name, password_hash, role, must_change_password)
--   VALUES ('admin', 'Administrator', crypt('ChangeMe-123', gen_salt('bf', 12)), 'admin', true);
-- (bcrypt hashes made here can be verified by the Node bcrypt/bcryptjs libraries.)
-- ---------------------------------------------------------------------
