# EMS - short user guide

## Signing in
Open the address of the application (for example `http://server:3000`) and sign in. A new account must choose its own
password the first time (at least 8 characters). After 5 wrong passwords an account is locked for 15 minutes.
The **Live** dot in the top bar means data is arriving. A red banner means the collector is not delivering data;
all meters then show as Down until it does.

## Roles
| Role | Can do |
|---|---|
| Viewer | See everything, build and export reports, save own report templates |
| Engineer | + share report templates, acknowledge alarms, edit alarm rules and recipe names |
| Admin | + manage meters, areas, tariffs and users, read the audit log |

## Meter status
- **Running**: the machine is running (PLC run signal, or power above the meter's idle limit).
- **Idle**: the meter is online but the machine is not running.
- **Down**: no signal from the meter, or no fresh data for 30 seconds. Readings are shown as dashes.

## Screens
**Dashboard**: plant load now with the last 24 hours (against yesterday), energy today, peak demand today,
meters online, batches running, energy by area, and a live meter table. Plant figures come from the main (incomer) meter.

**Meters**: one card per meter with the live power on top, the running batch below it, and voltage, current,
power factor, frequency, reactive power and energy today. Use the area tabs and the status filter; switch to **Table** for a list.

**Batches**: all batches with duration, energy and peak power. Click a batch to see its power curve and how its
energy compares with the previous batch of the same recipe at the same point in time.

**Alarms**: *Active* and *History*. Engineers and admins press **Acknowledge**. The number in the menu counts
unacknowledged active alarms.

**Reports**: choose *Group by* (hour, day, week, month, meter, area; optionally a second level), the *Period*, the *Meters*
(all, one area, or the plant total) and the fields. The preview updates by itself. **Export Excel** / **CSV** download it;
**Save template** keeps the setup, and *Saved templates* reloads it. Hourly reports are limited to 62 days.

**Settings** (engineers and admins):
- **Meters**: add or edit meters. *PLC index* is the meter's position in the PLC data block (0 to 79) and must be unique.
  Tick *Main meter* for the plant incomer (only for the incomer, otherwise energy is counted twice). Meters are never deleted; untick *Active*.
- **Areas**: the groups shown as tabs. An area with meters cannot be deleted.
- **Recipes**: give names to the recipe numbers the PLC sends.
- **Alarm rules**: for example "meter is Down (Status = 0) for 60 seconds" or "power above 250 kW for 5 minutes".
- **Tariffs**: flat rate plus optional time-of-use periods, used for the cost calculation (the cost figures are available through the API; there is no cost screen yet).
- **Users**: add users, change roles, reset passwords (leave the password empty to keep it), deactivate.
- **Audit log**: who changed what, and when.

## Common questions
- **A meter shows Down although the machine runs**: check the meter's communication in the PLC (CommOK bit) and its Modbus cable; the PLC must also be counting up *UpdateCount* for that meter.
- **A new meter does not appear**: it appears within seconds if the collector is running and the PLC index is correct.
- **Forgot the admin password**: on the server run `npm run create-admin -- admin NewPassword123` in the backend folder.
- **Daily numbers look cut at the wrong hour**: days start at midnight in the plant time zone written in the database install file (`Asia/Kolkata` unless you changed it before installing).
