-- =====================================================================
-- EMS Level 1 - database schema v2 (Step 3: aggregates for charts and reports)
-- Run AFTER ems_schema_v1.sql, on the same database.
--   psql -U postgres -d ems -f ems_schema_v2_aggregates.sql
-- To use another time zone without editing the file:
--   psql -U postgres -d ems -v plant_tz=Europe/Berlin -f ems_schema_v2_aggregates.sql
-- (pgAdmin does not understand the \set lines: replace :'plant_tz' by your zone in quotes.)
-- Do NOT wrap this script in BEGIN/COMMIT: continuous aggregates cannot be created in a transaction.
-- =====================================================================

-- Plant time zone: decides where a "day" starts and ends in daily/monthly reports.
\if :{?plant_tz}
\else
  \set plant_tz 'Asia/Kolkata'
\endif

-- ---------------------------------------------------------------------
-- Settings the API/UI can read, and the plant-total flag on meters
-- ---------------------------------------------------------------------
CREATE TABLE app_settings (
  key   text PRIMARY KEY,
  value text NOT NULL
);
INSERT INTO app_settings (key, value) VALUES ('plant_timezone', :'plant_tz');

-- Plant total = sum of meters flagged is_main (incomer / main meters).
-- Do not flag sub-meters, or the plant total counts the same energy twice.
ALTER TABLE meters ADD COLUMN is_main boolean NOT NULL DEFAULT false;

-- ---------------------------------------------------------------------
-- 15-minute aggregate: demand and short-term trends.
-- Hourly values are built from these at query time (4 rows per hour).
-- Minutes running/idle/down = *_samples x logging interval (1 minute by default).
-- ---------------------------------------------------------------------
CREATE MATERIALIZED VIEW readings_15min
WITH (timescaledb.continuous) AS
SELECT time_bucket('15 minutes', ts) AS bucket,
       meter_id,
       sum(kwh_import_delta) AS kwh_import,
       sum(kwh_export_delta) AS kwh_export,
       avg(kw) AS kw_avg, min(kw) AS kw_min, max(kw) AS kw_max,
       avg(kvar) AS kvar_avg, avg(kva) AS kva_avg, avg(pf) AS pf_avg, avg(freq) AS freq_avg,
       avg(v_l1) AS v_l1_avg, avg(v_l2) AS v_l2_avg, avg(v_l3) AS v_l3_avg,
       avg(i_l1) AS i_l1_avg, avg(i_l2) AS i_l2_avg, avg(i_l3) AS i_l3_avg,
       max(greatest(i_l1, i_l2, i_l3)) AS i_max,
       count(*) AS samples,
       count(*) FILTER (WHERE state = 2) AS running_samples,
       count(*) FILTER (WHERE state = 1) AS idle_samples,
       count(*) FILTER (WHERE state = 0) AS down_samples
FROM readings
GROUP BY bucket, meter_id
WITH NO DATA;

-- ---------------------------------------------------------------------
-- Daily aggregate in the plant time zone. Weekly and monthly reports are summed from this table.
-- ---------------------------------------------------------------------
CREATE MATERIALIZED VIEW readings_daily
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 day', ts, :'plant_tz') AS day,
       meter_id,
       sum(kwh_import_delta) AS kwh_import,
       sum(kwh_export_delta) AS kwh_export,
       avg(kw) AS kw_avg, min(kw) AS kw_min, max(kw) AS kw_max,
       avg(kvar) AS kvar_avg, avg(kva) AS kva_avg, avg(pf) AS pf_avg, avg(freq) AS freq_avg,
       avg(v_l1) AS v_l1_avg, avg(v_l2) AS v_l2_avg, avg(v_l3) AS v_l3_avg,
       avg(i_l1) AS i_l1_avg, avg(i_l2) AS i_l2_avg, avg(i_l3) AS i_l3_avg,
       max(greatest(i_l1, i_l2, i_l3)) AS i_max,
       count(*) AS samples,
       count(*) FILTER (WHERE state = 2) AS running_samples,
       count(*) FILTER (WHERE state = 1) AS idle_samples,
       count(*) FILTER (WHERE state = 0) AS down_samples
FROM readings
GROUP BY day, meter_id
WITH NO DATA;

-- Real-time mode: queries also include the newest rows that are not materialized yet,
-- so "energy today" on the dashboard is always current.
ALTER MATERIALIZED VIEW readings_15min SET (timescaledb.materialized_only = false);
ALTER MATERIALIZED VIEW readings_daily SET (timescaledb.materialized_only = false);

-- ---------------------------------------------------------------------
-- Refresh policies (background jobs) and retention
-- ---------------------------------------------------------------------
SELECT add_continuous_aggregate_policy('readings_15min',
  start_offset => INTERVAL '3 days', end_offset => INTERVAL '15 minutes', schedule_interval => INTERVAL '5 minutes');
SELECT add_continuous_aggregate_policy('readings_daily',
  start_offset => INTERVAL '7 days', end_offset => INTERVAL '1 hour', schedule_interval => INTERVAL '15 minutes');

-- Raw readings are dropped after 2 years (Step 2). Aggregates are kept longer:
SELECT add_retention_policy('readings_15min', INTERVAL '5 years');
-- readings_daily has no retention policy: monthly/yearly history is kept forever (about 29,000 rows per year).

-- ---------------------------------------------------------------------
-- Plant-level views (sum of the meters flagged is_main)
-- kw_demand = average kW over the 15 minutes, summed over the main meters
-- ---------------------------------------------------------------------
CREATE VIEW plant_15min AS
SELECT r.bucket,
       sum(r.kw_avg)     AS kw_demand,
       sum(r.kwh_import) AS kwh_import,
       sum(r.kwh_export) AS kwh_export,
       count(*)          AS main_meters
FROM readings_15min r
JOIN meters m ON m.id = r.meter_id AND m.is_main
GROUP BY r.bucket;

CREATE VIEW plant_daily AS
SELECT time_bucket('1 day', bucket, :'plant_tz')                 AS day,
       sum(kwh_import)                                           AS kwh_import,
       sum(kwh_export)                                           AS kwh_export,
       max(kw_demand)                                            AS peak_demand_kw,
       (array_agg(bucket ORDER BY kw_demand DESC))[1]            AS peak_at
FROM plant_15min
GROUP BY 1;

-- ---------------------------------------------------------------------
-- Manual refresh after loading old data or fixing readings older than the policy window:
--   CALL refresh_continuous_aggregate('readings_15min', '2026-01-01', '2026-02-01');
--   CALL refresh_continuous_aggregate('readings_daily',  '2026-01-01', '2026-02-01');
--
-- EXAMPLE QUERIES FOR THE API (all time stamps are timestamptz; the plant time zone is in app_settings)
--   Energy per meter per month:      SELECT time_bucket('1 month', day, :'plant_tz') AS month, meter_id, sum(kwh_import)
--                                    FROM readings_daily GROUP BY 1, 2 ORDER BY 1, 2;
--   Energy per area, last 7 days:    SELECT d.day, a.name, sum(d.kwh_import) FROM readings_daily d
--                                    JOIN meters m ON m.id = d.meter_id JOIN areas a ON a.id = m.area_id
--                                    WHERE NOT m.is_main AND d.day >= now() - interval '7 days' GROUP BY 1, 2;
--   Hourly values for a meter:       SELECT time_bucket('1 hour', bucket) AS hour, sum(kwh_import), avg(kw_avg)
--                                    FROM readings_15min WHERE meter_id = 1 AND bucket >= now() - interval '2 days' GROUP BY 1;
--   Running hours per day:           SELECT day, meter_id, running_samples / 60.0 AS running_hours FROM readings_daily;
-- ---------------------------------------------------------------------
