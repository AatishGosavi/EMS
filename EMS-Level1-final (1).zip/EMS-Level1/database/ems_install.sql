-- =====================================================================
-- EMS Level 1 - installs the whole database in the right order.
-- 1. Create an empty database:   psql -U postgres -c "CREATE DATABASE ems;"
-- 2. Put all ems_schema_*.sql files in one folder, open a terminal in that folder, then run:
--      psql -U postgres -d ems -f ems_install.sql
--    Another plant time zone (default Asia/Kolkata):
--      psql -U postgres -d ems -v plant_tz=Europe/Berlin -f ems_install.sql
-- Requires PostgreSQL with the TimescaleDB extension loaded (see the install steps).
-- =====================================================================
\set ON_ERROR_STOP on
\if :{?plant_tz}
\else
  \set plant_tz 'Asia/Kolkata'
\endif
\i ems_schema_v1.sql
\i ems_schema_v2_aggregates.sql
\i ems_schema_v3_batches.sql
\i ems_schema_v4_report_builder.sql
\i ems_schema_v5_users_audit.sql
\i ems_schema_v6_alarms_tariffs.sql
\echo 'EMS database installed.'
