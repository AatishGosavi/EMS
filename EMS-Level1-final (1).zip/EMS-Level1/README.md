# EMS Level 1 - Energy Management System

Reads energy meters through a Siemens S7-1200 PLC, stores the data in PostgreSQL/TimescaleDB, and shows it in a web
application: dashboard, meter cards by area, batches, alarms, report builder (Excel/CSV export) and settings screens.
Short user guide: `docs/USER_GUIDE.md`.

| Folder | Contents |
|---|---|
| `database/` | SQL scripts and `ems_install.sql` (installs everything in the right order) |
| `plc/` | `EMS_PLC_Structures.scl` - UDT_Meter and DB100 `EMS_Data` for TIA Portal |
| `backend/` | Collector (PLC -> database) and API; the built web application is already in `backend/public` |
| `frontend/` | React source of the web application (only needed to change the screens) |
| `docs/` | User guide |

## 1. Prerequisites (not included in this package)

- **Node.js 18 or newer.**
- **PostgreSQL 17 with the TimescaleDB extension.** On Windows: install PostgreSQL 17 from postgresql.org, then the TimescaleDB
  Windows package for PostgreSQL 17 (a zip with `setup.exe`, from the TimescaleDB GitHub releases page; run it as Administrator
  and let it set `shared_preload_libraries = 'timescaledb'`), then restart the PostgreSQL service. Both versions must match.

## 2. Install (Windows PowerShell)

    # database
    psql -U postgres -c "CREATE DATABASE ems;"
    cd database
    psql -U postgres -d ems -f ems_install.sql      # other time zone: add  -v plant_tz=Europe/Berlin  (default Asia/Kolkata)

    # backend
    cd ..\backend
    npm install
    copy .env.example .env                           # edit: DATABASE_URL, JWT_SECRET (32+ random characters), PLC_HOST
    npm run create-admin -- admin YourPassword123

## 3. Try it without a PLC (simulated PLC + demo plant with 20 meters)

    npm run seed:demo
    npm run start:sim

Open http://localhost:3000 and sign in as `admin`. Data fills in within a minute.

## 4. Use it with the real PLC

1. In TIA Portal import `plc/EMS_PLC_Structures.scl`, set the DB number of `EMS_Data` to 100, keep it non-optimized, and allow
   PUT/GET access in the CPU properties. Keep the PLC on a separate network.
2. In `backend\.env` set `PLC_HOST` (rack 0, slot 1, DB 100 are the defaults).
3. Add areas and meters in the application: **Settings -> Areas / Meters** (PLC index = array index in `EMS_Data`). Tick *Main meter* for the incomer.
   Start without the demo data (do not run `seed:demo`).
4. Start both programs (two PowerShell windows):

       npm run collector        # reads the PLC and stores the data
       npm run api              # web application on http://localhost:3000

   (`npm start` runs both in one window.)

## 5. Changing the screens (optional)

    cd frontend
    npm install
    npm run dev                # http://localhost:5173, talks to the backend on :3000
    npm run build:deploy       # builds into ..\backend\public

## 6. Tests

    cd backend
    npm test                   # 15 unit tests, no database needed
    $env:TEST_DATABASE_URL="postgres://postgres:PASSWORD@localhost:5432/ems_test"; npm test
        # + 10 integration tests; use an EMPTY database whose name contains "test", installed with ems_install.sql

## API overview (all under /api, JSON, Bearer token except health and auth)

`auth/login|refresh|logout|me|change-password` - `live/meters` (+ WebSocket `/ws?token=`) - `dashboard` - `meters/:id/trend` -
`batches`, `batches/:id` - `reports/meta|run|export|templates|cost` - `alarms`, `alarms/:id/ack`, `alarm-rules` -
`meters`, `areas`, `recipes`, `users`, `tariffs`, `audit`, `settings`
