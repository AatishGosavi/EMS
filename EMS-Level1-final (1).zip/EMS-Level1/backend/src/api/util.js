'use strict';
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const camelKey = (k) => k.replace(/_([a-z0-9])/g, (_, c) => c.toUpperCase());
const camel = (o) => (Array.isArray(o) ? o.map(camel) : o && typeof o === 'object' && !(o instanceof Date) ? Object.fromEntries(Object.entries(o).map(([k, v]) => [camelKey(k), v])) : o);
const intp = (v, name) => { const n = Number(v); if (v === '' || v == null || !Number.isInteger(n)) throw new HttpError(400, `${name} must be a whole number`); return n; };
const datep = (v, name) => { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(v)) || isNaN(Date.parse(v))) throw new HttpError(400, `${name} must be a date like 2026-09-30`); return String(v); };
const limitp = (v, def = 100, max = 1000) => Math.min(Math.max(parseInt(v, 10) || def, 1), max);

const CONSTRAINTS = {
  meters_plc_index_key: 'This PLC index is already used by another meter', meters_code_key: 'This meter code already exists',
  users_username_ci: 'This username already exists', areas_unique_name: 'An area with this name already exists',
  meters_plc_index_check: 'PLC index must be between 0 and 79',
};
function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
  const map = { '23505': 409, '23503': 400, '23514': 400, '22P02': 400, '22007': 400, '22003': 400, '22008': 400, P0001: 400 };
  if (map[err.code]) {
    const msg = CONSTRAINTS[err.constraint] || (err.code === 'P0001' ? err.message : err.code === '23503' ? 'Refers to something that does not exist, or is still in use' : err.code === '23505' ? 'This value already exists' : 'Value not allowed');
    return res.status(map[err.code]).json({ error: msg });
  }
  console.error('[api]', err);
  res.status(500).json({ error: 'Internal error' });
}
// UPDATE helper: builds "col = $n" pairs for the fields present in body (map: bodyKey -> column).
function patchSet(body, map) {
  const sets = [], vals = [];
  for (const [k, col] of Object.entries(map)) if (body[k] !== undefined) { vals.push(body[k]); sets.push(`${col} = $${vals.length}`); }
  if (!sets.length) throw new HttpError(400, 'Nothing to change');
  return { sets: sets.join(', '), vals };
}
module.exports = { HttpError, wrap, camel, intp, datep, limitp, errorHandler, patchSet };
